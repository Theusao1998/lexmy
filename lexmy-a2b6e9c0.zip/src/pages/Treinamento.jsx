import React, { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Check,
  X,
  BookCopy,
  Gavel,
  RotateCcw,
  ChevronRight,
  Sparkles,
  Clock,
  Target
} from "lucide-react";
import { Assertiva, FiltroQuestao } from "@/api/entities";
import { gradeAnswer } from "@/api/functions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

import { atualizarMetasQuestoes, registrarQuestao } from "@/components/utils/metasHelper";

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

export default function Treinamento() {
  const [filtros, setFiltros] = useState([]);
  const [disciplinaSelecionada, setDisciplinaSelecionada] = useState("");
  const [conteudoSelecionado, setConteudoSelecionado] = useState("");
  const [historicoTopicos, setHistoricoTopicos] = useState([]);

  const [sessaoIniciada, setSessaoIniciada] = useState(false);
  const [questaoAtual, setQuestaoAtual] = useState(null);
  const [carregandoQuestao, setCarregandoQuestao] = useState(false);

  const [respostaUsuario, setRespostaUsuario] = useState(null);
  const [justificativaUsuario, setJustificativaUsuario] = useState("");

  const [feedbackVisivel, setFeedbackVisivel] = useState(false);
  const [correcaoCompleta, setCorrecaoCompleta] = useState(null);
  const [carregandoCorrecao, setCarregandoCorrecao] = useState(false);

  const [estatisticasSessao, setEstatisticasSessao] = useState({
    acertos: 0,
    total: 0,
    inicio: null
  });

  useEffect(() => {
    carregarFiltros();
  }, []);

  const carregarFiltros = async () => {
    try {
      const data = await FiltroQuestao.list('-created_date', 200);
      setFiltros(data);
    } catch (error) {
      console.error('Erro ao carregar filtros:', error);
    }
  };
  
  const disciplinasUnicas = useMemo(() => {
    if (!filtros) return [];
    const nomes = filtros.map(f => f.disciplina);
    return [...new Set(nomes)].sort();
  }, [filtros]);

  const opcoesConteudo = useMemo(() => {
    if (!disciplinaSelecionada || !filtros) return [];
    return filtros
      .filter(f => f.disciplina === disciplinaSelecionada)
      .map(f => f.conteudo)
      .sort();
  }, [disciplinaSelecionada, filtros]);

  const iniciarTreinamento = async () => {
    if (!disciplinaSelecionada || !conteudoSelecionado) {
      alert("Por favor, selecione a disciplina e a submatéria/conteúdo.");
      return;
    }

    setSessaoIniciada(true);
    setEstatisticasSessao({
      acertos: 0,
      total: 0,
      inicio: new Date()
    });
    setHistoricoTopicos([]);
    await gerarNovaQuestao();
  };

  const gerarNovaQuestao = async () => {
    setCarregandoQuestao(true);
    setFeedbackVisivel(false);
    setRespostaUsuario(null);
    setJustificativaUsuario("");
    setCorrecaoCompleta(null);

    try {
      const assertivasCadastradas = await Assertiva.filter({
        disciplina: disciplinaSelecionada,
        conteudo: conteudoSelecionado
      });

      if (!assertivasCadastradas || assertivasCadastradas.length === 0) {
        setQuestaoAtual({
          semAssertivas: true,
          disciplina: disciplinaSelecionada,
          conteudo: conteudoSelecionado
        });
        setCarregandoQuestao(false);
        return;
      }

      const assertivasDisponiveis = assertivasCadastradas.filter(assertiva => {
        return !historicoTopicos.includes(assertiva.topico);
      });

      const assertivasParaEscolha = assertivasDisponiveis.length > 0
        ? assertivasDisponiveis
        : assertivasCadastradas;

      const assertivaEscolhida = assertivasParaEscolha[
        Math.floor(Math.random() * assertivasParaEscolha.length)
      ];

      const questao = {
        assertiva: assertivaEscolhida.assertiva,
        resposta_correta: assertivaEscolhida.resposta_correta,
        topico: assertivaEscolhida.topico,
        assertiva_original: assertivaEscolhida
      };

      setQuestaoAtual(questao);
      
      if (questao.topico) {
        setHistoricoTopicos((prev) => [...prev, questao.topico].slice(-6));
      }

    } catch (error) {
      console.error('Erro ao buscar questões:', error);
      alert('Erro ao carregar questões. Tente novamente.');
    }

    setCarregandoQuestao(false);
  };

  const confirmarResposta = async () => {
    if (!respostaUsuario) {
      alert("Selecione 'Certo' ou 'Errado'.");
      return;
    }

    setCarregandoCorrecao(true);

    try {
      const respostaCorretaSegura = String(questaoAtual.resposta_correta || '').toLowerCase();
      const respostaUsuarioSegura = String(respostaUsuario || '').toLowerCase();
      const acertou = respostaUsuarioSegura === respostaCorretaSegura;

      let correcaoData = null;
      
      if (justificativaUsuario?.trim()) {
        let tentativa = 0;
        while (tentativa < 2) {
          try {
            const { data } = await gradeAnswer({
              disciplina: disciplinaSelecionada,
              conteudo: conteudoSelecionado,
              assertiva: questaoAtual.assertiva,
              resposta_correta: questaoAtual.resposta_correta,
              resposta_usuario: respostaUsuario,
              justificativa_usuario: justificativaUsuario || "",
              assertiva_completa: questaoAtual.assertiva_original
            });
            correcaoData = data;
            break;
          } catch (err) {
            const status = err?.response?.status;
            const msg = String(err?.response?.data?.error || err?.message || "").toLowerCase();
            if ((status === 429 || msg.includes("rate limit")) && tentativa === 0) {
              await delay(1500);
              tentativa++;
              continue;
            }
            throw err;
          }
        }
      }

      const assertivaOriginal = questaoAtual.assertiva_original;
      
      setCorrecaoCompleta({
        acertou,
        fundamentacao_literal: assertivaOriginal.fundamentacao_literal,
        feedback_justificativa: correcaoData?.feedback_justificativa || ""
      });

      setEstatisticasSessao(prev => ({
        ...prev,
        total: prev.total + 1,
        acertos: prev.acertos + (acertou ? 1 : 0)
      }));

      await registrarQuestao('assertiva', disciplinaSelecionada, acertou);

      setFeedbackVisivel(true);

    } catch (error) {
      console.error('Erro ao processar correção:', error);
      
      const assertivaOriginal = questaoAtual.assertiva_original;
      const respostaCorretaSegura = String(questaoAtual.resposta_correta || '').toLowerCase();
      const respostaUsuarioSegura = String(respostaUsuario || '').toLowerCase();
      const acertou = respostaUsuarioSegura === respostaCorretaSegura;
      
      setCorrecaoCompleta({
        acertou,
        fundamentacao_literal: assertivaOriginal.fundamentacao_literal,
        feedback_justificativa: ""
      });

      setEstatisticasSessao(prev => ({
        ...prev,
        total: prev.total + 1,
        acertos: prev.acertos + (acertou ? 1 : 0)
      }));

      try {
        await registrarQuestao('assertiva', disciplinaSelecionada, acertou);
      } catch (metaError) {
        console.error('Erro ao registrar questão:', metaError);
      }

      setFeedbackVisivel(true);
    }

    setCarregandoCorrecao(false);
  };

  const proximaQuestao = () => {
    gerarNovaQuestao();
  };

  const reiniciarTreinamento = () => {
    setSessaoIniciada(false);
    setDisciplinaSelecionada("");
    setConteudoSelecionado("");
    setQuestaoAtual(null);
    setEstatisticasSessao({ acertos: 0, total: 0, inicio: null });
    setHistoricoTopicos([]);
  };

  const calcularTempoSessao = () => {
    if (!estatisticasSessao.inicio) return "0min";
    const minutos = Math.floor((new Date() - estatisticasSessao.inicio) / 60000);
    return `${minutos}min`;
  };

  const calcularPorcentagemAcerto = () => {
    if (estatisticasSessao.total === 0) return 0;
    return Math.round((estatisticasSessao.acertos / estatisticasSessao.total) * 100);
  };

  if (sessaoIniciada) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
        <div className="max-w-4xl mx-auto space-y-6">

          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                <Sparkles className="w-6 h-6 text-blue-600" />
                {disciplinaSelecionada}
              </h1>
              <p className="text-slate-600 text-sm mt-1">Treinamento Inteligente</p>
            </div>

            <div className="flex items-center gap-4">
              <Badge variant="outline" className="gap-2">
                <Target className="w-4 h-4" />
                {estatisticasSessao.acertos}/{estatisticasSessao.total} ({calcularPorcentagemAcerto()}%)
              </Badge>
              <Badge variant="outline" className="gap-2">
                <Clock className="w-4 h-4" />
                {calcularTempoSessao()}
              </Badge>
            </div>
          </div>

          {questaoAtual?.semAssertivas ? (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardContent className="p-12 text-center">
                <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-amber-500 to-orange-500 rounded-3xl flex items-center justify-center">
                  <BookCopy className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhuma Questão Disponível
                </h3>
                <p className="text-slate-600 mb-6">
                  Não há questões cadastradas para <strong>{disciplinaSelecionada}</strong> - <strong>{conteudoSelecionado}</strong>.
                </p>
                <p className="text-sm text-slate-500 mb-6">
                  As questões são criadas pelos administradores. Entre em contato para solicitar mais conteúdo para este tópico.
                </p>
                <Button onClick={reiniciarTreinamento} variant="outline" className="gap-2">
                  <RotateCcw className="w-4 h-4"/> Voltar ao Início
                </Button>
              </CardContent>
            </Card>
          ) : (
            <>
              {carregandoQuestao ? (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardContent className="p-12 text-center">
                    <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl flex items-center justify-center animate-pulse">
                      <Sparkles className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold text-slate-800 mb-2">
                      Carregando Questão...
                    </h3>
                    <p className="text-slate-600">
                      Buscando uma questão do banco de dados
                    </p>
                  </CardContent>
                </Card>
              ) : questaoAtual && (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg text-slate-700">
                        Analise a questão abaixo e responda Certo ou Errado:
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="p-6 bg-gradient-to-r from-slate-50 to-blue-50/30 rounded-lg border border-slate-200 text-lg font-medium text-slate-800 leading-relaxed">
                      {questaoAtual.assertiva}
                    </div>
                  </CardContent>
                </Card>
              )}

              {!feedbackVisivel && questaoAtual && !questaoAtual.semAssertivas && !carregandoQuestao && (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardContent className="p-6 space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <Button
                        onClick={() => setRespostaUsuario('certo')}
                        variant={respostaUsuario === 'certo' ? 'default' : 'outline'}
                        className={`h-20 text-xl gap-3 transition-all duration-200 ${
                          respostaUsuario === 'certo'
                            ? 'bg-green-500 hover:bg-green-600 text-white'
                            : 'hover:bg-green-50 hover:border-green-300'
                        }`}
                      >
                        <Check className="w-6 h-6" /> CERTO
                      </Button>
                      <Button
                        onClick={() => setRespostaUsuario('errado')}
                        variant={respostaUsuario === 'errado' ? 'default' : 'outline'}
                        className={`h-20 text-xl gap-3 transition-all duration-200 ${
                          respostaUsuario === 'errado'
                            ? 'bg-red-500 hover:bg-red-600 text-white'
                            : 'hover:bg-red-50 hover:border-red-300'
                        }`}
                      >
                        <X className="w-6 h-6" /> ERRADO
                      </Button>
                    </div>

                    <div>
                      <label htmlFor="justificativa" className="block text-sm font-medium text-slate-700 mb-2">
                        Fundamente sua resposta (opcional):
                      </label>
                      <Textarea
                        id="justificativa"
                        placeholder="Explique por que a questão está certa ou errada. Isso ajudará a fornecer um feedback mais personalizado..."
                        value={justificativaUsuario}
                        onChange={(e) => setJustificativaUsuario(e.target.value)}
                        className="min-h-[100px]"
                      />
                    </div>

                    <div className="mt-6 flex justify-end">
                      <Button
                        onClick={confirmarResposta}
                        disabled={carregandoCorrecao}
                        size="lg"
                        className="gap-2"
                      >
                        {carregandoCorrecao ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                            Analisando...
                          </>
                        ) : (
                          <>
                            Confirmar Resposta <ChevronRight className="w-4 h-4" />
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {feedbackVisivel && correcaoCompleta && (
                <Card className={`border-0 shadow-xl ${
                  correcaoCompleta.acertou
                    ? 'bg-gradient-to-r from-green-50 to-emerald-50/50'
                    : 'bg-gradient-to-r from-red-50 to-rose-50/50'
                }`}>
                  <CardHeader>
                    <CardTitle className={`flex items-center gap-3 text-2xl ${
                      correcaoCompleta.acertou ? 'text-green-700' : 'text-red-700'
                    }`}>
                      {correcaoCompleta.acertou ? (
                        <Check className="w-8 h-8"/>
                      ) : (
                        <X className="w-8 h-8"/>
                      )}
                      Você {correcaoCompleta.acertou ? 'Acertou!' : 'Errou!'}.
                    </CardTitle>
                    <p className="text-slate-600">
                      A resposta correta era <span className="font-bold text-lg">
                        {String(questaoAtual.resposta_correta || '').toUpperCase()}
                      </span>.
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="p-6 bg-white rounded-xl border shadow-sm">
                      <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                        <BookCopy className="w-5 h-5 text-blue-600" />
                        Fundamentação
                      </h4>
                      <div className="prose prose-slate max-w-none">
                        <div className="whitespace-pre-wrap">{correcaoCompleta.fundamentacao_literal}</div>
                      </div>
                    </div>

                    {justificativaUsuario && correcaoCompleta.feedback_justificativa && (
                      <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg mt-4">
                        <h4 className="font-semibold text-blue-800 mb-2">Sobre sua justificativa:</h4>
                        <p className="text-blue-700">{correcaoCompleta.feedback_justificativa}</p>
                      </div>
                    )}

                    <div className="mt-6 flex justify-between items-center">
                      <Button onClick={reiniciarTreinamento} variant="outline" className="gap-2">
                        <RotateCcw className="w-4 h-4"/> Encerrar Sessão
                      </Button>
                      <Button onClick={proximaQuestao} size="lg" className="gap-2">
                        <Sparkles className="w-5 h-5"/>
                        Próxima Questão
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-8">

        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Treinamento
          </h1>
          <p className="text-slate-600 text-lg">
            Treine com questões estilo CESPE/CEBRASPE
          </p>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
                <Sparkles className="w-6 h-6 text-white" />
              </div>
              Configure sua Sessão de Treinamento
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">
                Disciplina
              </label>
              <Select value={disciplinaSelecionada} onValueChange={setDisciplinaSelecionada}>
                <SelectTrigger>
                  <SelectValue placeholder="Escolha a disciplina..." />
                </SelectTrigger>
                <SelectContent>
                  {disciplinasUnicas.map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {disciplinaSelecionada && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">
                  Conteúdo / Submatéria
                </label>
                <Select value={conteudoSelecionado} onValueChange={setConteudoSelecionado}>
                  <SelectTrigger>
                    <SelectValue placeholder={`Escolha a submatéria de ${disciplinaSelecionada}...`} />
                  </SelectTrigger>
                  <SelectContent>
                    {opcoesConteudo.map((item) => (
                      <SelectItem key={item} value={item}>{item}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {opcoesConteudo.length > 0 && (
                  <p className="text-xs text-slate-500">
                    As opções são definidas pelos administradores.
                  </p>
                )}
              </div>
            )}

            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-blue-50/50 rounded-xl">
                <Sparkles className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                <h3 className="font-semibold text-slate-800 text-sm">Questões Inéditas</h3>
                <p className="text-xs text-slate-600">Geradas por nossa IA</p>
              </div>
              <div className="text-center p-4 bg-green-50/50 rounded-xl">
                <Target className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <h3 className="font-semibold text-slate-800 text-sm">Ilimitadas</h3>
                <p className="text-xs text-slate-600">Quantas quiser</p>
              </div>
              <div className="text-center p-4 bg-purple-50/50 rounded-xl">
                <Gavel className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                <h3 className="font-semibold text-slate-800 text-sm">Feedback Detalhado</h3>
                <p className="text-xs text-slate-600">Correção completa</p>
              </div>
            </div>

            <Button
              onClick={iniciarTreinamento}
              disabled={!disciplinaSelecionada || !conteudoSelecionado}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg gap-2 px-8 py-3 text-lg"
            >
              <Sparkles className="w-5 h-5" />
              Iniciar Treinamento
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}