import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  FileText,
  PenTool,
  Award,
  Clock,
  Target,
  BookOpen,
  ArrowLeft,
  Send,
  CheckCircle2,
  XCircle,
  Lightbulb,
  ThumbsUp,
  ThumbsDown,
  Sparkles,
  Filter
} from "lucide-react";
import { QuestaoDiscursiva } from "@/api/entities";
import { FiltroQuestao } from "@/api/entities";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import { Label } from "@/components/ui/label";

export default function Discursivas() {
  const [questoes, setQuestoes] = useState([]);
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]);
  const [loading, setLoading] = useState(true);

  // Filtros
  const [disciplinaSelecionada, setDisciplinaSelecionada] = useState("");
  const [conteudoSelecionado, setConteudoSelecionado] = useState("");

  // Sessão ativa
  const [sessaoIniciada, setSessaoIniciada] = useState(false);
  const [questaoAtual, setQuestaoAtual] = useState(null);
  const [respostaUsuario, setRespostaUsuario] = useState("");
  const [avaliando, setAvaliando] = useState(false);
  const [avaliacaoCompleta, setAvaliacaoCompleta] = useState(null);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setLoading(true);
    try {
      const [questoesData, filtrosData] = await Promise.all([
        QuestaoDiscursiva.filter({ status: 'publicada' }),
        FiltroQuestao.list('-created_date', 100)
      ]);
      
      setQuestoes(questoesData);
      setFiltrosDisponiveis(filtrosData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar questões.');
    } finally {
      setLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = filtrosDisponiveis.map(f => f.disciplina);
    return [...new Set(disciplinas)].sort();
  }, [filtrosDisponiveis]);

  const opcoesConteudo = React.useMemo(() => {
    if (!disciplinaSelecionada) return [];
    return filtrosDisponiveis
      .filter(f => f.disciplina === disciplinaSelecionada)
      .map(f => f.conteudo)
      .sort();
  }, [disciplinaSelecionada, filtrosDisponiveis]);

  const questoesFiltradas = React.useMemo(() => {
    return questoes.filter(q => {
      const matchDisciplina = !disciplinaSelecionada || q.disciplina === disciplinaSelecionada;
      const matchConteudo = !conteudoSelecionado || q.conteudo === conteudoSelecionado;
      return matchDisciplina && matchConteudo;
    });
  }, [questoes, disciplinaSelecionada, conteudoSelecionado]);

  const iniciarQuestao = (questao) => {
    setQuestaoAtual(questao);
    setRespostaUsuario("");
    setAvaliacaoCompleta(null);
    setSessaoIniciada(true);
  };

  const enviarResposta = async () => {
    if (!respostaUsuario.trim()) {
      toast.error('Digite sua resposta antes de enviar.');
      return;
    }

    if (respostaUsuario.trim().length < 50) {
      toast.error('Sua resposta deve ter pelo menos 50 caracteres.');
      return;
    }

    setAvaliando(true);

    try {
      const { data } = await base44.functions.invoke('gradeDiscursiva', {
        questao_id: questaoAtual.id,
        resposta_usuario: respostaUsuario,
        enunciado: questaoAtual.enunciado,
        resposta_espelho: questaoAtual.resposta_espelho,
        pontuacao_maxima: questaoAtual.pontuacao_maxima,
        criterios_avaliacao: questaoAtual.criterios_avaliacao || ''
      });

      setAvaliacaoCompleta(data.avaliacao);
      toast.success('Resposta avaliada com sucesso!');
      
    } catch (error) {
      console.error('Erro ao avaliar resposta:', error);
      toast.error('Erro ao avaliar resposta. Tente novamente.');
    } finally {
      setAvaliando(false);
    }
  };

  const voltarParaSelecao = () => {
    setSessaoIniciada(false);
    setQuestaoAtual(null);
    setRespostaUsuario("");
    setAvaliacaoCompleta(null);
  };

  const proximaQuestao = () => {
    const indexAtual = questoesFiltradas.findIndex(q => q.id === questaoAtual.id);
    if (indexAtual < questoesFiltradas.length - 1) {
      iniciarQuestao(questoesFiltradas[indexAtual + 1]);
    } else {
      toast.info('Você chegou ao fim das questões disponíveis.');
      voltarParaSelecao();
    }
  };

  // Tela de resposta da questão
  if (sessaoIniciada && questaoAtual) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
        <div className="max-w-5xl mx-auto space-y-6">
          {/* Header */}
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={voltarParaSelecao}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
            <div className="flex items-center gap-4">
              <Badge variant="outline" className="gap-2">
                <Target className="w-4 h-4" />
                {questaoAtual.pontuacao_maxima} pontos
              </Badge>
              {questaoAtual.tempo_estimado_minutos && (
                <Badge variant="outline" className="gap-2">
                  <Clock className="w-4 h-4" />
                  {questaoAtual.tempo_estimado_minutos} min
                </Badge>
              )}
            </div>
          </div>

          {/* Questão */}
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-xl mb-2">{questaoAtual.titulo}</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{questaoAtual.disciplina}</Badge>
                    {questaoAtual.conteudo && (
                      <Badge variant="outline" className="bg-blue-50">
                        {questaoAtual.conteudo}
                      </Badge>
                    )}
                    <Badge className={
                      questaoAtual.dificuldade === 'fácil' ? 'bg-green-100 text-green-700' :
                      questaoAtual.dificuldade === 'média' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }>
                      {questaoAtual.dificuldade}
                    </Badge>
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Enunciado */}
              <div className="p-6 bg-gradient-to-r from-slate-50 to-blue-50/30 rounded-lg border border-slate-200">
                <h3 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Enunciado
                </h3>
                <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">
                  {questaoAtual.enunciado}
                </p>
              </div>

              {/* Resposta do usuário */}
              {!avaliacaoCompleta && (
                <div className="space-y-3">
                  <Label className="text-base font-semibold flex items-center gap-2">
                    <PenTool className="w-5 h-5 text-purple-600" />
                    Sua Resposta
                  </Label>
                  <Textarea
                    value={respostaUsuario}
                    onChange={(e) => setRespostaUsuario(e.target.value)}
                    placeholder="Digite sua resposta aqui... Seja claro, objetivo e fundamentado."
                    className="min-h-[300px] text-base"
                    disabled={avaliando}
                  />
                  
                  <div className="flex justify-between items-center">
                    <p className="text-sm text-slate-500">
                      {respostaUsuario.length} caracteres (mínimo: 50)
                    </p>
                    <Button
                      onClick={enviarResposta}
                      disabled={avaliando || respostaUsuario.trim().length < 50}
                      className="gap-2"
                    >
                      {avaliando ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                          Avaliando...
                        </>
                      ) : (
                        <>
                          <Send className="w-4 h-4" />
                          Enviar e Avaliar
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}

              {/* Avaliação */}
              {avaliacaoCompleta && (
                <div className="space-y-6">
                  {/* Pontuação */}
                  <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center">
                          <Award className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <p className="text-sm text-slate-600">Pontuação Obtida</p>
                          <p className="text-3xl font-bold text-blue-700">
                            {avaliacaoCompleta.pontuacao_obtida}/{questaoAtual.pontuacao_maxima}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-slate-600">Aproveitamento</p>
                        <p className="text-2xl font-bold text-blue-700">
                          {Math.round((avaliacaoCompleta.pontuacao_obtida / questaoAtual.pontuacao_maxima) * 100)}%
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Feedback Geral */}
                  <div className="p-6 bg-white rounded-xl border border-slate-200">
                    <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                      <Sparkles className="w-5 h-5 text-purple-600" />
                      Feedback Geral
                    </h4>
                    <p className="text-slate-700 whitespace-pre-wrap leading-relaxed">
                      {avaliacaoCompleta.feedback_geral}
                    </p>
                  </div>

                  {/* Pontos Fortes */}
                  <div className="p-6 bg-green-50 rounded-xl border border-green-200">
                    <h4 className="font-semibold text-green-800 mb-3 flex items-center gap-2">
                      <ThumbsUp className="w-5 h-5" />
                      Pontos Fortes
                    </h4>
                    <p className="text-green-700 whitespace-pre-wrap leading-relaxed">
                      {avaliacaoCompleta.pontos_fortes}
                    </p>
                  </div>

                  {/* Pontos Fracos */}
                  <div className="p-6 bg-red-50 rounded-xl border border-red-200">
                    <h4 className="font-semibold text-red-800 mb-3 flex items-center gap-2">
                      <ThumbsDown className="w-5 h-5" />
                      Pontos Fracos
                    </h4>
                    <p className="text-red-700 whitespace-pre-wrap leading-relaxed">
                      {avaliacaoCompleta.pontos_fracos}
                    </p>
                  </div>

                  {/* Sugestões de Melhoria */}
                  <div className="p-6 bg-amber-50 rounded-xl border border-amber-200">
                    <h4 className="font-semibold text-amber-800 mb-3 flex items-center gap-2">
                      <Lightbulb className="w-5 h-5" />
                      Sugestões de Melhoria
                    </h4>
                    <p className="text-amber-700 whitespace-pre-wrap leading-relaxed">
                      {avaliacaoCompleta.sugestoes_melhoria}
                    </p>
                  </div>

                  {/* Resposta Espelho */}
                  <div className="p-6 bg-blue-50 rounded-xl border border-blue-200">
                    <h4 className="font-semibold text-blue-800 mb-3 flex items-center gap-2">
                      <BookOpen className="w-5 h-5" />
                      Resposta Espelho (Gabarito)
                    </h4>
                    <p className="text-blue-700 whitespace-pre-wrap leading-relaxed">
                      {questaoAtual.resposta_espelho}
                    </p>
                  </div>

                  {/* Botões */}
                  <div className="flex justify-between items-center pt-4 border-t">
                    <Button variant="outline" onClick={voltarParaSelecao}>
                      <ArrowLeft className="w-4 h-4 mr-2" />
                      Voltar às Questões
                    </Button>
                    <Button onClick={proximaQuestao} className="gap-2">
                      Próxima Questão
                      <Sparkles className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Tela principal
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Questões Discursivas
          </h1>
          <p className="text-slate-600 max-w-2xl">
            Desenvolva suas habilidades de redação jurídica com questões discursivas avaliadas por IA
          </p>
        </div>

        {/* Filtros */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Disciplina</Label>
                <Select value={disciplinaSelecionada} onValueChange={setDisciplinaSelecionada}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas as disciplinas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Todas as disciplinas</SelectItem>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Conteúdo</Label>
                <Select 
                  value={conteudoSelecionado} 
                  onValueChange={setConteudoSelecionado}
                  disabled={!disciplinaSelecionada}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os conteúdos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Todos os conteúdos</SelectItem>
                    {opcoesConteudo.map(c => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setDisciplinaSelecionada("");
                    setConteudoSelecionado("");
                  }}
                  className="w-full"
                >
                  <Filter className="w-4 h-4 mr-2" />
                  Limpar Filtros
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de questões */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
          </div>
        ) : questoesFiltradas.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {questoesFiltradas.map(questao => (
              <Card key={questao.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all">
                <CardHeader>
                  <div className="flex items-start justify-between mb-2">
                    <Badge className={
                      questao.dificuldade === 'fácil' ? 'bg-green-100 text-green-700' :
                      questao.dificuldade === 'média' ? 'bg-amber-100 text-amber-700' :
                      'bg-red-100 text-red-700'
                    }>
                      {questao.dificuldade}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg leading-tight">{questao.titulo}</CardTitle>
                  <p className="text-sm text-slate-600">{questao.disciplina}</p>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-600" />
                      <span className="text-slate-600">{questao.tempo_estimado_minutos}min</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Target className="w-4 h-4 text-green-600" />
                      <span className="text-slate-600">{questao.pontuacao_maxima} pts</span>
                    </div>
                  </div>
                  <Button 
                    onClick={() => iniciarQuestao(questao)}
                    className="w-full gap-2"
                  >
                    <PenTool className="w-4 h-4" />
                    Responder
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <FileText className="w-16 h-16 mx-auto mb-6 text-slate-400" />
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Nenhuma questão encontrada
              </h3>
              <p className="text-slate-600">
                {disciplinaSelecionada || conteudoSelecionado
                  ? 'Tente ajustar os filtros de busca'
                  : 'Ainda não há questões discursivas disponíveis'}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}