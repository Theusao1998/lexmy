
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Play,
  Pause,
  Square,
  RotateCcw,
  Timer,
  Clock,
  Music,
  Upload as UploadIcon,
  Trash2,
  Settings,
  CheckCircle2,
  Plus,
  Minus,
  ChevronUp,
  ChevronDown
} from "lucide-react";
import { SessaoEstudo } from "@/api/entities";
import { useTimer } from "@/components/timer/TimerContext";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { MusicaFoco } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { User } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function Temporizador() {
  const {
    tempoRestante, tempoTotal, isAtivo,
    resetar, formatarTempo,
    sessaoIniciadaIso,
    salvarSessaoAtual,
    selectedMusicId, selectedMusicTitle, volumeMusica,
    setSelectedMusicId, setSelectedMusicTitle, setVolumeMusica,
    tempoPersonalizado, atualizarTempoPersonalizado,
    iniciarPausar, // CORRIGIDO: Usar a função do contexto
    lastWorkCompletedAt, lastWorkSession // Mantido para consistência
  } = useTimer();

  // REMOVIDO: Estados de disciplina e tipo de sessão
  const [currentSessionId, setCurrentSessionId] = useState(() => localStorage.getItem('timer_currentSessionId'));

  const [musicas, setMusicas] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [uploadingMusica, setUploadingMusica] = useState(false);
  const [uploadMusicaError, setUploadMusicaError] = useState("");
  const [manageMusicasOpen, setManageMusicasOpen] = useState(false);

  // REMOVIDO: carregarDisciplinas não é mais necessário

  const carregarMusicas = useCallback(async () => {
    try {
      const lista = await MusicaFoco.list("-created_date", 100);
      setMusicas(lista);
    } catch (e) {
      console.error("Erro ao carregar músicas", e);
    }
  }, []);

  useEffect(() => {
    // REMOVIDO: carregarDisciplinas
    carregarMusicas();
    (async () => {
      try {
        const me = await User.me();
        setIsAdmin(me.role === "admin");
      } catch (e) {
        console.error("Failed to check user role:", e);
        setIsAdmin(false);
      }
    })();

    const savedSessionId = localStorage.getItem('timer_currentSessionId');
    if (savedSessionId) {
      SessaoEstudo.filter({ id: savedSessionId }).then(sessions => {
        if (!sessions || sessions.length === 0) {
          localStorage.removeItem('timer_currentSessionId');
          setCurrentSessionId(null);
        }
      }).catch(() => {
        console.error("Erro ao verificar sessão de estudo no localStorage, limpando.", savedSessionId);
        localStorage.removeItem('timer_currentSessionId');
        setCurrentSessionId(null);
      });
    }
  }, [carregarMusicas]); // REMOVIDO: carregarDisciplinas

  const aumentarTempo = () => {
    const novoTempo = Math.min(180, tempoPersonalizado + 5);
    atualizarTempoPersonalizado(novoTempo);
  };

  const diminuirTempo = () => {
    const novoTempo = Math.max(1, tempoPersonalizado - 5);
    atualizarTempoPersonalizado(novoTempo);
  };

  const ajustarTempoRapido = (minutos) => {
    const novoTempo = Math.max(1, Math.min(180, minutos));
    atualizarTempoPersonalizado(novoTempo);
  };

  const handleDeleteMusica = async (id) => {
    const ok = window.confirm("Tem certeza que deseja excluir esta música?");
    if (!ok) return;
    try {
      await MusicaFoco.delete(id);
      await carregarMusicas();
      if (selectedMusicId === id) {
        setSelectedMusicId("");
        setSelectedMusicTitle("");
      }
    } catch (e) {
      console.error("Erro ao excluir música:", e);
      setUploadMusicaError("Falha ao excluir a música.");
    }
  };

  const handleUploadMusica = async (e) => {
    setUploadMusicaError("");
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingMusica(true);
    try {
      const { file_url } = await UploadFile({ file });
      const baseTitle = file.name.replace(/\.[^/.]+$/, "");
      await MusicaFoco.create({
        titulo: baseTitle,
        audio_url: file_url
      });
      await carregarMusicas();
    } catch (err) {
      console.error("Upload music error:", err);
      let msg = "Falha ao enviar o arquivo. Tente novamente.";
      const raw = String(err?.message || "");
      if (err?.response?.status === 413 || raw.includes("413") || raw.toLowerCase().includes("payload too large")) {
        msg = "Este arquivo ultrapassa o limite do servidor. Comprima o áudio (ex.: MP3 128 kbps) ou envie uma versão menor.";
      }
      setUploadMusicaError(msg);
    } finally {
      setUploadingMusica(false);
      e.target.value = "";
    }
  };

  // REMOVIDO: A função iniciarPausar local foi removida, pois agora usamos a do contexto.
  
  // Lógica de sessão de estudo simplificada
  useEffect(() => {
    const startSessionIfNeeded = async () => {
      if (!isAtivo) return;
      if (currentSessionId) return;
      
      const startIso = sessaoIniciadaIso || new Date().toISOString();
      
      try {
        // SIMPLIFICADO: Criar sessão apenas com dados essenciais
        const rec = await SessaoEstudo.create({
          duracao_minutos: 0,
          data_inicio: startIso,
          data_fim: startIso // Temporário, será atualizado quando a sessão for finalizada
        });
        setCurrentSessionId(rec.id);
        localStorage.setItem('timer_currentSessionId', rec.id);
      } catch (e) {
        console.error('Erro ao iniciar registro de sessão:', e);
        setCurrentSessionId(null);
        localStorage.removeItem('timer_currentSessionId');
      }
    };

    if (isAtivo) {
      startSessionIfNeeded();
    }
  }, [isAtivo, sessaoIniciadaIso, currentSessionId]);

  // SIMPLIFICADO: Effect para salvar sessão quando pausar
  useEffect(() => {
    const wasActive = localStorage.getItem("timer_wasActive") === "true";
    
    if (wasActive && !isAtivo && sessaoIniciadaIso) {
      // SIMPLIFICADO: Não precisa mais passar parâmetros
      salvarSessaoAtual();
      
      // Limpar o currentSessionId após salvar
      setCurrentSessionId(null);
      localStorage.removeItem('timer_currentSessionId');
    }
    
    localStorage.setItem("timer_wasActive", isAtivo.toString());
  }, [isAtivo, sessaoIniciadaIso, salvarSessaoAtual]);

  // SIMPLIFICADO: useEffect para lastWorkCompletedAt
  useEffect(() => {
    if (!lastWorkCompletedAt || !lastWorkSession) return;
    
    const persistCompletion = async () => {
      try {
        console.log('Sessão já persistida pelo contexto');
      } catch (e) {
        console.error('Erro ao processar conclusão da sessão:', e);
      }
    };
    persistCompletion();
  }, [lastWorkCompletedAt, lastWorkSession]);

  const progressoPercentual = ((tempoTotal - tempoRestante) / tempoTotal) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        {/* Header */}
        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Temporizador de Estudo
          </h1>
          <p className="text-slate-600 text-lg">
            Controle seu tempo de estudo com foco e produtividade
          </p>
        </div>

        {/* Timer Principal com Controles Integrados */}
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-2xl">
          <CardContent className="p-8 md:p-12">
            <div className="text-center space-y-8">

              {/* Ícone e Status */}
              <div className="space-y-4">
                <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl flex items-center justify-center shadow-xl">
                  <Timer className="w-10 h-10 text-white" />
                </div>

                <div>
                  <h2 className="text-2xl font-bold text-slate-800">
                    {isAtivo ? 'Estudando' : 'Pausado'}
                  </h2>
                  <p className="text-slate-600">
                    {isAtivo ? 'Mantenha o foco!' : 'Pronto para começar'}
                  </p>
                </div>

                {isAtivo && (
                  <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white border-0 px-4 py-1">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse mr-2"></div>
                    Em andamento
                  </Badge>
                )}
              </div>

              {/* Display do Tempo com Controles Integrados */}
              <div className="space-y-6">
                {/* Controles de Ajuste de Tempo (apenas quando pausado) */}
                {!isAtivo && (
                  <div className="flex items-center justify-center gap-4 mb-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={diminuirTempo}
                      className="h-10 w-10 p-0 rounded-full hover:bg-red-50 hover:border-red-200"
                      disabled={tempoPersonalizado <= 1}
                    >
                      <Minus className="w-4 h-4 text-red-600" />
                    </Button>
                    
                    <div className="text-center">
                      <p className="text-sm text-slate-500 mb-1">Configurar tempo</p>
                      <p className="text-lg font-semibold text-slate-700">
                        {tempoPersonalizado} minutos
                      </p>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={aumentarTempo}
                      className="h-10 w-10 p-0 rounded-full hover:bg-green-50 hover:border-green-200"
                      disabled={tempoPersonalizado >= 180}
                    >
                      <Plus className="w-4 h-4 text-green-600" />
                    </Button>
                  </div>
                )}

                {/* Botões de Tempo Rápido (apenas quando pausado) */}
                {!isAtivo && (
                  <div className="flex justify-center gap-2 mb-6">
                    {[15, 25, 45, 60].map((minutos) => (
                      <Button
                        key={minutos}
                        variant="ghost"
                        size="sm"
                        onClick={() => ajustarTempoRapido(minutos)}
                        className={`h-8 px-3 text-xs rounded-full ${
                          tempoPersonalizado === minutos 
                            ? 'bg-blue-100 text-blue-700 border border-blue-200' 
                            : 'hover:bg-slate-100'
                        }`}
                      >
                        {minutos}min
                      </Button>
                    ))}
                  </div>
                )}

                <div className="text-8xl md:text-9xl font-bold text-slate-800 font-mono tracking-tighter">
                  {formatarTempo(tempoRestante)}
                </div>

                <Progress
                  value={progressoPercentual}
                  className="h-3 bg-slate-200"
                />

                <p className="text-sm text-slate-500">
                  {Math.round(progressoPercentual)}% concluído
                </p>
              </div>

              {/* Controles Principais */}
              <div className="flex justify-center gap-4">
                <Button
                  onClick={iniciarPausar}
                  className="bg-gradient-to-r from-blue-500 to-blue-600 hover:opacity-90 shadow-lg px-8 py-3 gap-3 text-lg"
                  size="lg"
                >
                  {isAtivo ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                  {isAtivo ? 'Pausar' : 'Iniciar'}
                </Button>

                <Button
                  onClick={resetar}
                  variant="outline"
                  size="lg"
                  className="px-6 gap-2"
                >
                  <RotateCcw className="w-4 h-4" />
                  Nova Sessão
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* SIMPLIFICADO: Apenas aba de música */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <Card className="relative bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              {/* Botões admin */}
              {isAdmin && (
                <>
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleUploadMusica}
                    className="hidden"
                    id="upload-musica-focus"
                    disabled={uploadingMusica}
                  />
                  <input
                    type="file"
                    accept="audio/*"
                    onChange={handleUploadMusica}
                    className="hidden"
                    id="upload-musica-focus-dialog"
                    disabled={uploadingMusica}
                  />
                  <div className="absolute top-4 right-4 flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      className="gap-2"
                      onClick={() => setManageMusicasOpen(true)}
                    >
                      <Trash2 className="w-4 h-4" />
                      Editar músicas
                    </Button>
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 gap-2"
                      disabled={uploadingMusica}
                      onClick={() => {
                        setUploadMusicaError("");
                        const el = document.getElementById('upload-musica-focus');
                        if (el) el.click();
                      }}
                    >
                      <UploadIcon className="w-4 h-4" />
                      {uploadingMusica ? "Enviando..." : "Adicionar música"}
                    </Button>
                  </div>
                </>
              )}

              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Music className="w-4 h-4" /> Música de Foco
                </CardTitle>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Seleção da música */}
                <div className="space-y-2">
                  <label className="text-sm text-slate-700">Selecione a música</label>
                  <select
                    value={selectedMusicId || ""}
                    onChange={(e) => {
                      const value = e.target.value;
                      setSelectedMusicId(value === "null" ? "" : value);
                      const item = musicas.find(m => m.id === value);
                      setSelectedMusicTitle(item?.titulo || "");
                    }}
                    className="w-full p-2 border border-slate-300 rounded-md bg-white"
                  >
                    <option value="null">Nenhuma</option>
                    {musicas.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.titulo}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Volume */}
                <div className="space-y-2">
                  <label className="text-sm text-slate-700">Volume ({Math.round(volumeMusica * 100)}%)</label>
                  <Slider
                    value={[volumeMusica]}
                    onValueChange={(vals) => setVolumeMusica(vals[0])}
                    min={0}
                    max={1}
                    step={0.01}
                  />
                </div>

                {/* Erros de upload (se houver) */}
                {uploadMusicaError && (
                  <p className="text-xs text-red-600 mt-2">{uploadMusicaError}</p>
                )}
              </CardContent>
            </Card>

            {/* Diálogo de gestão de músicas (admin) */}
            {isAdmin && (
              <Dialog open={manageMusicasOpen} onOpenChange={setManageMusicasOpen}>
                <DialogContent className="sm:max-w-xl w-[min(92vw,700px)]">
                  <DialogHeader>
                    <DialogTitle>Gerenciar músicas de foco</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    {/* Lista de músicas com opção de excluir */}
                    <div className="max-h-72 overflow-auto border rounded-lg">
                      {musicas.length === 0 ? (
                        <div className="p-4 text-sm text-slate-600">
                          Nenhuma música cadastrada ainda.
                        </div>
                      ) : (
                        <ul className="divide-y">
                          {musicas.map((m) => (
                            <li key={m.id} className="flex items-start gap-3 px-4 py-3">
                              <div className="flex-1 min-w-0 pr-2">
                                <p className="font-medium text-slate-800 truncate">{m.titulo}</p>
                                <p className="text-xs text-slate-500 break-all">{m.audio_url}</p>
                              </div>
                              <div className="flex-shrink-0">
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="text-red-600 border-red-200 hover:bg-red-50"
                                  onClick={() => handleDeleteMusica(m.id)}
                                >
                                  <Trash2 className="w-4 h-4 mr-1" />
                                  Excluir
                                </Button>
                              </div>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>

                    {/* Adicionar nova música dentro do diálogo */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-700">Adicionar nova música</p>
                        <p className="text-xs text-slate-500">Envie um arquivo de áudio do seu computador</p>
                      </div>
                      <Button
                        size="sm"
                        disabled={uploadingMusica}
                        onClick={() => {
                          setUploadMusicaError("");
                          const el = document.getElementById('upload-musica-focus-dialog');
                          if (el) el.click();
                        }}
                        className="gap-2"
                      >
                        <UploadIcon className="w-4 h-4" />
                        {uploadingMusica ? "Enviando..." : "Carregar"}
                      </Button>
                    </div>

                    {uploadMusicaError && (
                      <p className="text-xs text-red-600">{uploadMusicaError}</p>
                    )}
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
