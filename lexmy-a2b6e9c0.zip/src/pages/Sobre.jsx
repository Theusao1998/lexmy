import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Target,
  Heart,
  Lightbulb,
  Users,
  Award,
  Sparkles,
  BookOpen,
  Brain,
  MessageCircle,
  TrendingUp,
  Shield,
  Zap
} from "lucide-react";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import LexmyLogo from "@/components/brand/LexmyLogo";

export default function Sobre() {
  const handleIniciar = async () => {
    try {
      const callbackUrl = window.location.origin + createPageUrl("Dashboard");
      await User.loginWithRedirect(callbackUrl);
    } catch (error) {
      console.error('Erro no login:', error);
      try {
        await User.login();
      } catch (fallbackError) {
        console.error('Erro no fallback login:', fallbackError);
      }
    }
  };

  const valores = [
    {
      icon: Target,
      titulo: "Foco no Resultado",
      descricao: "Cada recurso é pensado para maximizar suas chances de aprovação."
    },
    {
      icon: Heart,
      titulo: "Paixão pela Educação",
      descricao: "Acreditamos que educação de qualidade transforma vidas e sociedades."
    },
    {
      icon: Lightbulb,
      titulo: "Inovação Constante",
      descricao: "Tecnologia de ponta aplicada aos estudos jurídicos, sempre evoluindo."
    },
    {
      icon: Users,
      titulo: "Comunidade Forte",
      descricao: "Juntos somos mais fortes. Apoio mútuo faz a diferença na jornada."
    }
  ];

  const diferenciais = [
    {
      icon: Brain,
      titulo: "Inteligência Artificial Jurídica",
      descricao: "Prof. Lex, nosso assistente de IA especializado em direito, disponível 24/7 para tirar suas dúvidas."
    },
    {
      icon: BookOpen,
      titulo: "Conteúdo Completo e Organizado",
      descricao: "Biblioteca jurídica com materiais organizados por disciplina, legislação, jurisprudência e doutrina."
    },
    {
      icon: TrendingUp,
      titulo: "Acompanhamento de Progresso",
      descricao: "Dashboard detalhado com métricas e estatísticas para você saber exatamente onde está e para onde ir."
    },
    {
      icon: MessageCircle,
      titulo: "Comunidade Ativa",
      descricao: "Conecte-se com outros concurseiros, compartilhe experiências e cresça junto com a comunidade."
    },
    {
      icon: Shield,
      titulo: "Metodologia Comprovada",
      descricao: "Sistema de revisões espaçadas, técnica Pomodoro e verticalização de editais baseados em ciência."
    },
    {
      icon: Zap,
      titulo: "Tudo em Um Só Lugar",
      descricao: "Não perca tempo alternando entre várias ferramentas. Tudo que você precisa está aqui."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
      {/* Header/Navbar */}
      <header className="sticky top-0 z-50 w-full glass-effect border-b border-slate-200/60">
        <style>{`
          .glass-effect {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
          }
        `}</style>
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <a href={createPageUrl("Home")}>
              <LexmyLogo className="w-40 h-auto cursor-pointer" />
            </a>
            
            <nav className="hidden md:flex items-center gap-6">
              <a 
                href={createPageUrl("Sobre")} 
                className="text-slate-700 hover:text-blue-600 transition-colors font-medium"
              >
                Sobre
              </a>
              <a 
                href={createPageUrl("Precos")} 
                className="text-slate-700 hover:text-blue-600 transition-colors font-medium"
              >
                Preços
              </a>
              <Button 
                onClick={handleIniciar}
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Entrar
              </Button>
            </nav>

            {/* Menu mobile */}
            <div className="md:hidden">
              <Button 
                onClick={handleIniciar}
                size="sm"
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Entrar
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-12 md:py-20">
        
        {/* Header */}
        <div className="text-center space-y-6 mb-20">
          <LexmyLogo className="w-48 h-auto mx-auto mb-8" />
          
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Sobre a Lexmy
          </h1>
          
          <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
            A plataforma definitiva para concurseiros jurídicos que buscam aprovação 
            através de tecnologia, comunidade e método científico.
          </p>
        </div>

        {/* Nossa História */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl mb-20">
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="bg-blue-100 text-blue-700 border-blue-200 mb-4">
                  Nossa História
                </Badge>
                <h2 className="text-3xl font-bold text-slate-900 mb-6">
                  Nascemos da necessidade real de concurseiros
                </h2>
                <div className="space-y-4 text-slate-600 leading-relaxed">
                  <p>
                    A Lexmy nasceu da experiência pessoal de concurseiros que enfrentaram as 
                    dificuldades do estudo para concursos públicos na área jurídica. Sabíamos 
                    que existia um caminho melhor.
                  </p>
                  <p>
                    Percebemos que os concurseiros precisavam de mais do que apenas conteúdo - 
                    eles precisavam de uma plataforma completa que integrasse organização, 
                    prática, revisão e comunidade em um único lugar.
                  </p>
                  <p>
                    Assim nasceu a Lexmy: unindo tecnologia de ponta, inteligência artificial 
                    e metodologias comprovadas de aprendizagem para criar a melhor experiência 
                    de estudo para concursos jurídicos.
                  </p>
                </div>
              </div>
              
              <div className="space-y-6">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100/50 p-6 rounded-2xl border border-blue-200">
                  <Target className="w-8 h-8 text-blue-600 mb-3" />
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Nossa Missão</h3>
                  <p className="text-slate-600">
                    Democratizar o acesso a ferramentas de qualidade para concurseiros, 
                    tornando a aprovação mais acessível através da tecnologia.
                  </p>
                </div>
                
                <div className="bg-gradient-to-r from-amber-50 to-amber-100/50 p-6 rounded-2xl border border-amber-200">
                  <Award className="w-8 h-8 text-amber-600 mb-3" />
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Nossa Visão</h3>
                  <p className="text-slate-600">
                    Ser a plataforma número 1 para concurseiros jurídicos no Brasil, 
                    reconhecida pela qualidade, inovação e resultados dos nossos usuários.
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Valores */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <Badge className="bg-purple-100 text-purple-700 border-purple-200 mb-4">
              Nossos Valores
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900">
              O que nos move todos os dias
            </h2>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {valores.map((valor, index) => {
              const Icon = valor.icon;
              return (
                <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">
                      {valor.titulo}
                    </h3>
                    <p className="text-slate-600 text-sm">
                      {valor.descricao}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Diferenciais */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <Badge className="bg-green-100 text-green-700 border-green-200 mb-4">
              Por que Lexmy?
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
              O que nos torna únicos
            </h2>
            <p className="text-slate-600 max-w-2xl mx-auto">
              Não somos apenas mais uma plataforma de estudos. Somos uma solução completa 
              pensada especificamente para concurseiros jurídicos.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {diferenciais.map((diferencial, index) => {
              const Icon = diferencial.icon;
              return (
                <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 group">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 mb-4 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                      <Icon className="w-6 h-6 text-blue-700" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-3">
                      {diferencial.titulo}
                    </h3>
                    <p className="text-slate-600 leading-relaxed">
                      {diferencial.descricao}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Estatísticas */}
        <Card className="bg-gradient-to-r from-blue-600 to-blue-700 border-0 shadow-2xl mb-20">
          <CardContent className="p-12">
            <div className="grid md:grid-cols-4 gap-8 text-center text-white">
              <div>
                <p className="text-4xl md:text-5xl font-bold mb-2">2.847</p>
                <p className="text-blue-100">Concurseiros Ativos</p>
              </div>
              <div>
                <p className="text-4xl md:text-5xl font-bold mb-2">15.234</p>
                <p className="text-blue-100">Horas de Estudo</p>
              </div>
              <div>
                <p className="text-4xl md:text-5xl font-bold mb-2">89%</p>
                <p className="text-blue-100">Taxa de Satisfação</p>
              </div>
              <div>
                <p className="text-4xl md:text-5xl font-bold mb-2">4.5/5</p>
                <p className="text-blue-100">Avaliação Média</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* CTA Final */}
        <div className="text-center">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-2xl inline-block">
            <CardContent className="p-12">
              <Sparkles className="w-16 h-16 mx-auto mb-6 text-amber-500" />
              <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
                Faça parte da revolução
              </h2>
              <p className="text-xl text-slate-600 mb-8 max-w-2xl">
                Junte-se a milhares de concurseiros que já escolheram 
                a Lexmy como parceira na jornada rumo à aprovação.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  onClick={handleIniciar}
                  size="lg"
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-xl px-8 py-6 text-lg gap-2"
                >
                  <Sparkles className="w-5 h-5" />
                  Começar Agora
                </Button>
                <Button
                  onClick={() => window.location.href = createPageUrl("Precos")}
                  size="lg"
                  variant="outline"
                  className="px-8 py-6 text-lg"
                >
                  Ver Preços
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}