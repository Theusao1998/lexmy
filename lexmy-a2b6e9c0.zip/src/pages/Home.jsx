
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  BookOpen,
  Brain,
  Users,
  Timer,
  TrendingUp,
  MessageCircle,
  Headphones,
  Scale,
  Puzzle,
  Award,
  CheckCircle,
  Star,
  ArrowRight,
  Sparkles,
  Target,
  Clock,
  FileText,
  Zap
} from "lucide-react";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import LexmyLogo from "@/components/brand/LexmyLogo";

export default function Home() {
  const handleLogin = async () => {
    try {
      // Redirecionar para login e depois para Dashboard
      const callbackUrl = window.location.origin + createPageUrl("Dashboard");
      await User.loginWithRedirect(callbackUrl);
    } catch (error) {
      console.error('Erro no login:', error);
      try {
        await User.login();
      } catch (fallbackError) {
        console.error('Erro no fallback login:', fallbackError);
      }
    }
  };

  const beneficios = [
    {
      icon: BookOpen,
      titulo: "Biblioteca Jurídica Completa",
      descricao: "Acesse materiais organizados por disciplina: legislação, doutrina, jurisprudência e muito mais.",
      destaque: "Mais de 1.000 materiais"
    },
    {
      icon: Brain,
      titulo: "Treinamento Inteligente",
      descricao: "Sistema de questões adaptativo com correção automática e feedback personalizado.",
      destaque: "IA que aprende com você"
    },
    {
      icon: Timer,
      titulo: "Técnica Pomodoro Integrada",
      descricao: "Temporizador especializado para estudos jurídicos com música de foco e controle de sessões.",
      destaque: "Foco maximizado"
    },
    {
      icon: TrendingUp,
      titulo: "Controle de Progresso",
      descricao: "Dashboards e métricas detalhadas para acompanhar sua evolução e metas.",
      destaque: "Dados que motivam"
    },
    {
      icon: MessageCircle,
      titulo: "Prof. Lex - IA Jurídica", // Changed from "Prof. Jusias" to "Prof. Lex"
      descricao: "Tire dúvidas 24/7 com nossa inteligência artificial especializada em direito.",
      destaque: "Disponível sempre"
    },
    {
      icon: Users,
      titulo: "Comunidade Ativa",
      descricao: "Conecte-se com outros concurseiros, compartilhe experiências e cresça junto.",
      destaque: "Rede de apoio"
    },
    {
      icon: Headphones,
      titulo: "Legislação em Áudio",
      descricao: "Escute leis e códigos durante deslocamentos ou atividades físicas.",
      destaque: "Estude em movimento"
    },
    {
      icon: FileText,
      titulo: "Verticalização de Editais",
      descricao: "Organize seu estudo com base em editais específicos de concursos.",
      destaque: "Estudo direcionado"
    },
    {
      icon: Puzzle,
      titulo: "Jogos Jurídicos",
      descricao: "Aprenda brincando com jogos educativos baseados em conteúdos jurídicos.",
      destaque: "Aprender é divertido"
    }
  ];

  const estatisticas = [
    { numero: "2.847", label: "Concurseiros Ativos", icon: Users },
    { numero: "15.234", label: "Horas de Estudo", icon: Clock },
    { numero: "89%", label: "Taxa de Aprovação", icon: Award },
    { numero: "4.5", label: "Avaliação Média", icon: Star }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
      <style>{`
        :root {
          --primary-blue: #1e3a8a;
          --primary-gold: #f59e0b;
        }

        .glass-effect {
          background: rgba(255, 255, 255, 0.85);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .gradient-text {
          background: linear-gradient(135deg, var(--primary-blue), var(--primary-gold));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .floating-animation {
          animation: floating 3s ease-in-out infinite;
        }

        @keyframes floating {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }

        .pulse-glow {
          animation: pulseGlow 2s ease-in-out infinite;
        }

        @keyframes pulseGlow {
          0%, 100% { box-shadow: 0 0 20px rgba(59, 130, 246, 0.3); }
          50% { box-shadow: 0 0 40px rgba(59, 130, 246, 0.6); }
        }
      `}</style>

      {/* Header/Navbar */}
      <header className="sticky top-0 z-50 w-full glass-effect border-b border-slate-200/60">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <LexmyLogo className="w-40 h-auto" />
            
            <nav className="hidden md:flex items-center gap-6">
              <a 
                href={createPageUrl("Sobre")} 
                className="text-slate-700 hover:text-blue-600 transition-colors font-medium"
              >
                Sobre
              </a>
              <a 
                href={createPageUrl("Precos")} 
                className="text-slate-700 hover:text-blue-600 transition-colors font-medium"
              >
                Preços
              </a>
              <Button 
                onClick={handleLogin}
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Entrar / Cadastrar
              </Button>
            </nav>

            {/* Menu mobile */}
            <div className="md:hidden">
              <Button 
                onClick={handleLogin}
                size="sm"
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Entrar
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-16 md:py-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/5 to-amber-600/5"></div>
        
        <div className="relative max-w-6xl mx-auto px-4 text-center">
          <div className="space-y-8">
            <div className="floating-animation">
              <Badge className="bg-gradient-to-r from-blue-100 to-amber-50 text-blue-800 border-blue-200 px-4 py-2 text-sm">
                🚀 A revolução dos estudos jurídicos chegou
              </Badge>
            </div>
            
            <h2 className="text-4xl md:text-6xl font-bold gradient-text leading-tight">
              Sua aprovação começa na<br />
              <span className="text-slate-900">Comunidade Lexmy</span>
            </h2>
            
            <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto leading-relaxed">
              Plataforma completa de estudos jurídicos com inteligência artificial, 
              comunidade ativa e ferramentas que realmente fazem a diferença na sua preparação.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <Button 
                onClick={handleLogin}
                size="lg" 
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-xl gap-2 pulse-glow px-8 py-4 text-lg"
              >
                <Zap className="w-5 h-5" />
                Começar Agora - É Grátis
              </Button>
              
              <div className="flex items-center gap-2 text-slate-600">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Sem cartão de crédito</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Estatísticas */}
      <section className="py-16 bg-white/50">
        <div className="max-w-6xl mx-auto px-4">
          <div className="text-center mb-12">
            <h3 className="text-2xl md:text-3xl font-bold text-slate-900 mb-4">
              Resultados que comprovam nossa eficácia
            </h3>
            <p className="text-slate-600">Números reais de uma comunidade que cresce e aprova</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {estatisticas.map((stat, index) => {
              const IconComponent = stat.icon;
              return (
                <Card key={index} className="glass-effect border-0 shadow-lg text-center hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-2xl md:text-3xl font-bold text-slate-800 mb-1">{stat.numero}</p>
                    <p className="text-sm text-slate-600">{stat.label}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefícios Principais */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="text-center mb-16">
            <Badge className="bg-blue-50 text-blue-700 border-blue-200 mb-4">
              Tudo que você precisa em um só lugar
            </Badge>
            <h3 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
              Por que escolher a Lexmy?
            </h3>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Ferramentas desenvolvidas especificamente para concurseiros jurídicos, 
              com tecnologia de ponta e foco em resultados.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {beneficios.map((beneficio, index) => {
              const IconComponent = beneficio.icon;
              return (
                <Card key={index} className="glass-effect border-0 shadow-lg hover:shadow-xl transition-all duration-300 group overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-500/5 to-amber-500/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  
                  <CardContent className="relative p-6 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="p-3 bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl group-hover:scale-110 transition-transform duration-300">
                        <IconComponent className="w-6 h-6 text-blue-700" />
                      </div>
                      <Badge variant="outline" className="bg-amber-50                   text-amber-700 border-amber-200 text-xs">
                        {beneficio.destaque}
                      </Badge>
                    </div>
                    
                    <div>
                      <h4 className="text-xl font-bold text-slate-800 mb-2 group-hover:text-blue-700 transition-colors">
                        {beneficio.titulo}
                      </h4>
                      <p className="text-slate-600 leading-relaxed">
                        {beneficio.descricao}
                      </p>
                    </div>
                    
                    <div className="flex items-center text-blue-600 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      Explorar recurso
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-700">
        <div className="max-w-4xl mx-auto px-4 text-center                       text-white">
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-white/20 text-white border-white/30 backdrop-blur-sm">
                <Target className="w-4 h-4 mr-1" />
                Sua aprovação está mais próxima
              </Badge>
              
              <h3 className="text-3xl md:text-5xl font-bold leading-tight">
                Junte-se a milhares de<br />
                concurseiros que já escolheram<br />
                <span className="text-amber-300">o melhor caminho</span>
              </h3>
              
              <p className="text-lg md:text-xl text-blue-100 max-w-2xl mx-auto">
                Comece hoje mesmo e descubra como estudar de forma inteligente, 
                focada e com o apoio de uma comunidade que quer seu sucesso.
              </p>
            </div>

            <div className="space-y-6">
              <Button 
                onClick={handleLogin}
                size="lg" 
                className="bg-white text-blue-700 hover:bg-gray-50 shadow-xl gap-2 px-10 py-5 text-lg font-semibold"
              >
                <Sparkles className="w-5 h-5" />
                Entrar na Comunidade Lexmy
              </Button>
              
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-blue-100 text-sm">
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-300" />
                  100% Gratuito para começar
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-300" />
                  Sem compromisso
                </div>
                <div className="flex items-center gap-1">
                  <CheckCircle className="w-4 h-4 text-green-300" />
                  Acesso imediato
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            {/* Coluna 1 - Logo e Descrição */}
            <div>
              <LexmyLogo className="w-32 h-auto mb-4" />
              <p className="text-slate-400 text-sm">
                A plataforma completa para concurseiros jurídicos que buscam a aprovação.
              </p>
            </div>

            {/* Coluna 2 - Links */}
            <div>
              <h3 className="font-semibold text-white mb-4">Links Rápidos</h3>
              <ul className="space-y-2 text-slate-400                   text-sm">
                <li>
                  <a href={createPageUrl("Sobre")} className="hover:text-white transition-colors">
                    Sobre Nós
                  </a>
                </li>
                <li>
                  <a href={createPageUrl("Precos")} className="hover:text-white transition-colors">
                    Preços
                  </a>
                </li>
                <li>
                  <a onClick={handleLogin} className="hover:text-white transition-colors cursor-pointer">
                    Entrar
                  </a>
                </li>
              </ul>
            </div>

            {/* Coluna 3 - CTA */}
            <div>
              <h3 className="font-semibold text-white mb-4">Comece Agora</h3>
              <p className="text-slate-400 text-sm mb-4">
                14 dias de teste gratuito. Sem cartão de crédito necessário.
              </p>
              <Button 
                onClick={handleLogin}
                className="w-full bg-blue-600 hover:bg-blue-700 gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Iniciar Teste Gratuito
              </Button>
            </div>
          </div>

          <div className="border-t border-slate-800 pt-6 text-center">
            <p className="text-slate-500 text-sm">
              © 2024 Lexmy. Todos os direitos reservados. • Estudos jurídicos revolucionários.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
