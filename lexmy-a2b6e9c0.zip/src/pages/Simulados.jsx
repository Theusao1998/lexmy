import React, { useState, useEffect, useMemo } from 'react';
import { Simulado } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  FileText,
  Clock,
  Target,
  Play,
  ArrowLeft,
  CheckCircle2,
  XCircle,
  Loader2
} from 'lucide-react';
import { toast } from 'sonner';
import { parseSimulado } from '@/api/functions';

export default function SimuladosPage() {
  const [simulados, setSimulados] = useState([]);
  const [loading, setLoading] = useState(true);

  // Estados para visualização do simulado
  const [simuladoAtivo, setSimuladoAtivo] = useState(null);
  const [questoesParsed, setQuestoesParsed] = useState([]);
  const [respostasUsuario, setRespostasUsuario] = useState({});
  const [simuladoFinalizado, setSimuladoFinalizado] = useState(false);
  const [carregandoParse, setCarregandoParse] = useState(false);

  useEffect(() => {
    carregarSimulados();
  }, []);

  const carregarSimulados = async () => {
    setLoading(true);
    try {
      // Buscar apenas simulados publicados
      const simuladosData = await Simulado.filter({ status: 'publicado' }, '-created_date', 100);
      setSimulados(simuladosData);
    } catch (error) {
      console.error('Erro ao carregar simulados:', error);
      toast.error('Erro ao carregar simulados.');
    } finally {
      setLoading(false);
    }
  };

  const handleIniciarSimulado = async (simulado) => {
    setCarregandoParse(true);
    try {
      const { data } = await parseSimulado({ conteudo: simulado.conteudo_puro });
      
      if (!data.questoes || data.questoes.length === 0) {
        toast.error('Nenhuma questão válida encontrada no simulado.');
        return;
      }

      setQuestoesParsed(data.questoes);
      setSimuladoAtivo(simulado);
      setRespostasUsuario({});
      setSimuladoFinalizado(false);
    } catch (error) {
      console.error('Erro ao processar simulado:', error);
      toast.error('Erro ao carregar simulado: ' + (error.message || 'Erro desconhecido'));
    } finally {
      setCarregandoParse(false);
    }
  };

  const handleSelecionarResposta = (numeroQuestao, alternativaIndex) => {
    setRespostasUsuario(prev => ({
      ...prev,
      [numeroQuestao]: alternativaIndex
    }));
  };

  const handleFinalizarSimulado = () => {
    if (Object.keys(respostasUsuario).length < questoesParsed.length) {
      if (!confirm('Você não respondeu todas as questões. Deseja finalizar mesmo assim?')) {
        return;
      }
    }
    setSimuladoFinalizado(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const calcularResultado = useMemo(() => {
    if (!simuladoFinalizado || !questoesParsed.length) return null;

    let acertos = 0;
    let erros = 0;

    questoesParsed.forEach(questao => {
      const respostaUsuario = respostasUsuario[questao.numero];
      if (respostaUsuario !== undefined) {
        if (respostaUsuario === questao.gabarito) {
          acertos++;
        } else {
          erros++;
        }
      } else {
        erros++;
      }
    });

    const total = questoesParsed.length;
    const percentual = Math.round((acertos / total) * 100);

    return { acertos, erros, total, percentual };
  }, [simuladoFinalizado, questoesParsed, respostasUsuario]);

  const scrollParaQuestao = (numero) => {
    const elemento = document.getElementById(`questao-${numero}`);
    if (elemento) {
      elemento.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  // Tela de visualização do simulado ativo
  if (simuladoAtivo) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
        {/* Header fixo */}
        <div className="sticky top-0 z-10 bg-white/80 backdrop-blur-xl border-b border-slate-200/60 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 md:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    if (!simuladoFinalizado || confirm('Deseja realmente sair do simulado?')) {
                      setSimuladoAtivo(null);
                      setQuestoesParsed([]);
                      setRespostasUsuario({});
                      setSimuladoFinalizado(false);
                    }
                  }}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
                <div>
                  <h1 className="text-xl font-bold text-slate-800">{simuladoAtivo.titulo}</h1>
                  {simuladoAtivo.tempo_limite_minutos && !simuladoFinalizado && (
                    <p className="text-sm text-slate-600 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Tempo limite: {simuladoAtivo.tempo_limite_minutos} minutos
                    </p>
                  )}
                </div>
              </div>
              
              {!simuladoFinalizado && (
                <Button onClick={handleFinalizarSimulado} className="gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Finalizar e Corrigir
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-4 md:p-8 flex gap-6">
          {/* Navegação lateral por questões */}
          <div className="hidden lg:block sticky top-24 h-fit">
            <Card className="w-48 bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Questões</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-5 gap-2">
                {questoesParsed.map((questao) => {
                  const respondida = respostasUsuario[questao.numero] !== undefined;
                  const correta = simuladoFinalizado && respostasUsuario[questao.numero] === questao.gabarito;
                  const incorreta = simuladoFinalizado && respostasUsuario[questao.numero] !== undefined && respostasUsuario[questao.numero] !== questao.gabarito;
                  
                  return (
                    <button
                      key={questao.numero}
                      onClick={() => scrollParaQuestao(questao.numero)}
                      className={`
                        w-10 h-10 rounded-lg border-2 font-semibold text-sm transition-all
                        ${respondida && !simuladoFinalizado ? 'bg-blue-100 border-blue-400 text-blue-700' : ''}
                        ${!respondida && !simuladoFinalizado ? 'bg-white border-slate-300 text-slate-600 hover:border-blue-300' : ''}
                        ${correta ? 'bg-green-100 border-green-400 text-green-700' : ''}
                        ${incorreta ? 'bg-red-100 border-red-400 text-red-700' : ''}
                      `}
                    >
                      {questao.numero}
                    </button>
                  );
                })}
              </CardContent>
            </Card>
          </div>

          {/* Conteúdo principal */}
          <div className="flex-1 space-y-8">
            {/* Placar de resultados */}
            {simuladoFinalizado && calcularResultado && (
              <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="text-2xl flex items-center gap-3">
                    <Target className="w-8 h-8 text-blue-600" />
                    Resultado do Simulado
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                    <div className="text-center p-4 bg-white rounded-xl">
                      <p className="text-sm text-slate-600 mb-1">Total</p>
                      <p className="text-3xl font-bold text-slate-800">{calcularResultado.total}</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-xl">
                      <p className="text-sm text-green-600 mb-1">Acertos</p>
                      <p className="text-3xl font-bold text-green-700">{calcularResultado.acertos}</p>
                    </div>
                    <div className="text-center p-4 bg-red-50 rounded-xl">
                      <p className="text-sm text-red-600 mb-1">Erros</p>
                      <p className="text-3xl font-bold text-red-700">{calcularResultado.erros}</p>
                    </div>
                    <div className="text-center p-4 bg-blue-50 rounded-xl">
                      <p className="text-sm text-blue-600 mb-1">Aproveitamento</p>
                      <p className="text-3xl font-bold text-blue-700">{calcularResultado.percentual}%</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Questões */}
            {questoesParsed.map((questao) => {
              const respostaUsuario = respostasUsuario[questao.numero];
              const respondida = respostaUsuario !== undefined;
              
              return (
                <Card 
                  key={questao.numero} 
                  id={`questao-${questao.numero}`}
                  className="bg-white/80 backdrop-blur-sm border-0 shadow-xl scroll-mt-24"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-3">
                        <Badge variant="outline" className="text-base px-3 py-1">
                          {questao.numero}
                        </Badge>
                        <div>
                          <Badge className="mb-2 bg-blue-100 text-blue-700 border-blue-200">
                            {questao.disciplina}
                          </Badge>
                        </div>
                      </div>
                      {simuladoFinalizado && (
                        <div>
                          {respostaUsuario === questao.gabarito ? (
                            <Badge className="bg-green-100 text-green-700 border-green-200 gap-1">
                              <CheckCircle2 className="w-4 h-4" />
                              Correta
                            </Badge>
                          ) : (
                            <Badge className="bg-red-100 text-red-700 border-red-200 gap-1">
                              <XCircle className="w-4 h-4" />
                              Incorreta
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Enunciado */}
                    <div className="p-4 bg-gradient-to-r from-slate-50 to-blue-50/30 rounded-lg border border-slate-200">
                      <p className="text-base leading-relaxed text-slate-800">
                        {questao.enunciado}
                      </p>
                    </div>

                    {/* Alternativas */}
                    <div className="space-y-3">
                      {questao.alternativas.map((alternativa, altIdx) => {
                        const selecionada = respostaUsuario === altIdx;
                        const correta = simuladoFinalizado && altIdx === questao.gabarito;
                        const incorreta = simuladoFinalizado && selecionada && altIdx !== questao.gabarito;
                        
                        return (
                          <button
                            key={altIdx}
                            onClick={() => !simuladoFinalizado && handleSelecionarResposta(questao.numero, altIdx)}
                            disabled={simuladoFinalizado}
                            className={`
                              w-full text-left p-4 rounded-lg border-2 transition-all
                              ${!simuladoFinalizado && 'hover:border-blue-300 hover:bg-blue-50/30 cursor-pointer'}
                              ${selecionada && !simuladoFinalizado ? 'bg-blue-100 border-blue-400' : ''}
                              ${!selecionada && !simuladoFinalizado ? 'bg-white border-slate-200' : ''}
                              ${correta ? 'bg-green-100 border-green-400' : ''}
                              ${incorreta ? 'bg-red-100 border-red-400' : ''}
                              ${simuladoFinalizado ? 'cursor-default' : ''}
                            `}
                          >
                            <div className="flex items-start gap-3">
                              <span className={`
                                w-7 h-7 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0
                                ${selecionada && !simuladoFinalizado ? 'bg-blue-500 text-white' : ''}
                                ${!selecionada && !simuladoFinalizado ? 'bg-slate-200 text-slate-600' : ''}
                                ${correta ? 'bg-green-500 text-white' : ''}
                                ${incorreta ? 'bg-red-500 text-white' : ''}
                                ${simuladoFinalizado && !correta && !incorreta ? 'bg-slate-200 text-slate-600' : ''}
                              `}>
                                {String.fromCharCode(65 + altIdx)}
                              </span>
                              <span className="flex-1 pt-0.5">{alternativa}</span>
                              {simuladoFinalizado && correta && (
                                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                              )}
                              {simuladoFinalizado && incorreta && (
                                <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                              )}
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Fundamentação */}
                    {simuladoFinalizado && questao.fundamentacao && (
                      <div className="p-4 bg-amber-50 border border-amber-200 rounded-lg">
                        <h4 className="font-semibold text-amber-900 mb-2 flex items-center gap-2">
                          <FileText className="w-4 h-4" />
                          Fundamentação
                        </h4>
                        <p className="text-amber-800 text-sm leading-relaxed whitespace-pre-wrap">
                          {questao.fundamentacao}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}

            {/* Botão de finalizar no rodapé */}
            {!simuladoFinalizado && (
              <div className="flex justify-center py-8">
                <Button onClick={handleFinalizarSimulado} size="lg" className="gap-2">
                  <CheckCircle2 className="w-5 h-5" />
                  Finalizar e Corrigir Simulado
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Tela de carregamento do parse
  if (carregandoParse) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-slate-600">Preparando simulado...</p>
        </div>
      </div>
    );
  }

  // Tela principal com lista de simulados
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center md:text-left">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Simulados
          </h1>
          <p className="text-slate-600 mt-1 max-w-2xl">
            Pratique com simulados completos e avalie seu desempenho
          </p>
        </div>

        {/* Lista de simulados */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : simulados.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {simulados.map(simulado => (
              <Card 
                key={simulado.id} 
                className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all duration-300 group"
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="p-3 bg-gradient-to-br from-blue-100 to-blue-200 rounded-2xl">
                      <FileText className="w-6 h-6 text-blue-600" />
                    </div>
                    <Badge className="bg-green-100 text-green-700 border-green-200">
                      Publicado
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardTitle className="text-lg leading-tight mb-2">{simulado.titulo}</CardTitle>
                  <CardDescription className="line-clamp-2 mb-4">
                    {simulado.descricao || 'Sem descrição'}
                  </CardDescription>
                  
                  {simulado.disciplina && (
                    <Badge variant="outline" className="mb-4">
                      {simulado.disciplina}
                    </Badge>
                  )}

                  {simulado.tempo_limite_minutos && (
                    <div className="flex items-center gap-2 text-sm text-slate-600 mb-4">
                      <Clock className="w-4 h-4" />
                      {simulado.tempo_limite_minutos} minutos
                    </div>
                  )}

                  <Button
                    onClick={() => handleIniciarSimulado(simulado)}
                    className="w-full gap-2"
                  >
                    <Play className="w-4 h-4" />
                    Iniciar Simulado
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <FileText className="w-16 h-16 mx-auto mb-6 text-slate-400" />
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Nenhum simulado disponível
              </h3>
              <p className="text-slate-600">
                Aguarde os administradores adicionarem simulados.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}