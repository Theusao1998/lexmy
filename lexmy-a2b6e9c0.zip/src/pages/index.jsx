import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Treinamento from "./Treinamento";

import Temporizador from "./Temporizador";

import Edital from "./Edital";

import Comunidade from "./Comunidade";

import Home from "./Home";

import LegislacaoAudio from "./LegislacaoAudio";

import Jogos from "./Jogos";

import Perfil from "./Perfil";

import Discursivas from "./Discursivas";

import Questoes from "./Questoes";

import Biblioteca from "./Biblioteca";

import ProfLex from "./ProfLex";

import Planner from "./Planner";

import Simulados from "./Simulados";

import Precos from "./Precos";

import Sobre from "./Sobre";

import Administracao from "./Administracao";

import AssistenteSeguranca from "./AssistenteSeguranca";

import MapasMentais from "./MapasMentais";

import AtivarPlano from "./AtivarPlano";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Treinamento: Treinamento,
    
    Temporizador: Temporizador,
    
    Edital: Edital,
    
    Comunidade: Comunidade,
    
    Home: Home,
    
    LegislacaoAudio: LegislacaoAudio,
    
    Jogos: Jogos,
    
    Perfil: Perfil,
    
    Discursivas: Discursivas,
    
    Questoes: Questoes,
    
    Biblioteca: Biblioteca,
    
    ProfLex: ProfLex,
    
    Planner: Planner,
    
    Simulados: Simulados,
    
    Precos: Precos,
    
    Sobre: Sobre,
    
    Administracao: Administracao,
    
    AssistenteSeguranca: AssistenteSeguranca,
    
    MapasMentais: MapasMentais,
    
    AtivarPlano: AtivarPlano,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Treinamento" element={<Treinamento />} />
                
                <Route path="/Temporizador" element={<Temporizador />} />
                
                <Route path="/Edital" element={<Edital />} />
                
                <Route path="/Comunidade" element={<Comunidade />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/LegislacaoAudio" element={<LegislacaoAudio />} />
                
                <Route path="/Jogos" element={<Jogos />} />
                
                <Route path="/Perfil" element={<Perfil />} />
                
                <Route path="/Discursivas" element={<Discursivas />} />
                
                <Route path="/Questoes" element={<Questoes />} />
                
                <Route path="/Biblioteca" element={<Biblioteca />} />
                
                <Route path="/ProfLex" element={<ProfLex />} />
                
                <Route path="/Planner" element={<Planner />} />
                
                <Route path="/Simulados" element={<Simulados />} />
                
                <Route path="/Precos" element={<Precos />} />
                
                <Route path="/Sobre" element={<Sobre />} />
                
                <Route path="/Administracao" element={<Administracao />} />
                
                <Route path="/AssistenteSeguranca" element={<AssistenteSeguranca />} />
                
                <Route path="/MapasMentais" element={<MapasMentais />} />
                
                <Route path="/AtivarPlano" element={<AtivarPlano />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}