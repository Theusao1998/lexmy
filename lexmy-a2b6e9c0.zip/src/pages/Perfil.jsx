
import React, { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch"; // Added Switch component
import {
  User,
  Camera,
  Save,
  Mail,
  Calendar,
  Shield,
  Check,
  AlertCircle,
  Edit,
  LogOut,
  CreditCard,
  Clock,
  Zap,
  XCircle,
  ArrowRight,
  Bell, // Added Bell icon
  MessageSquare, // Added MessageSquare icon
  Sparkles, // Added Sparkles icon
  Target, // NEW: Added Target icon
  BookOpen, // NEW: Added BookOpen icon
  Brain, // NEW: Added Brain icon
  TrendingUp, // NEW: Added TrendingUp icon
  Award, // NEW: Added Award icon
  Flame, // NEW: Added Flame icon
  Timer, // NEW: Added Timer icon
  CheckCircle2, // NEW: Added CheckCircle2 icon
  BarChart3, // NEW: Added BarChart3 icon
  Plus, // NEW: Added Plus icon
  Minus, // NEW: Added Minus icon
  ChevronUp, // NEW: Added ChevronUp icon
  ChevronDown // NEW: Added ChevronDown icon
} from "lucide-react";
import { User as UserEntity } from "@/api/entities";
import { Assinatura } from "@/api/entities";
import { UploadFile } from "@/api/integrations";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function Perfil() {
  const navigate = useNavigate();
  const [usuario, setUsuario] = useState(null);
  const [assinatura, setAssinatura] = useState(null);
  const [loading, setLoading] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [uploadandoFoto, setUploadandoFoto] = useState(false);
  const [cancelando, setCancelando] = useState(false);
  const [mensagem, setMensagem] = useState({ tipo: '', texto: '' });
  const [dadosEdicao, setDadosEdicao] = useState({
    nome: '',
    nick: '',
    telefone: '',
    cidade: '',
    estado: '',
    profissao: '',
    objetivo_concurso: '',
    bio: '',
    foto_perfil: ''
  });

  // New state for daily planner reminders
  const [lembretesConfig, setLembretesConfig] = useState({
    ativado: false,
    horario: '07:00',
    via: 'email'
  });

  // NEW: Estado para processar checkout
  const [processandoCheckout, setProcessandoCheckout] = useState(false);
  // NEW: Estado para armazenar dias restantes de teste
  const [diasRestantes, setDiasRestantes] = useState(null);

  const fileInputRef = useRef(null);

  // Cache for user data to reduce API calls and prevent rate limits
  const userCache = useRef({ data: null, timestamp: 0 });
  const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

  useEffect(() => {
    carregarDadosUsuario();
  }, []);

  // NOVA FUNÇÃO: Separar a busca de assinatura para poder reutilizá-la
  const buscarAssinatura = async (userEmail) => {
    try {
      console.log('[Perfil] Buscando assinaturas para:', userEmail);
      const assinaturas = await base44.entities.Assinatura.filter({
        user_email: userEmail
      });

      console.log('[Perfil] Assinaturas encontradas:', assinaturas.length, assinaturas);

      if (assinaturas.length > 0) {
        // Prioriza uma assinatura ativa ou em teste
        const assinaturaValida = assinaturas.find(a =>
          a.status === 'ativo' || a.status === 'teste'
        );

        const assinaturaParaUsar = assinaturaValida || assinaturas[0];
        console.log('[Perfil] Assinatura selecionada:', assinaturaParaUsar);
        setAssinatura(assinaturaParaUsar);

        // Calcular dias restantes se for teste
        if (assinaturaParaUsar.status === 'teste' && assinaturaParaUsar.data_teste_fim) {
          const dias = calcularDiasRestantes(assinaturaParaUsar.data_teste_fim);
          console.log('[Perfil] Dias restantes do teste:', dias);
          setDiasRestantes(dias);
        } else {
          setDiasRestantes(null);
        }
      } else {
        console.log('[Perfil] Nenhuma assinatura encontrada');
        setAssinatura(null);
        setDiasRestantes(null);
      }
    } catch (assError) {
      console.error('[Perfil] Erro ao carregar assinatura:', assError);
      setAssinatura(null);
      setDiasRestantes(null);
    }
  };


  const carregarDadosUsuario = async () => {
    setLoading(true);
    const now = Date.now();

    // Check if data is available in cache and not expired
    if (userCache.current.data && (now - userCache.current.timestamp < CACHE_TTL_MS)) {
      const cachedData = userCache.current.data;
      setUsuario(cachedData);
      setDadosEdicao({
        nome: cachedData.nome || cachedData.full_name || '',
        nick: cachedData.nick || '',
        telefone: cachedData.telefone || '',
        cidade: cachedData.cidade || '',
        estado: cachedData.estado || '',
        profissao: cachedData.profissao || '',
        objetivo_concurso: cachedData.objetivo_concurso || '',
        bio: cachedData.bio || '',
        foto_perfil: cachedData.foto_perfil || ''
      });
      setLembretesConfig({
        ativado: cachedData.lembretes_planner?.ativado || false,
        horario: cachedData.lembretes_planner?.horario || '07:00',
        via: cachedData.lembretes_planner?.via || 'email'
      });
      
      // CORREÇÃO: Mesmo usando cache para dados do usuário, SEMPRE buscar assinaturas frescas
      console.log('[Perfil] Usando cache para dados do usuário, mas buscando assinaturas frescas');
      await buscarAssinatura(cachedData.email);
      
      setLoading(false);
      return;
    }

    try {
      const dadosUsuario = await UserEntity.me();
      console.log('[Perfil] Dados do usuário carregados:', dadosUsuario.email);
      setUsuario(dadosUsuario);

      const novosDados = {
        nome: dadosUsuario.nome || dadosUsuario.full_name || '',
        nick: dadosUsuario.nick || '',
        telefone: dadosUsuario.telefone || '',
        cidade: dadosUsuario.cidade || '',
        estado: dadosUsuario.estado || '',
        profissao: dadosUsuario.profissao || '',
        objetivo_concurso: dadosUsuario.objetivo_concurso || '',
        bio: dadosUsuario.bio || '',
        foto_perfil: dadosUsuario.foto_perfil || ''
      };

      setDadosEdicao(novosDados);

      // Load reminder configuration
      setLembretesConfig({
        ativado: dadosUsuario.lembretes_planner?.ativado || false,
        horario: dadosUsuario.lembretes_planner?.horario || '07:00',
        via: dadosUsuario.lembretes_planner?.via || 'email'
      });

      userCache.current = { data: dadosUsuario, timestamp: now };

      // Carregar assinatura do usuário
      await buscarAssinatura(dadosUsuario.email);

    } catch (error) {
      console.error('[Perfil] Erro ao carregar dados do usuário:', error);

      if (error.response?.status === 401 || error.message?.includes('401') || error.message?.includes('unauthorized')) {
        setMensagem({ tipo: 'erro', texto: 'Sessão expirada. Redirecionando para a página inicial...' });
        setTimeout(() => {
          navigate(createPageUrl("Home"));
        }, 2000);
      } else {
        setMensagem({ tipo: 'erro', texto: 'Erro ao carregar seus dados. Tente recarregar a página.' });
      }
    }
    setLoading(false);
  };

  const handleInputChange = (campo, valor) => {
    setDadosEdicao(prev => ({ ...prev, [campo]: valor }));
  };

  const handleUploadFoto = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setMensagem({ tipo: 'erro', texto: 'Por favor, selecione apenas arquivos de imagem.' });
      return;
    }

    if (file.size > 5 * 1024 * 1024) {
      setMensagem({ tipo: 'erro', texto: 'A imagem deve ter no máximo 5MB.' });
      return;
    }

    setUploadandoFoto(true);
    try {
      const { file_url } = await UploadFile({ file });
      setDadosEdicao(prev => ({ ...prev, foto_perfil: file_url }));
      setMensagem({ tipo: 'sucesso', texto: 'Foto carregada com sucesso! Clique em "Salvar Alterações" para confirmar.' });
    } catch (error) {
      console.error('Erro no upload da foto:', error);
      setMensagem({ tipo: 'erro', texto: 'Erro ao fazer upload da foto.' });
    }
    setUploadandoFoto(false);

    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const salvarAlteracoes = async () => {
    setSalvando(true);
    setMensagem({ tipo: '', texto: '' });

    try {
      const dadosParaSalvar = {};

      if (dadosEdicao.nome?.trim()) dadosParaSalvar.nome = dadosEdicao.nome.trim();
      if (dadosEdicao.nick?.trim()) dadosParaSalvar.nick = dadosEdicao.nick.trim();
      if (dadosEdicao.telefone?.trim()) dadosParaSalvar.telefone = dadosEdicao.telefone.trim();
      if (dadosEdicao.cidade?.trim()) dadosParaSalvar.cidade = dadosEdicao.cidade.trim();
      if (dadosEdicao.estado?.trim()) dadosParaSalvar.estado = dadosEdicao.estado.trim();
      if (dadosEdicao.profissao?.trim()) dadosParaSalvar.profissao = dadosEdicao.profissao.trim();
      if (dadosEdicao.objetivo_concurso?.trim()) dadosParaSalvar.objetivo_concurso = dadosEdicao.objetivo_concurso.trim();
      if (dadosEdicao.bio?.trim()) dadosParaSalvar.bio = dadosEdicao.bio.trim();
      if (dadosEdicao.foto_perfil?.trim()) dadosParaSalvar.foto_perfil = dadosEdicao.foto_perfil.trim();

      // Include lembretes config in data to save
      dadosParaSalvar.lembretes_planner = lembretesConfig;

      if (Object.keys(dadosParaSalvar).length === 0) {
        setMensagem({ tipo: 'erro', texto: 'Nenhuma alteração foi feita.' });
        setSalvando(false);
        return;
      }

      const resultado = await UserEntity.updateMyUserData(dadosParaSalvar);

      userCache.current = { data: null, timestamp: 0 }; // Invalidate cache

      await new Promise(resolve => setTimeout(resolve, 800)); // Simulate network delay
      await carregarDadosUsuario(); // Reload user data to reflect changes

      setMensagem({ tipo: 'sucesso', texto: 'Perfil atualizado com sucesso!' });

    } catch (error) {
      console.error('Erro ao salvar:', error);

      let errorMessage = 'Erro ao salvar alterações.';

      if (error.response?.status === 400) {
        errorMessage = 'Dados inválidos. Verifique os campos preenchidos.';
      } else if (error.response?.status === 401) {
        errorMessage = 'Sessão expirada. Faça login novamente.';
      } else if (error.response?.status === 429) {
        errorMessage = 'Muitas tentativas. Aguarde um momento e tente novamente.';
      } else if (error.message) {
        errorMessage = `Erro: ${error.message}`;
      }

      setMensagem({ tipo: 'erro', texto: errorMessage });
    }

    setSalvando(false);
  };

  const handleCancelarAssinatura = async () => {
    if (!confirm('Tem certeza que deseja cancelar sua assinatura? Você perderá acesso às funcionalidades Pro ao final do ciclo atual.')) {
      return;
    }

    setCancelando(true);
    setMensagem({ tipo: '', texto: '' });
    try {
      const { data: response } = await base44.functions.invoke('cancelSubscription');

      if (response.success) {
        setMensagem({ tipo: 'sucesso', texto: 'Assinatura cancelada com sucesso. Você terá acesso até o final do período pago.' });
        
        // CORREÇÃO: Invalidar cache e recarregar dados
        userCache.current = { data: null, timestamp: 0 };
        await carregarDadosUsuario();
      } else {
        throw new Error(response.error || 'Erro desconhecido ao cancelar.');
      }
    } catch (error) {
      console.error('[Perfil] Erro ao cancelar assinatura:', error);

      let errorMessage = 'Erro ao cancelar assinatura. Tente novamente.';
      if (error.response?.data?.error) {
        errorMessage = error.response.data.error;
      } else if (error.message) {
        errorMessage = error.message;
      }
      setMensagem({ tipo: 'erro', texto: errorMessage });
    } finally {
      setCancelando(false);
    }
  };

  // NOVO: Função para iniciar checkout com Mercado Pago
  const handleIniciarCheckout = async (plano) => {
    setProcessandoCheckout(true);
    try {
      const { data: response } = await base44.functions.invoke('createMercadoPagoCheckout', {
        plano: plano
      });

      if (response.init_point) {
        window.location.href = response.init_point;
      } else {
        throw new Error('URL de checkout não recebida');
      }
    } catch (error) {
      console.error('[Perfil] Erro ao iniciar checkout:', error);

      if (error.response?.status === 401 || (error.message && error.message.includes('401'))) {
        alert('Sessão expirada. Por favor, faça login novamente.');
      } else {
        alert('Erro ao processar pagamento. Por favor, tente novamente.');
      }
    } finally {
      setProcessandoCheckout(false);
    }
  };


  const handleLogout = async () => {
    if (confirm('Deseja realmente sair da sua conta?')) {
      try {
        await UserEntity.logout();
        window.location.href = createPageUrl("Home");
      } catch (error) {
        console.error('Erro no logout:', error);
        window.location.href = createPageUrl("Home"); // Redirect anyway to clear session if error occurs
      }
    }
  };

  const calcularDiasRestantes = (dataFim) => {
    if (!dataFim) return 0;
    const hoje = new Date();
    const fim = new Date(dataFim);

    // Zera o componente de tempo para comparar apenas as datas
    hoje.setHours(0, 0, 0, 0);
    fim.setHours(0, 0, 0, 0);

    const diff = fim.getTime() - hoje.getTime();
    return Math.max(0, Math.ceil(diff / (1000 * 60 * 60 * 24)));
  };

  const getStatusBadge = (status) => {
    const configs = {
      ativo: { color: 'bg-green-100 text-green-700 border-green-200', label: 'Ativo' },
      teste: { color: 'bg-blue-100 text-blue-700 border-blue-200', label: 'Teste Gratuito' },
      cancelado: { color: 'bg-red-100 text-red-700 border-red-200', label: 'Cancelado' },
      expirado: { color: 'bg-gray-100 text-gray-700 border-gray-200', label: 'Expirado' },
      pendente: { color: 'bg-yellow-100 text-yellow-700 border-yellow-200', label: 'Pendente' }
    };
    return configs[status] || configs.pendente;
  };

  const getPlanoBadge = (plano) => {
    const configs = {
      mensal: 'Mensal',
      semestral: 'Semestral',
      anual: 'Anual',
      teste: 'Teste Gratuito'
    };
    return configs[plano] || plano;
  };


  useEffect(() => {
    if (mensagem.texto) {
      const timer = setTimeout(() => {
        setMensagem({ tipo: '', texto: '' });
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [mensagem]);

  const recursosPlanoPro = [
    { icon: Target, texto: 'Metas de estudo personalizadas' },
    { icon: BookOpen, texto: 'Acesso a todo conteúdo premium' },
    { icon: Brain, texto: 'Técnicas de estudo avançadas' },
    { icon: TrendingUp, texto: 'Relatórios de progresso detalhados' },
    { icon: Award, texto: 'Desafios e gamificação exclusivos' },
    { icon: Flame, texto: 'Priorização inteligente de conteúdo' },
    { icon: Timer, texto: 'Gerenciamento de tempo otimizado' },
    { icon: CheckCircle2, texto: 'Simulados ilimitados com IA' },
    { icon: BarChart3, texto: 'Análise de desempenho comparativa' },
    { icon: Plus, texto: 'Conteúdo extra e bônus mensais' },
    { icon: MessageSquare, texto: 'Suporte prioritário via WhatsApp' },
    { icon: Bell, texto: 'Lembretes inteligentes de estudo' },
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl animate-pulse">
            <CardContent className="p-12 text-center">
              <div className="w-24 h-24 bg-slate-200 rounded-full mx-auto mb-6"></div>
              <div className="h-6 bg-slate-200 rounded w-1/3 mx-auto mb-4"></div>
              <div className="h-4 bg-slate-200 rounded w-1/2 mx-auto"></div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">

        <div className="text-center space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Meu Perfil
          </h1>
          <p className="text-slate-600">
            Gerencie suas informações pessoais e assinatura
          </p>
        </div>

        {mensagem.texto && (
          <Card className={`border-0 shadow-lg ${
            mensagem.tipo === 'sucesso'
              ? 'bg-green-50 border-green-200'
              : 'bg-red-50 border-red-200'
          }`}>
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                {mensagem.tipo === 'sucesso' ? (
                  <Check className="w-5 h-5 text-green-600" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-600" />
                )}
                <span className={`font-medium ${
                  mensagem.tipo === 'sucesso' ? 'text-green-700' : 'text-red-700'
                }`}>
                  {mensagem.texto}
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="perfil" className="w-full">
          {/* Changed grid-cols-2 to grid-cols-3 to accommodate the new "Lembretes" tab */}
          <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="perfil" className="gap-2">
              <User className="w-4 h-4" />
              Perfil
            </TabsTrigger>
            <TabsTrigger value="assinatura" className="gap-2">
              <CreditCard className="w-4 h-4" />
              Assinatura
            </TabsTrigger>
            {/* New Tab Trigger for Lembretes */}
            <TabsTrigger value="lembretes" className="gap-2">
              <Bell className="w-4 h-4" />
              Lembretes
            </TabsTrigger>
          </TabsList>

          <TabsContent value="perfil" className="space-y-6 mt-6">
            <div className="grid lg:grid-cols-3 gap-8">

              <div className="space-y-6">
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardContent className="p-6 text-center space-y-6">

                    <div className="relative inline-block">
                      <div className="w-32 h-32 relative">
                        {dadosEdicao.foto_perfil ? (
                          <img
                            src={dadosEdicao.foto_perfil}
                            alt="Foto de perfil"
                            className="w-full h-full object-cover rounded-full border-4 border-white shadow-lg"
                            onError={(e) => {
                              e.target.style.display = 'none';
                              const fallbackDiv = document.querySelector('.fallback-avatar');
                              if (fallbackDiv) {
                                fallbackDiv.style.display = 'flex';
                              }
                            }}
                            onLoad={() => {
                              const fallbackDiv = document.querySelector('.fallback-avatar');
                              if (fallbackDiv) {
                                fallbackDiv.style.display = 'none';
                              }
                            }}
                          />
                        ) : null}

                        <div
                          className="fallback-avatar w-full h-full bg-gradient-to-br from-blue-500 to-blue-600 rounded-full border-4 border-white shadow-lg flex items-center justify-center absolute inset-0"
                          style={{ display: dadosEdicao.foto_perfil ? 'none' : 'flex' }}
                        >
                          <User className="w-16 h-16 text-white" />
                        </div>

                        <div className="absolute bottom-0 right-0">
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            disabled={uploadandoFoto}
                            className="w-8 h-8 bg-blue-600 hover:bg-blue-700 text-white rounded-full flex items-center justify-center shadow-lg transition-colors disabled:opacity-50"
                            title="Upload foto"
                          >
                            {uploadandoFoto ? (
                              <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-white"></div>
                            ) : (
                              <Camera className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </div>

                      <input
                        ref={fileInputRef}
                        type="file"
                        accept="image/*"
                        onChange={handleUploadFoto}
                        className="hidden"
                      />
                    </div>

                    <div>
                      <h2 className="text-xl font-bold text-slate-800">
                        {usuario?.nome || usuario?.full_name || 'Sem nome'}
                      </h2>
                      {usuario?.nick && (
                        <p className="text-blue-600 font-medium">@{usuario.nick}</p>
                      )}
                      <p className="text-slate-600 flex items-center justify-center gap-1 mt-1">
                        <Mail className="w-4 h-4" />
                        {usuario?.email}
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Badge className="bg-blue-100 text-blue-700 border-blue-200 gap-1">
                        <Shield className="w-3 h-3" />
                        {usuario?.role === 'admin' ? 'Administrador' : 'Estudante'}
                      </Badge>
                      <div className="text-xs text-slate-500 flex items-center justify-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Membro desde {new Date(usuario?.created_date).toLocaleDateString('pt-BR')}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Button
                  onClick={handleLogout}
                  variant="outline"
                  className="w-full gap-2 text-red-600 border-red-200 hover:bg-red-50"
                >
                  <LogOut className="w-4 h-4" />
                  Sair da Conta
                </Button>
              </div>

              <div className="lg:col-span-2">
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Edit className="w-5 h-5 text-blue-600" />
                      Informações Pessoais
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="nome">Nome Completo</Label>
                        <Input
                          id="nome"
                          value={dadosEdicao.nome}
                          onChange={(e) => handleInputChange('nome', e.target.value)}
                          placeholder="Ex: Matheus Teixeira"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="nick">Nome de Usuário</Label>
                        <Input
                          id="nick"
                          value={dadosEdicao.nick}
                          onChange={(e) => handleInputChange('nick', e.target.value)}
                          placeholder="Ex: matt_henrique"
                        />
                        <p className="text-xs text-slate-500">
                          Como você quer ser chamado na comunidade
                        </p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="telefone">Telefone</Label>
                        <Input
                          id="telefone"
                          value={dadosEdicao.telefone}
                          onChange={(e) => handleInputChange('telefone', e.target.value)}
                          placeholder="(00) 00000-0000"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="cidade">Cidade</Label>
                        <Input
                          id="cidade"
                          value={dadosEdicao.cidade}
                          onChange={(e) => handleInputChange('cidade', e.target.value)}
                          placeholder="Sua cidade"
                        />
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="estado">Estado</Label>
                        <Input
                          id="estado"
                          value={dadosEdicao.estado}
                          onChange={(e) => handleInputChange('estado', e.target.value)}
                          placeholder="Seu estado"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="profissao">Profissão</Label>
                        <Input
                          id="profissao"
                          value={dadosEdicao.profissao}
                          onChange={(e) => handleInputChange('profissao', e.target.value)}
                          placeholder="Sua profissão atual"
                        />
                      </div>
                    </div>

                    <Separator />

                    <div className="space-y-4">
                      <h3 className="font-semibold text-slate-800">Informações de Estudo</h3>

                      <div className="space-y-2">
                        <Label htmlFor="objetivo">Objetivo de Concurso</Label>
                        <Input
                          id="objetivo"
                          value={dadosEdicao.objetivo_concurso}
                          onChange={(e) => handleInputChange('objetivo_concurso', e.target.value)}
                          placeholder="Ex: Tribunal de Justiça, Polícia Civil, etc."
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bio">Sobre Você</Label>
                        <textarea
                          id="bio"
                          value={dadosEdicao.bio}
                          onChange={(e) => handleInputChange('bio', e.target.value)}
                          placeholder="Conte um pouco sobre você, sua jornada nos estudos, experiências..."
                          className="w-full min-h-[100px] px-3 py-2 border border-slate-200 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                    </div>

                    <div className="pt-6">
                      <Button
                        onClick={salvarAlteracoes}
                        disabled={salvando}
                        className="w-full md:w-auto gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                      >
                        {salvando ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                            Salvando...
                          </>
                        ) : (
                          <>
                            <Save className="w-4 h-4" />
                            Salvar Alterações
                          </>
                        )}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="assinatura" className="space-y-6 mt-6">
            {assinatura ? (
              <div className="space-y-6">
                {/* Card de Informações da Assinatura Atual */}
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-blue-600" />
                      Sua Assinatura Atual
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Coluna Esquerda - Info da Assinatura */}
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-600">Status:</span>
                          <Badge className={getStatusBadge(assinatura.status).color}>
                            {getStatusBadge(assinatura.status).label}
                          </Badge>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-600">Plano:</span>
                          <span className="font-semibold text-slate-800">
                            {getPlanoBadge(assinatura.plano)}
                          </span>
                        </div>

                        {assinatura.valor > 0 && (
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-slate-600">Valor:</span>
                            <span className="font-semibold text-slate-800">
                              R$ {assinatura.valor.toFixed(2).replace('.', ',')}
                            </span>
                          </div>
                        )}

                        <Separator />

                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-slate-600">Data de Início:</span>
                            <span className="text-sm font-medium text-slate-800">
                              {new Date(assinatura.data_inicio).toLocaleDateString('pt-BR')}
                            </span>
                          </div>

                          {assinatura.status === 'teste' && assinatura.data_teste_fim && (
                            <>
                              <div className="flex items-center justify-between">
                                <span className="text-sm text-slate-600">Teste expira em:</span>
                                <span className="text-sm font-medium text-slate-800">
                                  {new Date(assinatura.data_teste_fim).toLocaleDateString('pt-BR')}
                                </span>
                              </div>
                              <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                                <div className="flex items-center gap-2 text-blue-700">
                                  <Clock className="w-4 h-4" />
                                  <span className="text-sm font-medium">
                                    {diasRestantes !== null ? `${diasRestantes} dias restantes de teste gratuito` : 'Calculando dias restantes...'}
                                  </span>
                                </div>
                              </div>
                            </>
                          )}

                          {assinatura.status === 'ativo' && assinatura.data_fim && (
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-slate-600">Próxima cobrança:</span>
                              <span className="text-sm font-medium text-slate-800">
                                {new Date(assinatura.data_fim).toLocaleDateString('pt-BR')}
                              </span>
                            </div>
                          )}

                          {assinatura.cancelada_em && (
                            <div className="flex items-center justify-between">
                              <span className="text-sm text-slate-600">Cancelada em:</span>
                              <span className="text-sm font-medium text-slate-800">
                                {new Date(assinatura.cancelada_em).toLocaleDateString('pt-BR')}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Coluna Direita - Ações */}
                      <div className="space-y-4">
                        {assinatura.status === 'ativo' && (
                          <>
                            <Button
                              onClick={handleCancelarAssinatura}
                              disabled={cancelando}
                              variant="outline"
                              className="w-full gap-2 text-red-600 border-red-200 hover:bg-red-50"
                            >
                              {cancelando ? (
                                <>
                                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-red-600"></div>
                                  Cancelando...
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-4 h-4" />
                                  Cancelar Assinatura
                                </>
                              )}
                            </Button>

                            <div className="p-4 bg-slate-50 rounded-lg">
                              <p className="text-xs text-slate-600">
                                💡 Ao cancelar, você terá acesso até o final do período já pago.
                              </p>
                            </div>
                          </>
                        )}

                        {(assinatura.status === 'expirado' || assinatura.status === 'cancelado') && (
                          <div className="p-4 bg-amber-50 rounded-lg border border-amber-200">
                            <p className="text-sm text-amber-700">
                              ⚠️ Sua assinatura expirou. Escolha um plano abaixo para reativar.
                            </p>
                          </div>
                        )}

                        {assinatura.status === 'teste' && (
                          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                            <p className="text-sm text-green-700">
                              ✨ Aproveite seu teste gratuito! Escolha um plano abaixo para continuar após o término.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Cards de Planos Disponíveis */}
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Zap className="w-5 h-5 text-amber-600" />
                      {assinatura.status === 'ativo' ? 'Alterar Plano' : 'Escolher Plano'}
                    </CardTitle>
                    <p className="text-sm text-slate-600 mt-2">
                      {assinatura.status === 'ativo'
                        ? 'Faça upgrade ou downgrade do seu plano'
                        : 'Escolha o melhor plano para sua aprovação'}
                    </p>
                  </CardHeader>
                  <CardContent>
                    <div className="grid md:grid-cols-3 gap-6">
                      {/* Plano Mensal */}
                      <Card className="relative bg-white border-2 border-slate-200 hover:border-blue-300 transition-all duration-300">
                        <CardContent className="p-6 space-y-4">
                          <div>
                            <h3 className="text-lg font-bold text-slate-900">Mensal</h3>
                            <p className="text-sm text-slate-600">Flexibilidade máxima</p>
                          </div>

                          <div className="flex items-baseline gap-2">
                            <span className="text-4xl font-bold text-slate-900">R$ 49,90</span>
                            <span className="text-slate-600">/mês</span>
                          </div>

                          <Button
                            onClick={() => handleIniciarCheckout('mensal')}
                            disabled={processandoCheckout || assinatura.plano === 'mensal'}
                            className="w-full bg-blue-600 hover:bg-blue-700"
                          >
                            {assinatura.plano === 'mensal' ? 'Plano Atual' : 'Assinar Agora'}
                          </Button>

                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Acesso completo</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Cancele quando quiser</span>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>

                      {/* Plano Semestral */}
                      <Card className="relative bg-white border-2 border-blue-300 hover:border-blue-400 transition-all duration-300">
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-blue-600 text-white">Economia 20%</Badge>
                        </div>
                        <CardContent className="p-6 space-y-4">
                          <div>
                            <h3 className="text-lg font-bold text-slate-900">Semestral</h3>
                            <p className="text-sm text-slate-600">Economize mais</p>
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-baseline gap-2">
                              <span className="text-4xl font-bold text-slate-900">R$ 39,92</span>
                              <span className="text-slate-600">/mês</span>
                            </div>
                            <p className="text-sm text-slate-500">
                              R$ 239,52 cobrado semestralmente
                            </p>
                          </div>

                          <Button
                            onClick={() => handleIniciarCheckout('semestral')}
                            disabled={processandoCheckout || assinatura.plano === 'semestral'}
                            className="w-full bg-blue-600 hover:bg-blue-700"
                          >
                            {assinatura.plano === 'semestral' ? 'Plano Atual' : 'Assinar Agora'}
                          </Button>

                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Acesso completo</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Economize R$ 59,88</span>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>

                      {/* Plano Anual */}
                      <Card className="relative bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-400 hover:border-green-500 transition-all duration-300">
                        <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                          <Badge className="bg-green-600 text-white">Melhor Oferta -40%</Badge>
                        </div>
                        <CardContent className="p-6 space-y-4">
                          <div>
                            <h3 className="text-lg font-bold text-slate-900">Anual</h3>
                            <p className="text-sm text-slate-600">Máxima economia</p>
                          </div>

                          <div className="space-y-1">
                            <div className="flex items-baseline gap-2">
                              <span className="text-4xl font-bold text-slate-900">R$ 29,94</span>
                              <span className="text-slate-600">/mês</span>
                            </div>
                            <p className="text-sm text-slate-500">
                              R$ 359,28 cobrado anualmente
                            </p>
                          </div>

                          <Button
                            onClick={() => handleIniciarCheckout('anual')}
                            disabled={processandoCheckout || assinatura.plano === 'anual'}
                            className="w-full bg-green-600 hover:bg-green-700"
                          >
                            {assinatura.plano === 'anual' ? 'Plano Atual' : 'Assinar Agora'}
                          </Button>

                          <ul className="space-y-2 text-sm">
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Acesso completo</span>
                            </li>
                            <li className="flex items-center gap-2">
                              <Check className="w-4 h-4 text-green-600" />
                              <span>Economize R$ 239,52</span>
                            </li>
                          </ul>
                        </CardContent>
                      </Card>
                    </div>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                <CardContent className="p-12 text-center">
                  <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl flex items-center justify-center">
                    <CreditCard className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">
                    Nenhuma Assinatura Ativa
                  </h3>
                  <p className="text-slate-600 mb-6">
                    Você ainda não tem uma assinatura. Experimente gratuitamente por 14 dias!
                  </p>
                  <Button
                    onClick={() => navigate(createPageUrl("AtivarPlano"))}
                    className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                  >
                    <Zap className="w-4 h-4" />
                    Ativar Teste Gratuito / Ver Planos
                  </Button>
                </CardContent>
              </Card>
            )}

            {/* Card de Funcionalidades do Plano Pro - SEMPRE VISÍVEL */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-purple-600" />
                  {assinatura ? 'Seu Plano Pro Inclui:' : 'O Plano Pro Inclui:'}
                </CardTitle>
                <p className="text-sm text-slate-600">
                  {assinatura 
                    ? 'Todas essas funcionalidades estão disponíveis para você'
                    : 'Veja tudo que você terá acesso ao ativar o teste gratuito ou assinar'}
                </p>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {recursosPlanoPro.map((recurso, index) => {
                    const Icon = recurso.icon;
                    return (
                      <div key={index} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                        <div className="flex-shrink-0 w-8 h-8 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full flex items-center justify-center">
                          <Icon className="w-4 h-4 text-blue-700" />
                        </div>
                        <p className="text-sm text-slate-700 font-medium">{recurso.texto}</p>
                      </div>
                    );
                  })}
                </div>
                
                {!assinatura && (
                  <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
                    <p className="text-sm text-blue-800 text-center">
                      <strong>✨ Comece agora!</strong> Ative seu teste gratuito de 14 dias e tenha acesso completo a todas essas funcionalidades.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* New TabsContent for Lembretes */}
          <TabsContent value="lembretes" className="space-y-6 mt-6">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-blue-600" />
                  Lembretes Diários do Planner via WhatsApp
                </CardTitle>
                <p className="text-sm text-slate-600">
                  Receba seu plano de estudos do dia direto no WhatsApp
                </p>
              </CardHeader>
              <CardContent className="space-y-6">

                {/* Banner de "Em Breve" */}
                <div className="bg-gradient-to-r from-blue-50 to-amber-50/50 rounded-xl p-6 border border-blue-200/50">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <MessageSquare className="w-6 h-6 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-slate-800 mb-2">
                        Funcionalidade em Desenvolvimento
                      </h3>
                      <p className="text-sm text-slate-600 mb-4">
                        Em breve você poderá receber lembretes diários do seu plano de estudos
                        diretamente no WhatsApp! O Planner Lex enviará uma mensagem todas as manhãs
                        com os blocos de estudo que você tem programados para o dia.
                      </p>
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-600" />
                        <span className="text-sm font-medium text-slate-700">
                          Estamos trabalhando nisso!
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Prévia de como vai funcionar */}
                <div className="space-y-4">
                  <h4 className="font-semibold text-slate-800">Como vai funcionar:</h4>

                  <div className="space-y-3">
                    <div className="flex gap-3 p-4 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-blue-600 font-bold text-sm">1</span>
                      </div>
                      <div>
                        <p className="font-medium text-slate-800">Conecte seu WhatsApp</p>
                        <p className="text-sm text-slate-600">
                          Você poderá conectar seu número de WhatsApp à plataforma
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-3 p-4 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-blue-600 font-bold text-sm">2</span>
                      </div>
                      <div>
                        <p className="font-medium text-slate-800">Configure o horário</p>
                        <p className="text-sm text-slate-600">
                          Escolha em que horário deseja receber o lembrete diário
                        </p>
                      </div>
                    </div>

                    <div className="flex gap-3 p-4 bg-slate-50 rounded-lg">
                      <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-blue-600 font-bold text-sm">3</span>
                      </div>
                      <div>
                        <p className="font-medium text-slate-800">Receba seu plano</p>
                        <p className="text-sm text-slate-600">
                          Todo dia no horário escolhido, você receberá uma mensagem com seus blocos de estudo
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Call to action */}
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">
                    💡 <strong>Enquanto isso:</strong> Continue usando o Planner Lex na plataforma
                    para organizar sua rotina semanal de estudos!
                  </p>
                </div>

              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* The save button is now specific to the profile tab, but if any change happens, it will save everything */}
        {/* The original save button was inside the profile tab. Keeping it there but it applies to all user data including reminders */}
      </div>
    </div>
  );
}
