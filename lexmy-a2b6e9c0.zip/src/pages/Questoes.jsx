
import React, { useState, useEffect, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Check,
  X,
  BookCopy,
  Gavel,
  RotateCcw,
  ChevronRight,
  Clock,
  Target,
  HelpCircle
} from "lucide-react";
import { QuestaoMultipla, User } from "@/api/entities"; // User is no longer needed but kept for safety if there's other implicit use.
import { FiltroQuestao } from "@/api/entities";
import { gerarQuestaoMultipla } from "@/api/functions";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// Removed: Tabs, TabsContent, AdministracaoQuestoes, AdministracaoFiltros
// Removed: Brain, ClipboardList, ArrowRight, Zap, Sparkles, Settings, Filter icons

import { atualizarMetasQuestoes, registrarQuestao } from "@/components/utils/metasHelper";

function readLS(key) {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : null; } catch { return null; }
}
function writeLS(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

const delay = (ms) => new Promise((r) => setTimeout(r, ms));

export default function Questoes() {
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]);
  const [disciplinaSelecionada, setDisciplinaSelecionada] = useState("");
  const [conteudoSelecionado, setConteudoSelecionado] = useState("");

  const [sessaoIniciada, setSessaoIniciada] = useState(false);
  const [questaoAtual, setQuestaoAtual] = useState(null);
  const [carregandoQuestao, setCarregandoQuestao] = useState(false);

  const [alternativaSelecionada, setAlternativaSelecionada] = useState(null);

  const [feedbackVisivel, setFeedbackVisivel] = useState(false);
  const [avaliacaoCompleta, setAvaliacaoCompleta] = useState(null);
  const [carregandoAvaliacao, setCarregandoAvaliacao] = useState(false);

  const [estatisticasSessao, setEstatisticasSessao] = useState({
    acertos: 0,
    total: 0,
    inicio: null
  });

  // Removed: modoUI state
  // Removed: isAdmin state

  useEffect(() => {
    document.title = "Questões"; // Padronizar título da página
    carregarFiltrosDisponiveis();
    // Removed: verificarAdmin();
  }, []);

  const carregarFiltrosDisponiveis = async () => {
    try {
      const data = await FiltroQuestao.list('-created_date', 100);
      setFiltrosDisponiveis(data);
    } catch (error) {
      console.error('Erro ao carregar filtros:', error);
    }
  };

  const opcoesConteudo = useMemo(() => {
    if (!disciplinaSelecionada) return [];

    const conteudosDisciplina = filtrosDisponiveis
      .filter(filtro => filtro.disciplina === disciplinaSelecionada)
      .map(filtro => filtro.conteudo);

    return Array.from(new Set(conteudosDisciplina)).sort();
  }, [disciplinaSelecionada, filtrosDisponiveis]);

  const disciplinasUnicas = useMemo(() => {
    const disciplinasSet = new Set(filtrosDisponiveis.map(f => f.disciplina));
    return Array.from(disciplinasSet).sort();
  }, [filtrosDisponiveis]);

  // Removed: verificarAdmin function

  const iniciarSessao = async () => {
    if (!disciplinaSelecionada || !conteudoSelecionado) {
      alert("Por favor, selecione a disciplina e o conteúdo.");
      return;
    }

    setSessaoIniciada(true);
    setEstatisticasSessao({
      acertos: 0,
      total: 0,
      inicio: new Date()
    });
    await gerarNovaQuestao();
  };

  const gerarNovaQuestao = async () => {
    setCarregandoQuestao(true);
    setFeedbackVisivel(false);
    setAlternativaSelecionada(null);
    setAvaliacaoCompleta(null);

    try {
      // Primeiro, tentar buscar questões aprovadas do banco de dados
      const questoesCadastradas = await QuestaoMultipla.filter({
        disciplina: disciplinaSelecionada,
        conteudo: conteudoSelecionado,
        status: 'aprovada'
      });

      if (questoesCadastradas && questoesCadastradas.length > 0) {
        // Usar questão do banco de dados
        const questaoEscolhida = questoesCadastradas[
          Math.floor(Math.random() * questoesCadastradas.length)
        ];

        setQuestaoAtual({
          enunciado: questaoEscolhida.enunciado,
          alternativas: questaoEscolhida.alternativas,
          gabarito: questaoEscolhida.gabarito,
          fundamentacao: questaoEscolhida.fundamentacao,
          // NOVO: incluir informações adicionais
          codigo: questaoEscolhida.codigo,
          banca: questaoEscolhida.banca,
          ano: questaoEscolhida.ano,
          concurso: questaoEscolhida.concurso,
          origem: 'banco'
        });
      } else {
        // Gerar questão com IA se não houver no banco
        const { data } = await gerarQuestaoMultipla({
          disciplina: disciplinaSelecionada,
          conteudo: conteudoSelecionado
        });

        setQuestaoAtual({
          ...data,
          origem: 'ia'
        });
      }

    } catch (error) {
      console.error('Erro ao gerar questão:', error);
      alert('Erro ao carregar questão. Tente novamente.');
    }

    setCarregandoQuestao(false);
  };

  const confirmarResposta = async () => {
    if (alternativaSelecionada === null) {
      alert("Selecione uma alternativa.");
      return;
    }

    setCarregandoAvaliacao(true);

    try {
      const acertou = alternativaSelecionada === questaoAtual.gabarito;

      setAvaliacaoCompleta({
        acertou,
        fundamentacao: questaoAtual.fundamentacao
      });

      setEstatisticasSessao(prev => ({
        ...prev,
        total: prev.total + 1,
        acertos: prev.acertos + (acertou ? 1 : 0)
      }));

      // ATUALIZADO: Registrar questão resolvida no histórico
      await registrarQuestao('multipla_escolha', disciplinaSelecionada, acertou);

      setFeedbackVisivel(true);

    } catch (error) {
      console.error('Erro ao processar avaliação:', error);

      const acertou = alternativaSelecionada === questaoAtual.gabarito;

      setAvaliacaoCompleta({
        acertou,
        fundamentacao: questaoAtual.fundamentacao || "Fundamentação não disponível."
      });

      setEstatisticasSessao(prev => ({
        ...prev,
        total: prev.total + 1,
        acertos: prev.acertos + (acertou ? 1 : 0)
      }));

      // ATUALIZADO: Registrar questão mesmo em caso de erro na avaliação
      try {
        await registrarQuestao('multipla_escolha', disciplinaSelecionada, acertou);
      } catch (metaError) {
        console.error('Erro ao registrar questão:', metaError);
      }

      setFeedbackVisivel(true);
    }

    setCarregandoAvaliacao(false);
  };

  const proximaQuestao = () => {
    gerarNovaQuestao();
  };

  const reiniciarSessao = () => {
    setSessaoIniciada(false);
    setDisciplinaSelecionada("");
    setConteudoSelecionado("");
    setQuestaoAtual(null);
    setEstatisticasSessao({ acertos: 0, total: 0, inicio: null });
    // Removed: setModoUI("questoes");
  };

  const calcularTempoSessao = () => {
    if (!estatisticasSessao.inicio) return "0min";
    const minutos = Math.floor((new Date() - estatisticasSessao.inicio) / 60000);
    return `${minutos}min`;
  };

  const calcularPorcentagemAcerto = () => {
    if (estatisticasSessao.total === 0) return 0;
    return Math.round((estatisticasSessao.acertos / estatisticasSessao.total) * 100);
  };

  if (sessaoIniciada) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
        <div className="max-w-5xl mx-auto space-y-6">

          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-3">
                <HelpCircle className="w-6 h-6 text-blue-600" />
                {disciplinaSelecionada}
              </h1>
              <p className="text-slate-600 text-sm mt-1">Questões de Múltipla Escolha</p>
            </div>

            <div className="flex items-center gap-4">
              <Badge variant="outline" className="gap-2">
                <Target className="w-4 h-4" />
                {estatisticasSessao.acertos}/{estatisticasSessao.total} ({calcularPorcentagemAcerto()}%)
              </Badge>
              <Badge variant="outline" className="gap-2">
                <Clock className="w-4 h-4" />
                {calcularTempoSessao()}
              </Badge>
            </div>
          </div>

          {carregandoQuestao ? (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardContent className="p-12 text-center">
                <div className="w-16 h-16 mx-auto mb-6 bg-gradient-to-br from-blue-500 to-blue-600 rounded-3xl flex items-center justify-center animate-pulse">
                  <HelpCircle className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Carregando Questão...
                </h3>
                <p className="text-slate-600">
                  Preparando uma nova questão para você
                </p>
              </CardContent>
            </Card>
          ) : questaoAtual && (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <div className="flex flex-col gap-4">
                  {/* NOVO: Informações da questão do banco ANTES do título */}
                  {questaoAtual.origem === 'banco' && (
                    <div className="p-4 bg-gradient-to-r from-slate-50 to-blue-50/30 rounded-lg border border-slate-200/50">
                      <div className="flex flex-wrap items-center gap-4 text-sm">
                        {questaoAtual.codigo && (
                          <Badge variant="outline" className="bg-white/70 font-mono">
                            <HelpCircle className="w-3 h-3 mr-1" />
                            {questaoAtual.codigo}
                          </Badge>
                        )}
                        {questaoAtual.banca && (
                          <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                            <BookCopy className="w-3 h-3 mr-1" />
                            {questaoAtual.banca}
                          </Badge>
                        )}
                        {questaoAtual.ano && (
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            <Clock className="w-3 h-3 mr-1" />
                            {questaoAtual.ano}
                          </Badge>
                        )}
                        {questaoAtual.concurso && (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            <Target className="w-3 h-3 mr-1" />
                            {questaoAtual.concurso}
                          </Badge>
                        )}
                      </div>
                    </div>
                  )}
                  
                  <CardTitle className="text-lg text-slate-700">
                    Questão {estatisticasSessao.total + 1}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 bg-gradient-to-r from-slate-50 to-blue-50/30 rounded-lg border border-slate-200">
                  <p className="text-lg font-medium text-slate-800 leading-relaxed">
                    {questaoAtual.enunciado}
                  </p>
                </div>

                <div className="space-y-3">
                  {questaoAtual.alternativas?.map((alt, index) => (
                    <button
                      key={index}
                      onClick={() => setAlternativaSelecionada(index)}
                      className={`w-full text-left p-4 rounded-lg border-2 transition-all duration-200 ${
                        alternativaSelecionada === index
                          ? 'border-blue-500 bg-blue-50 text-blue-900'
                          : 'border-slate-200 bg-white hover:border-blue-300 hover:bg-blue-50/30'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <span className={`w-6 h-6 rounded-full flex items-center justify-center text-sm font-bold ${
                          alternativaSelecionada === index
                            ? 'bg-blue-500 text-white'
                            : 'bg-slate-200 text-slate-600'
                        }`}>
                          {String.fromCharCode(65 + index)}
                        </span>
                        <span className="flex-1">{alt}</span>
                      </div>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {!feedbackVisivel && questaoAtual && !carregandoQuestao && (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardContent className="p-6">
                <div className="flex justify-end">
                  <Button
                    onClick={confirmarResposta}
                    disabled={carregandoAvaliacao}
                    size="lg"
                    className="gap-2"
                  >
                    {carregandoAvaliacao ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                        Avaliando...
                      </>
                    ) : (
                      <>
                        Confirmar Resposta <ChevronRight className="w-4 h-4" />
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {feedbackVisivel && avaliacaoCompleta && (
            <Card className={`border-0 shadow-xl ${
              avaliacaoCompleta.acertou
                ? 'bg-gradient-to-r from-green-50 to-emerald-50/50'
                : 'bg-gradient-to-r from-red-50 to-rose-50/50'
            }`}>
              <CardHeader>
                <CardTitle className={`flex items-center gap-3 text-2xl ${
                  avaliacaoCompleta.acertou ? 'text-green-700' : 'text-red-700'
                }`}>
                  {avaliacaoCompleta.acertou ? (
                    <Check className="w-8 h-8"/>
                  ) : (
                    <X className="w-8 h-8"/>
                  )}
                  Você {avaliacaoCompleta.acertou ? 'Acertou!' : 'Errou!'}
                </CardTitle>
                <p className="text-slate-600">
                  A resposta correta era a alternativa <span className="font-bold text-lg">
                    {String.fromCharCode(65 + questaoAtual.gabarito)}
                  </span>: {questaoAtual.alternativas[questaoAtual.gabarito]}
                </p>
              </CardHeader>
              <CardContent>
                <div className="p-6 bg-white rounded-xl border shadow-sm">
                  <h4 className="font-semibold text-slate-800 mb-3 flex items-center gap-2">
                    <Gavel className="w-5 h-5 text-amber-600" />
                    Fundamentação
                  </h4>
                  <div className="prose prose-slate max-w-none">
                    <div className="whitespace-pre-wrap text-slate-700">
                      {avaliacaoCompleta.fundamentacao || "Fundamentação não disponível."}
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex justify-between items-center">
                  <Button onClick={reiniciarSessao} variant="outline" className="gap-2">
                    <RotateCcw className="w-4 h-4"/> Encerrar Sessão
                  </Button>
                  <Button onClick={proximaQuestao} size="lg" className="gap-2">
                    <HelpCircle className="w-5 h-5"/>
                    Próxima Questão
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-8">

        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Questões
          </h1>
          <p className="text-slate-600">
            Pratique com questões de múltipla escolha
          </p>
        </div>

        {/* Removed: Tabs component and its children */}
        {/* The content that was previously inside <TabsContent value="questoes"> now directly here */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
                <HelpCircle className="w-6 h-6 text-white" />
              </div>
              Configure sua Sessão de Questões
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">
                Disciplina
              </label>
              <Select value={disciplinaSelecionada} onValueChange={setDisciplinaSelecionada}>
                <SelectTrigger>
                  <SelectValue placeholder="Escolha a disciplina..." />
                </SelectTrigger>
                <SelectContent>
                  {disciplinasUnicas.length > 0 ? (
                    disciplinasUnicas.map(disciplina => (
                      <SelectItem key={disciplina} value={disciplina}>{disciplina}</SelectItem>
                    ))
                  ) : (
                    <SelectItem disabled value="no-disciplines">Nenhuma disciplina disponível</SelectItem>
                  )}
                </SelectContent>
              </Select>
            </div>

            {disciplinaSelecionada && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">
                  Conteúdo / Submatéria
                </label>
                <Select value={conteudoSelecionado} onValueChange={setConteudoSelecionado}>
                  <SelectTrigger>
                    <SelectValue placeholder={`Escolha o conteúdo de ${disciplinaSelecionada}...`} />
                  </SelectTrigger>
                  <SelectContent>
                    {opcoesConteudo.length > 0 ? (
                      opcoesConteudo.map((item) => (
                        <SelectItem key={item} value={item}>{item}</SelectItem>
                      ))
                    ) : (
                      <SelectItem disabled value="no-content">Nenhum conteúdo disponível</SelectItem>
                    )}
                  </SelectContent>
                </Select>
                {opcoesConteudo.length === 0 && (
                  <p className="text-xs text-red-500 mt-1">
                    Nenhum conteúdo disponível para esta disciplina. Solicite ao administrador que adicione filtros.
                  </p>
                )}
              </div>
            )}

            <div className="grid md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-blue-50/50 rounded-xl">
                <HelpCircle className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                <h3 className="font-semibold text-slate-800 text-sm">Múltipla Escolha</h3>
                <p className="text-xs text-slate-600">5 alternativas por questão</p>
              </div>
              <div className="text-center p-4 bg-green-50/50 rounded-xl">
                <Target className="w-8 h-8 mx-auto mb-2 text-green-600" />
                <h3 className="font-semibold text-slate-800 text-sm">Ilimitadas</h3>
                <p className="text-xs text-slate-600">Quantas quiser</p>
              </div>
              <div className="text-center p-4 bg-purple-50/50 rounded-xl">
                <Gavel className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                <h3 className="font-semibold text-slate-800 text-sm">Fundamentação Legal</h3>
                <p className="text-xs text-slate-600">Base jurídica completa</p>
              </div>
            </div>

            <Button
              onClick={iniciarSessao}
              disabled={!disciplinaSelecionada || !conteudoSelecionado}
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg gap-2 px-8 py-3 text-lg"
            >
              <HelpCircle className="w-5 h-5" />
              Iniciar Sessão de Questões
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
