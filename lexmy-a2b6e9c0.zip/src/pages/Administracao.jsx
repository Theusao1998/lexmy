
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Shield,
  Users,
  BookOpen,
  Brain,
  FileText,
  Headphones,
  Settings,
  BarChart3,
  Bot,
  HelpCircle,
  ListChecks,
  Newspaper,
  ArrowRight,
  Database,
  FileImage,
  ClipboardList,
  ShieldCheck,
  Lock,
  CreditCard // Added CreditCard icon
} from "lucide-react";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import { useNavigate } from "react-router-dom";
import AdministracaoAssertivas from "@/components/treinamento/AdministracaoAssertivas";
import AdministracaoQuestoes from "@/components/questoes/AdministracaoQuestoes";
import AdministracaoFiltros from "@/components/questoes/AdministracaoFiltros";
import BotControls from "@/components/comunidade/BotControls";
import AdministracaoSimulados from "@/components/simulados/AdministracaoSimulados";
import AdministracaoDiscursivas from "@/components/discursivas/AdministracaoDiscursivas";
import AdministracaoEditais from "@/components/edital/AdministracaoEditais";
import AdministracaoBiblioteca from "@/components/biblioteca/AdministracaoBiblioteca";
import AdministracaoLegislacaoAudio from "@/components/audio/AdministracaoLegislacaoAudio";
import AdministracaoMapasMentais from "@/components/mapas/AdministracaoMapasMentais";
import AdministracaoAssinaturas from "@/components/assinaturas/AdministracaoAssinaturas"; // Imported new component

export default function AdministracaoPage() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");
  const navigate = useNavigate();

  useEffect(() => {
    verificarPermissoes();
  }, []);

  const verificarPermissoes = async () => {
    try {
      const user = await User.me();
      
      if (user.role !== 'admin') {
        alert('Acesso negado. Esta área é restrita a administradores.');
        navigate(createPageUrl("Dashboard"));
        return;
      }
      
      setIsAdmin(true);
    } catch (error) {
      console.error('Erro ao verificar permissões:', error);
      navigate(createPageUrl("Dashboard"));
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-600 to-blue-800 rounded-3xl flex items-center justify-center animate-pulse">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">Verificando permissões...</h3>
          <p className="text-slate-600">Aguarde um momento</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-600 to-blue-800 rounded-2xl flex items-center justify-center shadow-lg">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
                  Administração
                </h1>
                <p className="text-slate-600">Painel de controle e gerenciamento da plataforma</p>
              </div>
            </div>
          </div>
          <Badge className="bg-red-100 text-red-700 border-red-200 px-4 py-2">
            <Shield className="w-4 h-4 mr-2" />
            Área Administrativa
          </Badge>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          {/* Updated grid-cols to accommodate new tab - 12 tabs total */}
          <TabsList className="grid w-full grid-cols-6 bg-white/60 backdrop-blur-sm h-auto"> 
            <TabsTrigger value="overview" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Visão Geral
            </TabsTrigger>
            <TabsTrigger value="questoes" className="gap-2">
              <HelpCircle className="w-4 h-4" />
              Questões
            </TabsTrigger>
            <TabsTrigger value="assertivas" className="gap-2">
              <Brain className="w-4 h-4" />
              Assertivas
            </TabsTrigger>
            <TabsTrigger value="filtros" className="gap-2">
              <ListChecks className="w-4 h-4" />
              Filtros
            </TabsTrigger>
            <TabsTrigger value="simulados" className="gap-2">
              <FileText className="w-4 h-4" />
              Simulados
            </TabsTrigger>
            <TabsTrigger value="discursivas" className="gap-2">
              <Newspaper className="w-4 h-4" />
              Discursivas
            </TabsTrigger>
            <TabsTrigger value="editais" className="gap-2">
              <ClipboardList className="w-4 h-4" />
              Editais
            </TabsTrigger>
            <TabsTrigger value="biblioteca" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Biblioteca
            </TabsTrigger>
            <TabsTrigger value="audios" className="gap-2">
              <Headphones className="w-4 h-4" />
              Áudios
            </TabsTrigger>
            <TabsTrigger value="mapas" className="gap-2">
              <Brain className="w-4 h-4" />
              Mapas Mentais
            </TabsTrigger>
            <TabsTrigger value="bots" className="gap-2">
              <Bot className="w-4 h-4" />
              Bots
            </TabsTrigger>
            {/* New Tab Trigger for Assinaturas */}
            <TabsTrigger value="assinaturas" className="gap-2">
              <CreditCard className="w-4 h-4" />
              Assinaturas
            </TabsTrigger>
          </TabsList>

          {/* Visão Geral */}
          <TabsContent value="overview" className="space-y-6">
            {/* Assistente de Segurança */}
            <Card className="bg-gradient-to-r from-red-50 via-orange-50 to-amber-50 border-2 border-red-200/50 shadow-xl">
              <CardContent className="p-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-16 h-16 bg-gradient-to-br from-red-600 to-orange-600 rounded-2xl flex items-center justify-center shadow-lg">
                      <ShieldCheck className="w-8 h-8 text-white" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-slate-900 mb-2">
                        Assistente de Segurança
                      </h3>
                      <p className="text-slate-700 mb-4">
                        Auditor inteligente que verifica regras de RLS, identifica vulnerabilidades e garante a privacidade dos usuários da plataforma.
                      </p>
                      <div className="flex flex-wrap gap-2 mb-4">
                        <Badge className="bg-red-100 text-red-700 border-red-200">
                          <Lock className="w-3 h-3 mr-1" />
                          Auditoria de RLS
                        </Badge>
                        <Badge className="bg-orange-100 text-orange-700 border-orange-200">
                          <ShieldCheck className="w-3 h-3 mr-1" />
                          Verificação de Segurança
                        </Badge>
                        <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                          <Users className="w-3 h-3 mr-1" />
                          Privacidade de Dados
                        </Badge>
                      </div>
                      <p className="text-sm text-slate-600">
                        <strong>Exemplo de uso:</strong> "Analise a segurança da entidade Edital" ou "Faça uma auditoria geral de RLS"
                      </p>
                    </div>
                  </div>
                  <Button
                    onClick={() => navigate(createPageUrl("AssistenteSeguranca"))}
                    className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 gap-2 shadow-lg"
                  >
                    <ShieldCheck className="w-4 h-4" />
                    Abrir Assistente
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Espaço reservado para futuros gráficos e métricas */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <BarChart3 className="w-6 h-6 text-blue-600" />
                  Métricas e Gráficos
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <BarChart3 className="w-16 h-16 mx-auto mb-4 text-slate-400" />
                  <p className="text-slate-600">
                    Estatísticas e gráficos de uso da plataforma serão exibidos aqui em breve.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Questões */}
          <TabsContent value="questoes">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <HelpCircle className="w-6 h-6 text-blue-600" />
                  Gerenciamento de Questões Múltipla Escolha
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AdministracaoQuestoes />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Assertivas */}
          <TabsContent value="assertivas">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Brain className="w-6 h-6 text-purple-600" />
                  Gerenciamento de Assertivas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <AdministracaoAssertivas />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Filtros */}
          <TabsContent value="filtros">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <ListChecks className="w-6 h-6 text-green-600" />
                  Gerenciamento de Filtros de Conteúdo
                </CardTitle>
                <CardDescription>
                  Configure as disciplinas e conteúdos disponíveis para treinamento e questões
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoFiltros />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Simulados */}
          <TabsContent value="simulados">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center">
                    <FileText className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento de Simulados
                </CardTitle>
                <CardDescription>
                  Configure e gerencie simulados completos para os estudantes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoSimulados />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Discursivas */}
          <TabsContent value="discursivas">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl flex items-center justify-center">
                    <Newspaper className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento de Questões Discursivas
                </CardTitle>
                <CardDescription>
                  Configure e gerencie questões discursivas avaliadas por IA
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoDiscursivas />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Editais */}
          <TabsContent value="editais">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-cyan-500 to-cyan-600 rounded-2xl flex items-center justify-center">
                    <ClipboardList className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento de Editais Template
                </CardTitle>
                <CardDescription>
                  Configure editais modelo para a biblioteca e permita que usuários os copiem
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoEditais />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Biblioteca */}
          <TabsContent value="biblioteca">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento da Biblioteca
                </CardTitle>
                <CardDescription>
                  Adicione e gerencie legislação, materiais de estudo, jurisprudência, informativos e resumos visuais
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoBiblioteca />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Áudios de Legislação */}
          <TabsContent value="audios">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center">
                    <Headphones className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento de Áudios de Legislação
                </CardTitle>
                <CardDescription>
                  Configure áudios e coleções para estudo auditivo de legislação
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoLegislacaoAudio />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mapas Mentais */}
          <TabsContent value="mapas">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center">
                    <Brain className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento de Mapas Mentais
                </CardTitle>
                <CardDescription>
                  Crie e gerencie mapas mentais interativos com HTML/CSS completo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoMapasMentais />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bots */}
          <TabsContent value="bots">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <Bot className="w-6 h-6 text-amber-600" />
                  Controle de Bots da Comunidade
                </CardTitle>
                <CardDescription>
                  Gerencie as configurações e o status dos bots automáticos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BotControls onBotExecuted={() => {}} />
              </CardContent>
            </Card>
          </TabsContent>

          {/* New Tab: Assinaturas */}
          <TabsContent value="assinaturas">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center">
                    <CreditCard className="w-6 h-6 text-white" />
                  </div>
                  Gerenciamento de Assinaturas
                </CardTitle>
                <CardDescription>
                  Visualize e gerencie todas as assinaturas da plataforma
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AdministracaoAssinaturas />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
