
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sparkles,
  Check,
  Zap,
  BookOpen,
  Brain,
  Timer,
  Users,
  Shield,
  Headphones,
  FileText,
  Puzzle,
  TrendingUp,
  MessageCircle,
  Calendar,
  Target,
  Clock,
  CheckCircle
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { createPageUrl } from "@/utils";
import LexmyLogo from "@/components/brand/LexmyLogo";

export default function AtivarPlano() {
  const navigate = useNavigate();
  const [processandoTeste, setProcessandoTeste] = useState(false);
  const [processandoCheckout, setProcessandoCheckout] = useState(false);
  const [mensagemErro, setMensagemErro] = useState("");

  const recursos = [
    { icon: BookOpen, texto: "Biblioteca Jurídica Completa" },
    { icon: Brain, texto: "Questões Ilimitadas com IA" },
    { icon: Timer, texto: "Temporizador Pomodoro com Música" },
    { icon: Shield, texto: "Prof. Lex - IA Jurídica 24/7" },
    { icon: Users, texto: "Comunidade Ativa" },
    { icon: Headphones, texto: "Legislação em Áudio" },
    { icon: FileText, texto: "Verticalização de Editais" },
    { icon: Calendar, texto: "Planner Inteligente" },
    { icon: Puzzle, texto: "Jogos Jurídicos" },
    { icon: TrendingUp, texto: "Dashboard de Progresso" },
    { icon: MessageCircle, texto: "Chat em Tempo Real" },
    { icon: Target, texto: "Sistema de Metas" }
  ];

  const precosPlanos = {
    mensal: {
      valor: 49.90,
      periodo: "mês",
      total: 49.90,
      economia: 0,
      destaque: false
    },
    semestral: {
      valor: 39.92,
      periodo: "mês",
      total: 239.52,
      economia: 20,
      destaque: false
    },
    anual: {
      valor: 29.94,
      periodo: "mês",
      total: 359.28,
      economia: 40,
      destaque: true
    }
  };

  const handleAtivarTesteGratuito = async () => {
    setProcessandoTeste(true);
    setMensagemErro("");

    try {
      // AWAIT completo da requisição antes de qualquer redirect
      const { data } = await base44.functions.invoke('activateFreeTrial', {});

      if (data.success) {
        console.log('[AtivarPlano] Teste ativado com sucesso:', data.assinatura);
        
        // Marcar no sessionStorage que o trial foi ativado (flag anti-loop)
        sessionStorage.setItem('trialActivated', '1');
        
        // Redirect "duro" com replace para forçar reload completo do Layout
        console.log('[AtivarPlano] Redirecionando para Dashboard com replace...');
        
        // Usar setTimeout curto para garantir que sessionStorage seja salvo antes do redirect
        setTimeout(() => {
          window.location.replace(createPageUrl("Dashboard"));
        }, 100);
      } else {
        // Erro retornado pelo backend
        setMensagemErro(data.error || "Erro ao ativar teste gratuito");
        setProcessandoTeste(false);
      }
    } catch (error) {
      console.error('[AtivarPlano] Erro ao ativar teste:', error);
      
      if (error.response?.data?.error) {
        setMensagemErro(error.response.data.error);
      } else if (error.response?.data?.expired) {
        setMensagemErro("Você já utilizou seu teste gratuito. Por favor, escolha um plano abaixo.");
      } else {
        setMensagemErro("Erro ao ativar teste gratuito. Por favor, tente novamente.");
      }
      
      setProcessandoTeste(false);
    }
  };

  const handleIniciarCheckout = async (plano) => {
    setProcessandoCheckout(true);
    setMensagemErro("");

    try {
      const { data } = await base44.functions.invoke('createMercadoPagoCheckout', {
        plano: plano
      });

      if (data.init_point) {
        window.location.href = data.init_point;
      } else {
        throw new Error('URL de checkout não recebida');
      }
    } catch (error) {
      console.error('Erro ao iniciar checkout:', error);
      setMensagemErro("Erro ao processar pagamento. Por favor, tente novamente.");
    } finally {
      setProcessandoCheckout(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
      <style>{`
        .glass-effect {
          background: rgba(255, 255, 255, 0.85);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }
      `}</style>

      {/* Header */}
      <header className="sticky top-0 z-50 w-full glass-effect border-b border-slate-200/60">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-center">
            <LexmyLogo className="w-40 h-auto" />
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-12 md:py-16">
        
        {/* Hero Section */}
        <div className="text-center space-y-6 mb-12">
          <Badge className="bg-gradient-to-r from-blue-100 to-amber-50 text-blue-800 border-blue-200 px-4 py-2 text-sm">
            <Sparkles className="w-4 h-4 mr-2" />
            Bem-vindo ao Lexmy!
          </Badge>
          
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Escolha seu Plano
          </h1>
          
          <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto">
            Para acessar a plataforma, ative seu teste gratuito de 14 dias ou escolha um dos nossos planos.
          </p>
        </div>

        {/* Mensagem de Erro */}
        {mensagemErro && (
          <Card className="max-w-2xl mx-auto mb-8 border-red-200 bg-red-50">
            <CardContent className="p-4">
              <p className="text-red-700 text-center">{mensagemErro}</p>
            </CardContent>
          </Card>
        )}

        {/* Card de Teste Gratuito */}
        <Card className="max-w-4xl mx-auto mb-12 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-400 shadow-2xl">
          <CardContent className="p-8 md:p-12">
            <div className="flex flex-col md:flex-row items-center gap-8">
              
              {/* Lado Esquerdo - Info */}
              <div className="flex-1 space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-12 h-12 bg-green-600 rounded-2xl flex items-center justify-center">
                    <Sparkles className="w-6 h-6 text-white" />
                  </div>
                  <Badge className="bg-green-600 text-white">Recomendado</Badge>
                </div>
                
                <h2 className="text-3xl font-bold text-slate-900">
                  Teste Gratuito - 14 Dias
                </h2>
                
                <p className="text-lg text-slate-600">
                  Experimente todos os recursos da plataforma por 14 dias, sem compromisso e sem cartão de crédito necessário.
                </p>

                <ul className="space-y-2">
                  <li className="flex items-center gap-2 text-slate-700">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span>Acesso completo por 14 dias</span>
                  </li>
                  <li className="flex items-center gap-2 text-slate-700">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span>Sem cartão de crédito</span>
                  </li>
                  <li className="flex items-center gap-2 text-slate-700">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span>Cancele quando quiser</span>
                  </li>
                </ul>
              </div>

              {/* Lado Direito - CTA */}
              <div className="flex-shrink-0">
                <Button
                  type="button"
                  onClick={handleAtivarTesteGratuito}
                  disabled={processandoTeste}
                  size="lg"
                  className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-xl px-12 py-6 text-lg gap-2"
                >
                  {processandoTeste ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      Ativando...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5" />
                      Ativar Teste Gratuito
                    </>
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Divisor */}
        <div className="relative max-w-4xl mx-auto my-12">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-300"></div>
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="px-4 bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 text-slate-600 font-medium">
              ou escolha um plano
            </span>
          </div>
        </div>

        {/* Grid de Planos */}
        <div className="max-w-6xl mx-auto">
          <h3 className="text-2xl font-bold text-center text-slate-900 mb-8">
            Planos Disponíveis
          </h3>
          
          <div className="grid md:grid-cols-3 gap-6 mb-12">
            {/* Plano Mensal */}
            <Card className="bg-white border-2 border-slate-200 hover:border-blue-300 transition-all duration-300">
              <CardContent className="p-6 space-y-4">
                <div>
                  <h4 className="text-lg font-bold text-slate-900">Mensal</h4>
                  <p className="text-sm text-slate-600">Flexibilidade máxima</p>
                </div>

                <div className="flex items-baseline gap-2">
                  <span className="text-4xl font-bold text-slate-900">R$ 49,90</span>
                  <span className="text-slate-600">/mês</span>
                </div>

                <Button
                  onClick={() => handleIniciarCheckout('mensal')}
                  disabled={processandoCheckout || processandoTeste}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Assinar Agora
                </Button>

                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span>Acesso completo</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span>Cancele quando quiser</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Plano Semestral */}
            <Card className="bg-white border-2 border-blue-300 hover:border-blue-400 transition-all duration-300 relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-blue-600 text-white">Economia 20%</Badge>
              </div>
              <CardContent className="p-6 space-y-4">
                <div>
                  <h4 className="text-lg font-bold text-slate-900">Semestral</h4>
                  <p className="text-sm text-slate-600">Economize mais</p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-slate-900">R$ 39,92</span>
                    <span className="text-slate-600">/mês</span>
                  </div>
                  <p className="text-sm text-slate-500">
                    R$ 239,52 cobrado semestralmente
                  </p>
                </div>

                <Button
                  onClick={() => handleIniciarCheckout('semestral')}
                  disabled={processandoCheckout || processandoTeste}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                >
                  Assinar Agora
                </Button>

                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span>Acesso completo</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span>Economize R$ 59,88</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            {/* Plano Anual */}
            <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-400 hover:border-green-500 transition-all duration-300 relative">
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <Badge className="bg-green-600 text-white">Melhor Oferta -40%</Badge>
              </div>
              <CardContent className="p-6 space-y-4">
                <div>
                  <h4 className="text-lg font-bold text-slate-900">Anual</h4>
                  <p className="text-sm text-slate-600">Máxima economia</p>
                </div>

                <div className="space-y-1">
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-bold text-slate-900">R$ 29,94</span>
                    <span className="text-slate-600">/mês</span>
                  </div>
                  <p className="text-sm text-slate-500">
                    R$ 359,28 cobrado anualmente
                  </p>
                </div>

                <Button
                  onClick={() => handleIniciarCheckout('anual')}
                  disabled={processandoCheckout || processandoTeste}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  Assinar Agora
                </Button>

                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span>Acesso completo</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-green-600" />
                    <span>Economize R$ 239,52</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Recursos Incluídos */}
        <Card className="max-w-6xl mx-auto bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader>
            <CardTitle className="text-center text-2xl">
              Todos os planos incluem:
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {recursos.map((recurso, index) => {
                const Icon = recurso.icon;
                return (
                  <div key={index} className="flex items-start gap-2">
                    <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                      <Icon className="w-4 h-4 text-blue-700" />
                    </div>
                    <span className="text-sm text-slate-700">{recurso.texto}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
