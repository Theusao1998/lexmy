
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  FileText,
  Building,
  Briefcase,
  Calendar,
  DollarSign,
  Users,
  Copy,
  BookOpen,
  Plus,
  ClipboardList,
  Edit,
  Trash2,
  Download,
  FileCheck,
  Archive,
  FilePenLine
} from "lucide-react";
import { Edital } from "@/api/entities";
import { base44 } from "@/api/base44Client";
import { toast } from "sonner";
import EditalForm from "@/components/edital/EditalForm";
import EditalTopics from "@/components/edital/EditalTopics";
import GerenciarDisciplinasDialog from "@/components/edital/GerenciarDisciplinasDialog";

export default function EditalPage() {
  const [editais, setEditais] = useState([]);
  const [editaisTemplates, setEditaisTemplates] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("meus");

  // Estados para edital pessoal
  const [showEditalForm, setShowEditalForm] = useState(false);
  const [editalParaEditar, setEditalParaEditar] = useState(null);

  // Estados para visualizar tópicos
  const [editalSelecionado, setEditalSelecionado] = useState(null);
  const [showTopics, setShowTopics] = useState(false);

  // Estados para gerenciar disciplinas
  const [showGerenciarDialog, setShowGerenciarDialog] = useState(false);
  const [editalParaGerenciar, setEditalParaGerenciar] = useState(null);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setLoading(true);
    try {
      const userData = await base44.auth.me();
      setUser(userData);

      // Buscar editais pessoais do usuário
      // O RLS já garante que só virão editais created_by = user.email
      const editaisPessoais = await base44.entities.Edital.filter({ 
        tipo: 'pessoal' 
      });

      // Buscar templates
      // O RLS já garante que:
      // - Usuários comuns só veem templates com status: "publicado" ou "arquivado"
      // - Admins veem todos os templates (incluindo rascunhos)
      const templates = await base44.entities.Edital.filter({ 
        tipo: 'template' 
      });

      setEditais(editaisPessoais);
      setEditaisTemplates(templates);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar editais.');
    } finally {
      setLoading(false);
    }
  };

  const handleCriarEditalPessoal = async (formData) => {
    try {
      await base44.entities.Edital.create({ 
        ...formData, 
        tipo: "pessoal", 
        disciplinas: [], 
        template_origem_id: null
      }); 
      setShowEditalForm(false);
      setEditalParaEditar(null);
      toast.success('Edital criado com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao criar edital pessoal:', error);
      toast.error('Erro ao criar edital pessoal.');
    }
  };

  const handleEditarEdital = async (formData) => {
    try {
      await base44.entities.Edital.update(editalParaEditar.id, formData);
      setShowEditalForm(false);
      setEditalParaEditar(null);
      toast.success('Edital atualizado com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao editar edital:', error);
      toast.error('Erro ao editar edital.');
    }
  };

  const handleExcluirEdital = async (editalId) => {
    if (!confirm('Tem certeza que deseja excluir este edital? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await base44.entities.Edital.delete(editalId);
      toast.success('Edital excluído com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao excluir edital:', error);
      toast.error('Erro ao excluir edital.');
    }
  };

  const handleCopiarTemplate = async (templateEdital) => {
    if (!confirm(`Deseja copiar o edital "${templateEdital.nome_concurso}" para seus editais pessoais?`)) {
      return;
    }

    try {
      const { data } = await base44.functions.invoke('copiarEditalParaUsuario', {
        templateEdital
      });

      if (data.success) {
        toast.success('Edital copiado com sucesso!');
        await carregarDados();
        setActiveTab("meus");
      } else {
        toast.error(data.error || 'Erro ao copiar edital.');
      }
    } catch (error) {
      console.error('Erro ao copiar edital:', error);
      toast.error('Erro ao copiar edital.');
    }
  };

  const handleVisualizarTopicos = (edital) => {
    setEditalSelecionado(edital);
    setShowTopics(true);
  };

  const handleVoltarParaEditais = () => {
    setShowTopics(false);
    setEditalSelecionado(null);
    carregarDados();
  };

  const handleGerenciarDisciplinas = (edital) => {
    setEditalParaGerenciar(edital);
    setShowGerenciarDialog(true);
  };

  const handleExportarPDF = async (edital) => {
    try {
      toast.info('Gerando PDF...');
      const { data } = await base44.functions.invoke('exportEditalPdf', {
        editalId: edital.id
      });

      if (data && data.pdfUrl) {
        window.open(data.pdfUrl, '_blank');
        toast.success('PDF gerado com sucesso!');
      } else {
        toast.error('Erro ao gerar PDF.');
      }
    } catch (error) {
      console.error('Erro ao exportar PDF:', error);
      toast.error('Erro ao exportar PDF.');
    }
  };

  // Função auxiliar para obter o ícone e cor do status
  const getStatusBadge = (status) => {
    const configs = {
      rascunho: {
        icon: FilePenLine,
        label: "Rascunho",
        className: "bg-yellow-100 text-yellow-700 border-yellow-200"
      },
      publicado: {
        icon: FileCheck,
        label: "Publicado",
        className: "bg-green-100 text-green-700 border-green-200"
      },
      arquivado: {
        icon: Archive,
        label: "Arquivado",
        className: "bg-slate-100 text-slate-700 border-slate-200"
      }
    };

    const config = configs[status] || configs.rascunho;
    const Icon = config.icon;

    return (
      <Badge className={config.className}>
        <Icon className="w-3 h-3 mr-1" />
        {config.label}
      </Badge>
    );
  };

  if (showTopics && editalSelecionado) {
    return (
      <EditalTopics
        edital={editalSelecionado}
        onBack={handleVoltarParaEditais}
        onToggle={async (disciplinaIndex, topicoIndex, campo) => {
          try {
            const novasDisciplinas = [...editalSelecionado.disciplinas];
            const hoje = new Date().toISOString().split('T')[0];
            
            if (novasDisciplinas[disciplinaIndex]?.topicos?.[topicoIndex]) {
              const topicoAtual = novasDisciplinas[disciplinaIndex].topicos[topicoIndex];
              
              if (topicoAtual[campo]) {
                novasDisciplinas[disciplinaIndex].topicos[topicoIndex][campo] = null;
              } else {
                novasDisciplinas[disciplinaIndex].topicos[topicoIndex][campo] = hoje;
              }
            }

            await base44.entities.Edital.update(editalSelecionado.id, {
              disciplinas: novasDisciplinas
            });

            // Update local state to reflect the change immediately
            setEditalSelecionado({
              ...editalSelecionado,
              disciplinas: novasDisciplinas
            });
            toast.success('Tópico atualizado!');
          } catch (error) {
            console.error('Erro ao atualizar tópico:', error);
            toast.error('Erro ao atualizar tópico.');
          }
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Editais
          </h1>
          <p className="text-slate-600 max-w-2xl">
            Organize e verticalize os conteúdos programáticos dos seus concursos
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/60 backdrop-blur-sm">
            <TabsTrigger value="meus" className="gap-2">
              <ClipboardList className="w-4 h-4" />
              Meus Editais
            </TabsTrigger>
            <TabsTrigger value="biblioteca" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Biblioteca de Templates
            </TabsTrigger>
          </TabsList>

          {/* Meus Editais */}
          <TabsContent value="meus" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold text-slate-800">Meus Editais Pessoais</h2>
              <Button onClick={() => { setEditalParaEditar(null); setShowEditalForm(true); }} className="gap-2">
                <Plus className="w-4 h-4" />
                Novo Edital
              </Button>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
              </div>
            ) : editais.length === 0 ? (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <FileText className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">
                    Nenhum edital cadastrado
                  </h3>
                  <p className="text-slate-600 mb-6">
                    Crie um novo edital ou copie um template da biblioteca
                  </p>
                  <div className="flex justify-center gap-3">
                    <Button onClick={() => setShowEditalForm(true)} className="gap-2">
                      <Plus className="w-4 h-4" />
                      Criar Novo
                    </Button>
                    <Button variant="outline" onClick={() => setActiveTab("biblioteca")} className="gap-2">
                      <BookOpen className="w-4 h-4" />
                      Ver Biblioteca
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-6">
                {editais.map((edital) => (
                  <Card key={edital.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-2 flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <CardTitle className="text-xl">{edital.nome_concurso}</CardTitle>
                            {getStatusBadge(edital.status)}
                          </div>
                          <div className="flex items-center gap-3 text-sm text-slate-600 flex-wrap">
                            {edital.orgao && (
                              <span className="flex items-center gap-1">
                                <Building className="w-4 h-4" />
                                {edital.orgao}
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Briefcase className="w-4 h-4" />
                              {edital.cargo}
                            </span>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => { setEditalParaEditar(edital); setShowEditalForm(true); }}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirEdital(edital.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-2">
                        {edital.vagas && (
                          <Badge variant="outline" className="gap-1">
                            <Users className="w-3 h-3" />
                            {edital.vagas} vagas
                          </Badge>
                        )}
                        {edital.salario && (
                          <Badge variant="outline" className="gap-1 bg-green-50 text-green-700 border-green-200">
                            <DollarSign className="w-3 h-3" />
                            R$ {edital.salario.toLocaleString('pt-BR')}
                          </Badge>
                        )}
                        {edital.data_prova && (
                          <Badge variant="outline" className="gap-1">
                            <Calendar className="w-3 h-3" />
                            {new Date(edital.data_prova).toLocaleDateString('pt-BR')}
                          </Badge>
                        )}
                        {edital.disciplinas && edital.disciplinas.length > 0 && (
                          <Badge className="gap-1 bg-blue-100 text-blue-700">
                            <BookOpen className="w-3 h-3" />
                            {edital.disciplinas.length} disciplinas
                          </Badge>
                        )}
                      </div>

                      <div className="flex gap-2 flex-wrap">
                        <Button onClick={() => handleVisualizarTopicos(edital)} className="flex-1 gap-2">
                          <BookOpen className="w-4 h-4" />
                          Ver Conteúdo Programático
                        </Button>
                        <Button
                          variant="outline"
                          onClick={() => handleGerenciarDisciplinas(edital)}
                          className="gap-2"
                        >
                          <Edit className="w-4 h-4" />
                          Disciplinas
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Biblioteca de Templates */}
          <TabsContent value="biblioteca" className="space-y-6">
            <div>
              <h2 className="text-xl font-semibold text-slate-800 mb-2">Biblioteca de Templates</h2>
              <p className="text-sm text-slate-600">
                Copie editais modelo para o seu perfil e personalize conforme necessário
              </p>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
              </div>
            ) : editaisTemplates.length === 0 ? (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <BookOpen className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">
                    Nenhum template disponível
                  </h3>
                  <p className="text-slate-600">
                    A biblioteca de templates ainda não possui editais cadastrados
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {editaisTemplates.map((template) => (
                  <Card key={template.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all">
                    <CardHeader>
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap mb-2">
                            <CardTitle className="text-lg">{template.nome_concurso}</CardTitle>
                            {getStatusBadge(template.status)}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-slate-600 flex-wrap">
                            {template.orgao && (
                              <span className="flex items-center gap-1">
                                <Building className="w-3 h-3" />
                                {template.orgao}
                              </span>
                            )}
                            <span className="flex items-center gap-1">
                              <Briefcase className="w-3 h-3" />
                              {template.cargo}
                            </span>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex flex-wrap gap-2">
                        {template.disciplinas && template.disciplinas.length > 0 && (
                          <Badge className="gap-1 bg-blue-100 text-blue-700">
                            <BookOpen className="w-3 h-3" />
                            {template.disciplinas.length} disciplinas
                          </Badge>
                        )}
                      </div>

                      <Button onClick={() => handleCopiarTemplate(template)} className="w-full gap-2">
                        <Copy className="w-4 h-4" />
                        Copiar para Meus Editais
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Form de Edital Pessoal - ATUALIZADO: Adicionada prop isTemplate={false} */}
      <EditalForm
        open={showEditalForm}
        onOpenChange={setShowEditalForm}
        onSubmit={editalParaEditar ? handleEditarEdital : handleCriarEditalPessoal}
        titulo={editalParaEditar ? "Editar Edital" : "Novo Edital Pessoal"}
        subtitulo={editalParaEditar ? "Altere as informações do edital" : "Crie um novo edital para organizar seus estudos"}
        editalInicial={editalParaEditar}
        isTemplate={false}
      />

      {/* Dialog de Gerenciar Disciplinas */}
      {editalParaGerenciar && (
        <GerenciarDisciplinasDialog
          open={showGerenciarDialog}
          onOpenChange={setShowGerenciarDialog}
          edital={editalParaGerenciar}
          onSave={carregarDados}
        />
      )}
    </div>
  );
}
