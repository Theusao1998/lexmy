import React from "react";
import { Puzzle } from "lucide-react";
import EmBreveCard from "@/components/ui/EmBreveCard";

export default function Jogos() {
  return (
    <EmBreveCard
      titulo="Jogos Jurídicos Em Breve"
      descricao="Estamos desenvolvendo jogos educativos para tornar seu aprendizado ainda mais dinâmico e divertido. Em breve você terá acesso a quizzes, desafios e muito mais!"
      icone={Puzzle}
    />
  );
}