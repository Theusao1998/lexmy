
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Brain,
  Search,
  Filter,
  X,
  Maximize2
} from "lucide-react";
import { MapaMental } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function MapasMentaisPage() {
  const [mapasMentais, setMapasMentais] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Filtros
  const [filtroDisciplina, setFiltroDisciplina] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Visualização de mapa mental
  const [mapaSelecionado, setMapaSelecionado] = useState(null);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    carregarMapas();
  }, []);

  const carregarMapas = async () => {
    setLoading(true);
    try {
      const data = await MapaMental.list('-created_date', 100);
      setMapasMentais(data);
    } catch (error) {
      console.error('Erro ao carregar mapas mentais:', error);
    } finally {
      setLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = mapasMentais.map(m => m.disciplina).filter(Boolean);
    return [...new Set(disciplinas)].sort();
  }, [mapasMentais]);

  const mapasFiltrados = React.useMemo(() => {
    return mapasMentais.filter(m => {
      const matchDisciplina = filtroDisciplina === "all" || m.disciplina === filtroDisciplina;
      const matchBusca = !filtroBusca || 
        m.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        m.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        m.tags?.some(tag => tag.toLowerCase().includes(filtroBusca.toLowerCase()));
      return matchDisciplina && matchBusca;
    });
  }, [mapasMentais, filtroDisciplina, filtroBusca]);

  const handleVisualizarMapa = (mapa) => {
    setMapaSelecionado(mapa);
    setShowModal(true);
  };

  const handleFecharModal = () => {
    setShowModal(false);
    setMapaSelecionado(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Mapas Mentais
          </h1>
          <p className="text-slate-600 max-w-2xl">
            Visualizações interativas para facilitar o aprendizado
          </p>
        </div>

        {/* Filtros */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                  <Filter className="w-4 h-4" />
                  Disciplina
                </label>
                <Select value={filtroDisciplina} onValueChange={setFiltroDisciplina}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as disciplinas</SelectItem>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                  <Search className="w-4 h-4" />
                  Buscar
                </label>
                <Input
                  placeholder="Digite o título, disciplina ou tag..."
                  value={filtroBusca}
                  onChange={(e) => setFiltroBusca(e.target.value)}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Mapas Mentais */}
        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-600 border-t-transparent"></div>
          </div>
        ) : mapasFiltrados.length === 0 ? (
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
            <CardContent className="p-12 text-center">
              <div className="w-16 h-16 mx-auto mb-6 bg-purple-100 rounded-full flex items-center justify-center">
                <Brain className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Nenhum mapa mental encontrado
              </h3>
              <p className="text-slate-600">
                {filtroDisciplina !== "all" || filtroBusca
                  ? "Tente ajustar os filtros de busca"
                  : "Nenhum mapa mental disponível ainda."}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {mapasFiltrados.map((mapa) => (
              <Card 
                key={mapa.id} 
                className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all cursor-pointer group"
                onClick={() => handleVisualizarMapa(mapa)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center text-white">
                      <Brain className="w-6 h-6" />
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="text-slate-400 group-hover:text-purple-600"
                    >
                      <Maximize2 className="w-5 h-5" />
                    </Button>
                  </div>
                  <CardTitle className="text-lg group-hover:text-purple-600 transition-colors">
                    {mapa.titulo}
                  </CardTitle>
                  {mapa.descricao && (
                    <p className="text-sm text-slate-600 line-clamp-2 mt-2">
                      {mapa.descricao}
                    </p>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {mapa.disciplina && (
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        {mapa.disciplina}
                      </Badge>
                    )}
                    {mapa.tags?.slice(0, 3).map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="bg-slate-50 text-slate-600">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Modal de Visualização do Mapa Mental */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-[95vw] max-h-[95vh] w-full h-full overflow-hidden p-0 [&>button]:hidden">
          <DialogHeader className="p-4 pb-3 border-b bg-white/80 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Brain className="w-4 h-4 text-white" />
                </div>
                <div className="min-w-0 flex-1">
                  <DialogTitle className="text-base font-semibold truncate">{mapaSelecionado?.titulo}</DialogTitle>
                  {mapaSelecionado?.disciplina && (
                    <p className="text-xs text-slate-600 truncate">{mapaSelecionado.disciplina}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => {
                    const modalContent = document.querySelector('.mapa-mental-container');
                    if (modalContent) {
                      if (!document.fullscreenElement) {
                        modalContent.requestFullscreen?.() || 
                        modalContent.webkitRequestFullscreen?.() || 
                        modalContent.mozRequestFullScreen?.();
                      } else {
                        document.exitFullscreen?.() || 
                        document.webkitExitFullscreen?.() || 
                        document.mozCancelFullScreen?.();
                      }
                    }
                  }}
                  className="rounded-full"
                  title="Tela cheia"
                >
                  <Maximize2 className="w-4 h-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleFecharModal}
                  className="rounded-full"
                  title="Fechar"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </DialogHeader>
          
          <div className="flex-1 overflow-auto p-6">
            {mapaSelecionado && (
              <div 
                className="mapa-mental-container"
                dangerouslySetInnerHTML={{ __html: mapaSelecionado.conteudo_renderizado_html }}
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
