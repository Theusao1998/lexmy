
import React, { useState, useEffect, useCallback, useRef } from "react";
import { format, addDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Calendar as CalendarIcon,
  MessageSquare,
  Send,
  RefreshCw,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
  BookOpen,
  Target,
  Plus,
  Clock, // Added
  Lightbulb, // Added
  Sparkles // Added
} from "lucide-react";
import { BlocoRotina } from "@/api/entities";
import { Edital } from "@/api/entities";
import { base44 } from "@/api/base44Client";
import MessageBubble from "@/components/agentes/MessageBubble";
import { Input } from "@/components/ui/input";
import BlocoRotinaCard from "@/components/planner/BlocoRotinaCard";
import { startOfDay, subDays } from "date-fns";
import { Calendar } from "@/components/ui/calendar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import BlocoRotinaForm from "@/components/planner/BlocoRotinaForm";

const diasSemanaMap = {
  0: "domingo",
  1: "segunda",
  2: "terca",
  3: "quarta",
  4: "quinta",
  5: "sexta",
  6: "sabado"
};

export default function PlannerPage() {
  const [blocosRotina, setBlocosRotina] = useState([]);
  const [editais, setEditais] = useState([]);
  const [dataSelecionada, setDataSelecionada] = useState(new Date());

  // Estados do chat com assistente
  const [conversationId, setConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Estados para o formulário de blocos
  const [showBlocoForm, setShowBlocoForm] = useState(false);
  const [blocoEdicao, setBlocoEdicao] = useState(null);

  // Ref para o container de mensagens do chat
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);

  // Chave para localStorage
  const STORAGE_KEY = 'planner_lex_conversation_id';

  // Função para rolar para o final do chat
  const scrollToBottom = () => {
    if (messagesContainerRef.current) {
      messagesContainerRef.current.scrollTop = messagesContainerRef.current.scrollHeight;
    }
  };

  // Rolar para o final sempre que as mensagens mudarem
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    carregarDados();
    inicializarConversa();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const blocos = await BlocoRotina.list('-created_date');
      setBlocosRotina(blocos);
      
      const editaisUsuario = await Edital.list();
      setEditais(editaisUsuario);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const inicializarConversa = async () => {
    setIsLoading(true);
    try {
      const user = await base44.auth.me();
      if (!user) {
        console.error('Usuário não autenticado');
        return;
      }

      // Tentar carregar conversationId do localStorage
      const storedConversationId = localStorage.getItem(STORAGE_KEY);
      let activeConversationId = null;
      let activeMessages = [];
      
      if (storedConversationId) {
        try {
          // Tentar carregar a conversa armazenada
          const conversaExistente = await base44.agents.getConversation(storedConversationId);
          activeConversationId = conversaExistente.id;
          activeMessages = conversaExistente.messages || [];
          console.log('Conversa carregada do localStorage:', conversaExistente.id);
        } catch (error) {
          console.warn('Conversa armazenada no localStorage não encontrada ou inválida. Criando nova...', error);
          // Se falhar, remove do localStorage e cria uma nova
          localStorage.removeItem(STORAGE_KEY);
        }
      }

      // Se não há conversa no localStorage ou se falhou ao carregar, criar nova
      if (!activeConversationId) {
        console.log('Nenhuma conversa ativa encontrada ou válida. Criando nova...');
        const novaConversa = await base44.agents.createConversation({
          agent_name: "planner_lex",
          metadata: {
            name: "Planejamento de Rotina",
            description: "Conversa com o Planner Lex"
          }
        });
        activeConversationId = novaConversa.id;
        activeMessages = [];
        
        // Salvar no localStorage
        localStorage.setItem(STORAGE_KEY, novaConversa.id);
        console.log('Nova conversa criada e salva:', novaConversa.id);
      }

      setConversationId(activeConversationId);
      setMessages(activeMessages);
      
    } catch (error) {
      console.error('Erro ao inicializar conversa:', error);
      alert('Erro ao carregar ou iniciar a conversa com o Planner Lex. Por favor, tente novamente mais tarde.');
    } finally {
      // setIsLoading(false) moved to carregarDados to avoid premature dismissal if both run in parallel.
      // If carregarDados is guaranteed to finish after inicializarConversa, then this can be here.
      // For now, let's keep it in carregarDados for overall page loading.
    }
  };

  useEffect(() => {
    if (!conversationId) return;

    const unsubscribe = base44.agents.subscribeToConversation(conversationId, (data) => {
      setMessages(data.messages || []);
      setIsSending(false);
    });

    return () => unsubscribe();
  }, [conversationId]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!inputMessage.trim() || !conversationId || isSending) return;

    setIsSending(true);
    try {
      const conversation = await base44.agents.getConversation(conversationId);
      await base44.agents.addMessage(conversation, {
        role: "user",
        content: inputMessage.trim()
      });
      setInputMessage("");

      setTimeout(() => {
        carregarDados();
      }, 3000);
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      alert('Erro ao enviar mensagem. Tente novamente.');
      setIsSending(false);
    }
  };

  // Funções para gerenciar blocos
  const handleCriarBloco = async (dadosBloco) => {
    try {
      await BlocoRotina.create(dadosBloco);
      await carregarDados();
      setShowBlocoForm(false);
      setBlocoEdicao(null);
    } catch (error) {
      console.error('Erro ao criar bloco:', error);
      alert('Erro ao criar bloco. Tente novamente.');
    }
  };

  const handleEditarBloco = async (dadosBloco) => {
    try {
      if (!blocoEdicao || !blocoEdicao.id) {
        throw new Error('ID do bloco para edição não encontrado.');
      }
      await BlocoRotina.update(blocoEdicao.id, dadosBloco);
      await carregarDados();
      setShowBlocoForm(false);
      setBlocoEdicao(null);
    } catch (error) {
      console.error('Erro ao editar bloco:', error);
      alert('Erro ao editar bloco. Tente novamente.');
    }
  };

  const handleAbrirFormularioEdicao = (bloco) => {
    setBlocoEdicao(bloco);
    setShowBlocoForm(true);
  };

  const handleFecharFormulario = () => {
    setShowBlocoForm(false);
    setBlocoEdicao(null);
  };

  const handleDeleteBloco = async (blocoId) => {
    if (!confirm('Tem certeza que deseja excluir este bloco da rotina?')) return;

    try {
      await BlocoRotina.delete(blocoId);
      await carregarDados();
    } catch (error) {
      console.error('Erro ao excluir bloco:', error);
      alert('Erro ao excluir bloco.');
    }
  };

  const handleConcluirBloco = async (bloco) => {
    if (!bloco.topico_edital_ref) {
      alert('Este bloco não está vinculado a um tópico do edital.');
      return;
    }

    try {
      const { edital_id, disciplina_nome, topico_titulo } = bloco.topico_edital_ref;
      
      if (!edital_id || !disciplina_nome || !topico_titulo) {
        alert('Referência ao edital está incompleta.');
        return;
      }
      
      const edital = await Edital.get(edital_id);
      
      if (!edital || !edital.disciplinas) {
        alert('Edital não encontrado ou sem disciplinas.');
        return;
      }

      const disciplinaIndex = edital.disciplinas.findIndex(d => d.nome === disciplina_nome);
      if (disciplinaIndex === -1) {
        alert(`Disciplina "${disciplina_nome}" não encontrada no edital.`);
        return;
      }

      const topicoIndex = edital.disciplinas[disciplinaIndex].topicos?.findIndex(t => t.titulo === topico_titulo);
      if (topicoIndex === -1 || topicoIndex === undefined) {
        alert(`Tópico "${topico_titulo}" não encontrado na disciplina.`);
        return;
      }

      const disciplinasClone = JSON.parse(JSON.stringify(edital.disciplinas));
      const hoje = format(new Date(), 'yyyy-MM-dd');
      
      if (bloco.tipo_atividade === 'revisao' && bloco.revisao_tipo) {
        const campoRevisao = `revisao_${bloco.revisao_tipo}_em`;
        disciplinasClone[disciplinaIndex].topicos[topicoIndex][campoRevisao] = hoje;
        
        await Edital.update(edital_id, { disciplinas: disciplinasClone });
        await carregarDados();
        
        alert(`Revisão de ${bloco.revisao_tipo.replace('d', ' dia(s)')} concluída!`);
        
      } else if (bloco.tipo_atividade === 'estudo') {
        disciplinasClone[disciplinaIndex].topicos[topicoIndex].estudado_em = hoje;

        await Edital.update(edital_id, { disciplinas: disciplinasClone });

        const dataEstudo = startOfDay(new Date());
        const revisoesConfig = [
          { dias: 1, tipo: '1d', nome: 'Revisão de 1 dia' },
          { dias: 7, tipo: '7d', nome: 'Revisão de 7 dias' },
          { dias: 14, tipo: '14d', nome: 'Revisão de 14 dias' },
          { dias: 30, tipo: '30d', nome: 'Revisão de 30 dias' },
          { dias: 90, tipo: '90d', nome: 'Revisão de 90 dias' }
        ];

        const blocosRevisaoCriados = [];
        
        for (const revisao of revisoesConfig) {
          try {
            const dataRevisao = addDays(dataEstudo, revisao.dias);
            const diaSemana = diasSemanaMap[dataRevisao.getDay()];
            const dataRevisaoStr = format(dataRevisao, 'yyyy-MM-dd');

            const novoBlocoRevisao = {
              dia_semana: diaSemana,
              horario_inicio: bloco.horario_inicio || "08:00",
              horario_fim: bloco.horario_fim || "09:00",
              atividade: topico_titulo,
              disciplina: disciplina_nome,
              tipo_atividade: 'revisao',
              revisao_tipo: revisao.tipo,
              cor: bloco.cor || '#10b981',
              ativo: true,
              data_inicio_vigencia: dataRevisaoStr,
              data_fim_vigencia: dataRevisaoStr,
              recorrente: false,
              topico_edital_ref: {
                edital_id: edital_id,
                disciplina_nome: disciplina_nome,
                topico_titulo: topico_titulo
              }
            };

            await BlocoRotina.create(novoBlocoRevisao);
            blocosRevisaoCriados.push(revisao.nome);
          } catch (blocoError) {
            console.error(`Erro ao criar bloco de ${revisao.nome}:`, blocoError);
          }
        }

        await carregarDados();
        
        if (blocosRevisaoCriados.length > 0) {
          alert(`Tópico "${topico_titulo}" marcado como estudado!\n\nBlocos de revisão criados: ${blocosRevisaoCriados.join(', ')}.`);
        } else {
          alert(`Tópico "${topico_titulo}" marcado como estudado!\n\nAtenção: Não foi possível criar os blocos de revisão automáticos.`);
        }
      } else {
        alert('Este bloco não pode ser marcado como concluído (tipo de atividade não suportado).');
      }
      
    } catch (error) {
      console.error('Erro ao marcar tópico como concluído:', error);
      alert(`Erro ao marcar tópico como concluído: ${error.message || 'Erro desconhecido'}. Tente novamente.`);
    }
  };

  const limparPlanoDiario = async () => {
    if (blocosDoDia.length === 0) {
      alert('Não há atividades para limpar neste dia.');
      return;
    }

    const dataSelecionadaFormatada = format(dataSelecionada, "EEEE, d 'de' MMMM", { locale: ptBR });
    
    if (!confirm(`Tem certeza que deseja excluir TODAS as ${blocosDoDia.length} atividades de ${dataSelecionadaFormatada}?\n\nEsta ação não pode ser desfeita.`)) {
      return;
    }

    try {
      setIsLoading(true);
      
      const promessas = blocosDoDia.map(bloco => BlocoRotina.delete(bloco.id));
      await Promise.all(promessas);
      
      await carregarDados();
      
      alert(`${blocosDoDia.length} atividades foram removidas com sucesso!`);
    } catch (error) {
      console.error('Erro ao limpar plano diário:', error);
      alert('Erro ao limpar atividades. Tente novamente.');
    } finally {
      setIsLoading(false);
    }
  };

  const navegarDia = (direcao) => {
    if (direcao === 'anterior') {
      setDataSelecionada(subDays(dataSelecionada, 1));
    } else {
      setDataSelecionada(addDays(dataSelecionada, 1));
    }
  };

  const voltarHoje = () => {
    setDataSelecionada(new Date());
  };

  const limparConversa = async () => {
    if (confirm("Deseja iniciar uma nova conversa? Isso reiniciará o chat do zero.")) {
      setIsLoading(true);
      try {
        // Criar uma nova conversa
        const novaConversa = await base44.agents.createConversation({
          agent_name: "planner_lex",
          metadata: {
            name: "Planejamento de Rotina",
            description: "Conversa com o Planner Lex"
          }
        });
        
        // Atualizar estado
        setConversationId(novaConversa.id);
        setMessages([]);
        
        // Salvar novo ID no localStorage
        localStorage.setItem(STORAGE_KEY, novaConversa.id);
        
        console.log('Conversa reiniciada:', novaConversa.id);
        alert('Nova conversa iniciada com sucesso!');
      } catch (error) {
        console.error("Erro ao reiniciar conversa:", error);
        alert("Erro ao iniciar nova conversa. Tente novamente.");
      } finally {
        setIsLoading(false);
      }
    }
  };

  const diaSelecionadoString = diasSemanaMap[dataSelecionada.getDay()];
  const blocosDoDia = blocosRotina
    .filter((b) => {
      if (b.dia_semana !== diaSelecionadoString || !b.ativo) {
        return false;
      }

      if (!b.data_inicio_vigencia && !b.data_fim_vigencia) {
        return true;
      }

      const dataSelecionadaStr = format(dataSelecionada, 'yyyy-MM-dd');

      if (b.recorrente && b.data_inicio_vigencia) {
        return dataSelecionadaStr >= b.data_inicio_vigencia;
      }

      const dentroDoInicio = !b.data_inicio_vigencia || dataSelecionadaStr >= b.data_inicio_vigencia;
      const dentroDoFim = !b.data_fim_vigencia || dataSelecionadaStr <= b.data_fim_vigencia;

      return dentroDoInicio && dentroDoFim;
    })
    .sort((a, b) => a.horario_inicio.localeCompare(b.horario_inicio));

  const agruparBlocosPorDisciplina = (blocos) => {
    const grupos = {};
    const semDisciplina = [];

    blocos.forEach(bloco => {
      if (!bloco.disciplina || bloco.disciplina.trim() === '') {
        semDisciplina.push(bloco);
        return;
      }

      if (!grupos[bloco.disciplina]) {
        grupos[bloco.disciplina] = {
          estudo: [],
          revisao: [],
          exercicios: [],
          simulado: [],
          outros: []
        };
      }

      const tipo = bloco.tipo_atividade;
      if (tipo === 'estudo') {
        grupos[bloco.disciplina].estudo.push(bloco);
      } else if (tipo === 'revisao') {
        grupos[bloco.disciplina].revisao.push(bloco);
      } else if (tipo === 'exercicios') {
        grupos[bloco.disciplina].exercicios.push(bloco);
      } else if (tipo === 'simulado') {
        grupos[bloco.disciplina].simulado.push(bloco);
      } else {
        grupos[bloco.disciplina].outros.push(bloco);
      }
    });

    return { grupos, semDisciplina };
  };

  const { grupos: blocosPorDisciplina, semDisciplina: outrasAtividades } = agruparBlocosPorDisciplina(blocosDoDia);
  const disciplinasOrdenadas = Object.keys(blocosPorDisciplina).sort();
  const ehHoje = startOfDay(dataSelecionada).getTime() === startOfDay(new Date()).getTime();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 flex items-center justify-center">
        <div className="flex items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="text-slate-600">Carregando...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Planner
          </h1>
          <p className="text-slate-600">
            Organize sua rotina de estudos com a ajuda do assistente de planejamento
          </p>
        </div>

        <Tabs defaultValue="planner-lex" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm shadow-lg">
            <TabsTrigger value="planner-lex" className="gap-2">
              <MessageSquare className="w-4 h-4" />
              Planner Lex
            </TabsTrigger>
            <TabsTrigger value="visao-mensal" className="gap-2">
              <CalendarIcon className="w-4 h-4" />
              Visão Mensal
            </TabsTrigger>
            <TabsTrigger value="plano-diario" className="gap-2">
              <BookOpen className="w-4 h-4" />
              Plano Diário
            </TabsTrigger>
          </TabsList>

          {/* Aba 1: Planner Lex */}
          <TabsContent value="planner-lex" className="mt-6">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="relative">
                      <img 
                        src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/689cc9827607abbfa2b6e9c0/b106ef135_ChatGPTImage18deoutde202513_02_13.png"
                        alt="Planner Lex"
                        className="w-16 h-16 rounded-full border-4 border-white shadow-lg object-cover"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                          e.currentTarget.nextElementSibling.style.display = 'flex';
                        }}
                      />
                      <div 
                        className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center shadow-lg"
                        style={{ display: 'none' }}
                      >
                        <CalendarIcon className="w-8 h-8 text-white" />
                      </div>
                      <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                    </div>
                    <div>
                      <CardTitle className="font-semibold tracking-tight text-xl">
                        Planner Lex
                      </CardTitle>
                      <p className="text-sm text-slate-600 mt-1">
                        Seu assistente para uma rotina de estudos perfeita
                      </p>
                      <div className="flex gap-2 mt-2 flex-wrap">
                        <Badge className="bg-blue-100 text-blue-700 border-blue-200 gap-1">
                          <CalendarIcon className="w-3 h-3" />
                          Organização de Rotina
                        </Badge>
                        <Badge className="bg-amber-100 text-amber-700 border-amber-200 gap-1">
                          <Clock className="w-3 h-3" />
                          Otimização de Tempo
                        </Badge>
                        <Badge className="bg-green-100 text-green-700 border-green-200 gap-1">
                          <Sparkles className="w-3 h-3" />
                          IA Avançada
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={limparConversa}
                    className="gap-2 hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                  >
                    <RotateCcw className="w-4 h-4" />
                    Limpar
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div 
                  ref={messagesContainerRef}
                  className="h-[500px] overflow-y-auto border rounded-lg p-3 bg-slate-50 space-y-3"
                >
                  {messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center px-4">
                      <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center mb-6 shadow-lg">
                        <CalendarIcon className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 mb-3">
                        Olá! Sou o Planner Lex
                      </h3>
                      <p className="text-slate-600 max-w-md mb-4 leading-relaxed">
                        Vou te ajudar a distribuir os tópicos do seu edital ao longo da semana de forma inteligente e sustentável.
                      </p>
                      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 max-w-md">
                        <p className="text-sm text-blue-800 font-medium mb-2">
                          Para começar, me conte:
                        </p>
                        <ul className="text-xs text-blue-700 space-y-1 text-left">
                          <li>• Você trabalha ou estuda em período integral?</li>
                          <li>• Quantas horas por dia você tem disponíveis para estudar?</li>
                          <li>• Em quais dias da semana você pode estudar?</li>
                        </ul>
                      </div>
                    </div>
                  ) : (
                    <>
                      {messages.map((msg, idx) => (
                        <MessageBubble
                          key={idx}
                          message={msg}
                          avatarUrl="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/689cc9827607abbfa2b6e9c0/b106ef135_ChatGPTImage18deoutde202513_02_13.png"
                        />
                      ))}
                      <div ref={messagesEndRef} />
                    </>
                  )}
                </div>

                <form onSubmit={handleSendMessage} className="flex gap-2">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    placeholder="Digite sua mensagem..."
                    disabled={isSending}
                    className="flex-1"
                  />
                  <Button type="submit" disabled={isSending || !inputMessage.trim()} size="icon">
                    <Send className="w-4 h-4" />
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Card de Dicas de Uso */}
            <Card className="mt-6 bg-white/60 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-amber-600" />
                  Dicas de Uso
                </h3>
                
                <div className="space-y-4">
                  <div>
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">
                      💡 O que o Planner Lex pode fazer:
                    </h4>
                    <ul className="text-sm text-slate-600 space-y-1 ml-4 list-disc list-inside">
                      <li>Criar sua rotina semanal de estudos de forma personalizada</li>
                      <li>Distribuir tópicos do seu edital ao longo da semana</li>
                      <li>Considerar seu tempo disponível e carga de trabalho</li>
                      <li>Priorizar disciplinas com maior peso ou dificuldade</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">
                      🎯 Como interagir para melhores resultados:
                    </h4>
                    <ul className="text-sm text-slate-600 space-y-1 ml-4 list-disc list-inside">
                      <li>Seja específico sobre seus horários disponíveis</li>
                      <li>Informe se trabalha ou estuda em período integral</li>
                      <li>Mencione disciplinas prioritárias ou com maior dificuldade</li>
                      <li>Deixe claro quantas horas por dia você pode dedicar aos estudos</li>
                    </ul>
                  </div>

                  <div>
                    <h4 className="text-sm font-semibold text-slate-700 mb-2">
                      📝 Exemplos de perguntas:
                    </h4>
                    <div className="grid md:grid-cols-2 gap-2">
                      {[
                        "Quero montar minha rotina semanal, por onde começo?",
                        "Tenho 3 horas por dia para estudar, como distribuo os tópicos?",
                        "Como organizo minha semana considerando que trabalho de manhã?",
                        "Quais tópicos do meu edital devo priorizar esta semana?",
                      ].map((exemplo, index) => (
                        <button
                          key={index}
                          onClick={() => setInputMessage(exemplo)}
                          className="text-left p-3 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs text-slate-700 transition-colors"
                        >
                          "{exemplo}"
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-4">
                    <p className="text-xs text-amber-800">
                      <strong>💡 Dica:</strong> O Planner Lex trabalha melhor quando você fornece informações detalhadas sobre sua rotina e objetivos. Quanto mais específico, melhor será o planejamento!
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Aba 2: Visão Mensal */}
          <TabsContent value="visao-mensal" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <CalendarIcon className="w-5 h-5 text-blue-600" />
                    Visão Geral do Mês
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="w-full">
                      <Calendar
                        mode="single"
                        selected={dataSelecionada}
                        onSelect={(date) => date && setDataSelecionada(date)}
                        locale={ptBR}
                        className="rounded-md border w-full"
                        classNames={{
                          months: "w-full",
                          month: "w-full space-y-4",
                          caption: "flex justify-center pt-1 relative items-center",
                          caption_label: "text-sm font-medium",
                          nav: "space-x-1 flex items-center",
                          nav_button: "h-7 w-7 bg-transparent p-0 opacity-50 hover:opacity-100",
                          table: "w-full border-collapse space-y-1",
                          head_row: "flex w-full",
                          head_cell: "text-slate-500 rounded-md w-full font-normal text-[0.8rem]",
                          row: "flex w-full mt-2",
                          cell: "text-center text-sm p-0 relative [&:has([aria-selected])]:bg-slate-100 first:[&:has([aria-selected])]:rounded-l-md last:[&:has([aria-selected])]:rounded-r-md focus-within:relative focus-within:z-20 w-full",
                          day: "h-12 w-full p-0 font-normal aria-selected:opacity-100 hover:bg-slate-100 rounded-md",
                          day_selected: "bg-blue-600 text-white hover:bg-blue-700 hover:text-white focus:bg-blue-600 focus:text-white",
                          day_today: "bg-slate-100 text-slate-900 font-semibold",
                          day_outside: "text-slate-400 opacity-50",
                          day_disabled: "text-slate-400 opacity-50",
                          day_hidden: "invisible"
                        }}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-blue-50/50 rounded-lg p-4 text-center">
                        <p className="text-3xl font-bold text-blue-700">
                          {blocosRotina.filter((b) => b.ativo && ['estudo', 'revisao', 'exercicios'].includes(b.tipo_atividade)).length}
                        </p>
                        <p className="text-xs text-slate-600 mt-1">Blocos de Estudo/Semana</p>
                      </div>
                      <div className="bg-green-50/50 rounded-lg p-4 text-center">
                        <p className="text-3xl font-bold text-green-700">
                          {new Set(blocosRotina.filter((b) => b.ativo && b.disciplina).map((b) => b.disciplina)).size}
                        </p>
                        <p className="text-xs text-slate-600 mt-1">Disciplinas Ativas</p>
                      </div>
                    </div>

                    <Button
                      variant="outline"
                      size="sm"
                      onClick={carregarDados}
                      className="w-full gap-2"
                    >
                      <RefreshCw className="w-4 h-4" />
                      Atualizar Dados
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Target className="w-5 h-5 text-amber-600" />
                    Resumo Semanal
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-7 gap-2">
                      {['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((dia, idx) => (
                        <div key={idx} className="text-center">
                          <p className="text-xs text-slate-500 font-medium mb-2">{dia}</p>
                          <div className="h-16 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg flex items-center justify-center">
                            <p className="text-lg font-bold text-blue-700">
                              {blocosRotina.filter(b => 
                                b.ativo && 
                                b.dia_semana === Object.values(diasSemanaMap)[idx] &&
                                ['estudo', 'revisao', 'exercicios'].includes(b.tipo_atividade)
                              ).length}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="pt-4 border-t">
                      <p className="text-sm text-slate-600 text-center">
                        Visualização dos blocos de estudo distribuídos pela semana
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Aba 3: Plano Diário */}
          <TabsContent value="plano-diario" className="mt-6">
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
              <CardHeader>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center gap-3">
                      <CalendarIcon className="w-5 h-5 text-blue-600" />
                      Plano Diário
                    </CardTitle>
                  </div>

                  {/* Barra de botões organizada */}
                  <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t">
                    {/* Navegação de Data */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navegarDia('anterior')}
                      >
                        <ChevronLeft className="w-4 h-4" />
                      </Button>
                      <div className="text-center min-w-[200px]">
                        <p className="font-semibold text-slate-800">
                          {format(dataSelecionada, "EEEE", { locale: ptBR })}
                        </p>
                        <p className="text-sm text-slate-600">
                          {format(dataSelecionada, "d 'de' MMMM", { locale: ptBR })}
                        </p>
                      </div>
                      {!ehHoje && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={voltarHoje}
                          className="text-blue-600"
                        >
                          Hoje
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => navegarDia('proximo')}
                      >
                        <ChevronRight className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* Ações */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setBlocoEdicao(null);
                          setShowBlocoForm(true);
                        }}
                        className="gap-2 bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                      >
                        <Plus className="w-4 h-4" />
                        Adicionar Bloco
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={carregarDados}
                        className="gap-2"
                      >
                        <RefreshCw className="w-4 h-4" />
                        Atualizar
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={limparPlanoDiario}
                        disabled={blocosDoDia.length === 0}
                        className="gap-2 hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                      >
                        <RotateCcw className="w-4 h-4" />
                        Limpar Dia
                      </Button>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {blocosDoDia.length === 0 ? (
                  <div className="text-center py-12 text-slate-500">
                    <CalendarIcon className="w-12 h-12 mx-auto mb-4 text-slate-300" />
                    <p className="text-lg">Nenhuma atividade planejada para este dia</p>
                    <p className="text-sm mt-2">
                      Use o Planner Lex ou clique em "Adicionar Bloco" para criar sua rotina
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    {disciplinasOrdenadas.map((disciplina) => {
                      const tiposDisciplina = blocosPorDisciplina[disciplina];
                      const temBlocos = tiposDisciplina.estudo.length > 0 || 
                                       tiposDisciplina.revisao.length > 0 || 
                                       tiposDisciplina.exercicios.length > 0 || 
                                       tiposDisciplina.simulado.length > 0 ||
                                       tiposDisciplina.outros.length > 0;
                      
                      if (!temBlocos) return null;

                      return (
                        <div key={disciplina} className="border-l-4 border-blue-500 pl-4">
                          <h3 className="text-lg font-bold text-slate-800 mb-3">
                            {disciplina}
                          </h3>
                          
                          <div className="space-y-4">
                            {tiposDisciplina.estudo.length > 0 && (
                              <div>
                                <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                                  Estudo
                                </h4>
                                <div className="space-y-2 ml-4">
                                  {tiposDisciplina.estudo.map((bloco) => (
                                    <BlocoRotinaCard
                                      key={bloco.id}
                                      bloco={bloco}
                                      editais={editais}
                                      onDelete={handleDeleteBloco}
                                      onConcluir={handleConcluirBloco}
                                      onEdit={handleAbrirFormularioEdicao}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}

                            {tiposDisciplina.revisao.length > 0 && (
                              <div>
                                <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                                  Revisão
                                </h4>
                                <div className="space-y-2 ml-4">
                                  {tiposDisciplina.revisao.map((bloco) => (
                                    <BlocoRotinaCard
                                      key={bloco.id}
                                      bloco={bloco}
                                      editais={editais}
                                      onDelete={handleDeleteBloco}
                                      onConcluir={handleConcluirBloco}
                                      onEdit={handleAbrirFormularioEdicao}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}

                            {tiposDisciplina.exercicios.length > 0 && (
                              <div>
                                <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                                  Exercícios
                                </h4>
                                <div className="space-y-2 ml-4">
                                  {tiposDisciplina.exercicios.map((bloco) => (
                                    <BlocoRotinaCard
                                      key={bloco.id}
                                      bloco={bloco}
                                      editais={editais}
                                      onDelete={handleDeleteBloco}
                                      onConcluir={handleConcluirBloco}
                                      onEdit={handleAbrirFormularioEdicao}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}

                            {tiposDisciplina.simulado.length > 0 && (
                              <div>
                                <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                                  Simulado
                                </h4>
                                <div className="space-y-2 ml-4">
                                  {tiposDisciplina.simulado.map((bloco) => (
                                    <BlocoRotinaCard
                                      key={bloco.id}
                                      bloco={bloco}
                                      editais={editais}
                                      onDelete={handleDeleteBloco}
                                      onConcluir={handleConcluirBloco}
                                      onEdit={handleAbrirFormularioEdicao}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}

                            {tiposDisciplina.outros.length > 0 && (
                              <div>
                                <h4 className="text-sm font-semibold text-slate-700 mb-2 flex items-center gap-2">
                                  <div className="w-2 h-2 bg-slate-400 rounded-full"></div>
                                  Outras Atividades
                                </h4>
                                <div className="space-y-2 ml-4">
                                  {tiposDisciplina.outros.map((bloco) => (
                                    <BlocoRotinaCard
                                      key={bloco.id}
                                      bloco={bloco}
                                      editais={editais}
                                      onDelete={handleDeleteBloco}
                                      onConcluir={handleConcluirBloco}
                                      onEdit={handleAbrirFormularioEdicao}
                                    />
                                  ))}
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}

                    {outrasAtividades.length > 0 && (
                      <div className="border-l-4 border-slate-400 pl-4">
                        <h3 className="text-lg font-bold text-slate-800 mb-3">
                          Outras Atividades
                        </h3>
                        <div className="space-y-2 ml-4">
                          {outrasAtividades.map((bloco) => (
                            <BlocoRotinaCard
                              key={bloco.id}
                              bloco={bloco}
                              editais={editais}
                              onDelete={handleDeleteBloco}
                              onConcluir={handleConcluirBloco}
                              onEdit={handleAbrirFormularioEdicao}
                            />
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Formulário de Bloco de Rotina */}
        <BlocoRotinaForm
          isOpen={showBlocoForm}
          onClose={handleFecharFormulario}
          onSubmit={blocoEdicao ? handleEditarBloco : handleCriarBloco}
          bloco={blocoEdicao}
          diaSemanaInicial={diasSemanaMap[dataSelecionada.getDay()]}
          dataInicial={format(dataSelecionada, 'yyyy-MM-dd')}
        />
      </div>
    </div>
  );
}
