

import React, { useState, useEffect, useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Bell,
  Brain,
  BookMarked,
  ClipboardList,
  Headphones,
  HelpCircle,
  LayoutDashboard,
  LogOut,
  Menu,
  MessageSquare,
  Newspaper,
  Puzzle,
  Settings,
  Shield,
  Timer,
  User as UserIcon,
  Library,
  FileImage,
  Calendar as CalendarIcon,
  ListChecks,
  Clock,
  Sparkles
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger
} from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import TimerSidebarSummary from "@/components/timer/TimerSidebarSummary";
import { TimerProvider, useTimer } from "@/components/timer/TimerContext";
import { User as UserEntity } from "@/api/entities";
import LexmyLogo from "@/components/brand/LexmyLogo";
import { obterEstatisticasHoje } from "@/components/utils/metasHelper";
import BrasiliaClock from "@/components/utils/BrasiliaClock";
import { SessaoEstudo } from "@/api/entities";
import { base44 } from '@/api/base44Client';

const navigationItems = [
  {
    title: "Dashboard",
    url: createPageUrl("Dashboard"),
    icon: LayoutDashboard,
    description: "Visão geral dos estudos"
  },
  {
    title: "Biblioteca",
    url: createPageUrl("Biblioteca"),
    icon: Library,
    description: "Seus materiais de estudo"
  },
  {
    title: "Legislação em Áudio",
    url: createPageUrl("LegislacaoAudio"),
    icon: Headphones,
    description: "Áudios de leis"
  },
  {
    title: "Treinamento",
    url: createPageUrl("Treinamento"),
    icon: Brain,
    description: "Questões e simulados"
  },
  {
    title: "Questões",
    url: createPageUrl("Questoes"),
    icon: HelpCircle,
    description: "Múltipla escolha"
  },
  {
    title: "Discursivas",
    url: createPageUrl("Discursivas"),
    icon: Newspaper,
    description: "Questões discursivas"
  },
  {
    title: "Simulados",
    url: createPageUrl("Simulados"),
    icon: ListChecks,
    description: "Simulados completos"
  },
  {
    title: "Temporizador",
    url: createPageUrl("Temporizador"),
    icon: Timer,
    description: "Sessões de estudo"
  },
  {
    title: "Planner",
    url: createPageUrl("Planner"),
    icon: CalendarIcon,
    description: "Organize sua rotina"
  },
  {
    title: "Edital",
    url: createPageUrl("Edital"),
    icon: ClipboardList,
    description: "Verticalize seu edital"
  },
  {
    title: "Mapas Mentais",
    url: createPageUrl("MapasMentais"),
    icon: Brain,
    description: "Visualizações interativas"
  },
  {
    title: "Comunidade",
    url: createPageUrl("Comunidade"),
    icon: MessageSquare,
    description: "Interaja com outros"
  },
  {
    title: "Jogos",
    url: createPageUrl("Jogos"),
    icon: Puzzle,
    description: "Aprenda jogando"
  },
  {
    title: "Prof. Lex",
    url: createPageUrl("ProfLex"),
    icon: Shield,
    description: "Tire suas dúvidas"
  },
];


function LayoutContent({ children, currentPageName }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [assinatura, setAssinatura] = useState(null);
  const [diasRestantes, setDiasRestantes] = useState(null);
  const [loading, setLoading] = useState(true);
  const [estatisticasQuestoes, setEstatisticasQuestoes] = useState({ acertos: 0, total: 0 });
  
  const [tempoEstudadoHoje, setTempoEstudadoHoje] = useState(0);
  
  const { isAtivo, sessaoIniciadaIso, sessoes, calcularTempoEstudadoHoje } = useTimer();

  const paginasPublicas = useMemo(() => ["Home", "Sobre", "Precos", "AtivarPlano"], []);

  // Função para verificar se uma assinatura é válida
  const assinaturaEhValida = (assinatura) => {
    // Se for ativo, é válida
    if (assinatura.status === 'ativo') {
      return true;
    }
    
    // Se for teste, verificar se não expirou
    if (assinatura.status === 'teste' && assinatura.data_teste_fim) {
      const hoje = new Date();
      const dataTesteFim = new Date(assinatura.data_teste_fim);
      
      hoje.setHours(0, 0, 0, 0);
      dataTesteFim.setHours(0, 0, 0, 0);
      
      return hoje <= dataTesteFim;
    }
    
    // Qualquer outro status não é válido
    return false;
  };

  // Função para calcular dias restantes
  const calcularDiasRestantes = (dataFim) => {
    if (!dataFim) return null;
    const hoje = new Date();
    const fim = new Date(dataFim);
    
    hoje.setHours(0, 0, 0, 0);
    fim.setHours(0, 0, 0, 0);
    
    const diff = fim.getTime() - hoje.getTime();
    const dias = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return Math.max(0, dias);
  };

  // Função para criar teste gratuito
  const criarTesteGratuito = async (userEmail) => {
    // Verificar flag de sessão para evitar múltiplas tentativas
    const trialBootstrapped = sessionStorage.getItem('trialBootstrapped');
    if (trialBootstrapped === 'true') {
      console.log('[Layout] Trial já foi processado nesta sessão, pulando...');
      return null;
    }

    console.log('[Layout] Iniciando bootstrap do trial para:', userEmail);

    try {
      const response = await base44.functions.invoke('activateFreeTrial', {});
      console.log('[Layout] Resposta completa do activateFreeTrial:', response);
      
      const { data } = response;
      console.log('[Layout] Data do activateFreeTrial:', data);
      
      if (data && data.success) {
        console.log('[Layout] Trial ativado/recuperado com sucesso:', data.assinatura);
        
        // Marcar como processado nesta sessão
        sessionStorage.setItem('trialBootstrapped', 'true');
        
        return data.assinatura;
      } else {
        console.log('[Layout] Backend retornou erro ou success=false:', data);
        return null;
      }
    } catch (error) {
      console.error('[Layout] Exceção ao chamar activateFreeTrial:', error);
      console.error('[Layout] Detalhes do erro:', {
        message: error.message,
        response: error.response,
        status: error.response?.status,
        data: error.response?.data
      });
      return null;
    }
  };

  const loadData = async () => {
    let currentUserData = null;
    let currentStats = { acertos: 0, total: 0 };

    try {
      // PASSO 1: Carregar dados do usuário
      try {
        currentUserData = await UserEntity.me();
        setUser(currentUserData);
        console.log('[Layout] Usuário carregado:', currentUserData.email);
      } catch (userError) {
        console.log('[Layout] Erro ao carregar usuário:', userError);
        
        if (userError.response?.status === 401 || String(userError.message).includes('401') || String(userError.message).includes('Unauthorized')) {
          setUser(null);
          setLoading(false);
          return;
        }
        setUser(null);
      }

      // PASSO 2: Verificar assinatura (apenas para páginas protegidas)
      if (currentUserData && !paginasPublicas.includes(currentPageName)) {
        try {
          console.log('[Layout] Verificando assinatura para:', currentUserData.email);
          
          // GUARD ANTI-LOOP: Verificar se o trial acabou de ser ativado
          const trialJustActivated = sessionStorage.getItem('trialActivated') === '1';
          
          if (trialJustActivated) {
            console.log('[Layout] Trial recém-ativado detectado (flag sessionStorage), permitindo acesso ao Dashboard');
            
            // Tentar buscar a assinatura mesmo assim (para exibir informações no Layout)
            try {
              const assinaturas = await base44.entities.Assinatura.filter({
                user_email: currentUserData.email
              });
              
              console.log('[Layout] Assinaturas encontradas após trial ativado:', assinaturas.length);
              
              if (assinaturas.length > 0) {
                const assinaturaRecente = assinaturas[0];
                setAssinatura(assinaturaRecente);
                
                console.log('[Layout] Assinatura carregada após trial:', assinaturaRecente.status, assinaturaRecente.id);
                
                // IMPORTANTE: Só limpar a flag se conseguimos ler a assinatura de teste com sucesso
                if (assinaturaRecente.status === 'teste') {
                  console.log('[Layout] Assinatura de teste confirmada - limpando flag trialActivated');
                  sessionStorage.removeItem('trialActivated');
                }
                
                if (assinaturaRecente.status === 'teste' && assinaturaRecente.data_teste_fim) {
                  const dias = calcularDiasRestantes(assinaturaRecente.data_teste_fim);
                  setDiasRestantes(dias);
                }
              }
            } catch (assError) {
              console.log('[Layout] Erro ao buscar assinatura após trial ativado, mas permitindo acesso:', assError);
            }
            
            // PERMITIR ACESSO, não redirecionar
            // Continue para o PASSO 3 (estatísticas)
          } else {
            // Fluxo normal: verificar se é admin ou tem assinatura válida
            const isAdmin = currentUserData.role === 'admin';

            if (isAdmin) {
              console.log('[Layout] Usuário é admin - acesso irrestrito');
              // Buscar assinaturas para exibir informações, mas admin sempre tem acesso
              const assinaturas = await base44.entities.Assinatura.filter({
                user_email: currentUserData.email
              });
              const assinaturaAdmin = assinaturas.length > 0 ? assinaturas[0] : null;
              setAssinatura(assinaturaAdmin);
              
              if (assinaturaAdmin && assinaturaAdmin.status === 'teste' && assinaturaAdmin.data_teste_fim) {
                const dias = calcularDiasRestantes(assinaturaAdmin.data_teste_fim);
                setDiasRestantes(dias);
              }
            } else {
              // Usuário normal - precisa verificar assinatura
              console.log('[Layout] Buscando assinaturas para usuário normal...');
              
              // Buscar todas as assinaturas do usuário
              const assinaturas = await base44.entities.Assinatura.filter({
                user_email: currentUserData.email
              });

              console.log('[Layout] Assinaturas encontradas:', assinaturas.length);

              // Verificar se tem assinatura válida
              const assinaturasValidas = assinaturas.filter(a => assinaturaEhValida(a));
              console.log('[Layout] Assinaturas válidas:', assinaturasValidas.length);
              
              if (assinaturasValidas.length > 0) {
                // TEM ASSINATURA VÁLIDA - usar e prosseguir
                const assinaturaAtiva = assinaturasValidas[0];
                console.log('[Layout] Usando assinatura válida:', assinaturaAtiva.status, assinaturaAtiva.id);
                setAssinatura(assinaturaAtiva);
                
                if (assinaturaAtiva.status === 'teste' && assinaturaAtiva.data_teste_fim) {
                  const dias = calcularDiasRestantes(assinaturaAtiva.data_teste_fim);
                  setDiasRestantes(dias);
                  console.log('[Layout] Dias restantes do teste:', dias);
                }
              } else {
                // NÃO TEM ASSINATURA VÁLIDA - redirecionar para página de ativação
                console.log('[Layout] Usuário sem assinatura válida, redirecionando para AtivarPlano');
                navigate(createPageUrl("AtivarPlano"));
                setLoading(false);
                return; // Interrompe o carregamento
              }
            }
          }
        } catch (assinaturaError) {
          console.error('[Layout] Erro ao verificar assinatura:', assinaturaError);
          // Em caso de erro, redirecionar para ativação por segurança
          if (currentUserData.role !== 'admin') {
            console.log('[Layout] Erro ao carregar assinatura, redirecionando para AtivarPlano');
            navigate(createPageUrl("AtivarPlano"));
            setLoading(false);
            return;
          }
        }
      }

      // PASSO 3: Carregar estatísticas (apenas se usuário autenticado)
      if (currentUserData) {
        try {
          currentStats = await obterEstatisticasHoje();
        } catch (statsError) {
          console.log('[Layout] Erro ao carregar estatísticas:', statsError);
          currentStats = { acertos: 0, total: 0 };
        }
      }

      setEstatisticasQuestoes(currentStats);
    } catch (error) {
      console.error('[Layout] Erro geral:', error);
      setUser(null);
      setEstatisticasQuestoes({ acertos: 0, total: 0 });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [currentPageName]);

  useEffect(() => {
    const atualizarTempo = () => {
      const novoTempo = calcularTempoEstudadoHoje();
      setTempoEstudadoHoje(Math.round(novoTempo));
    };

    atualizarTempo();
    
  }, [sessoes, sessaoIniciadaIso, calcularTempoEstudadoHoje]);

  const handleLogout = async () => {
    if (confirm('Deseja realmente sair da sua conta?')) {
      try {
        await UserEntity.logout();
        window.location.href = createPageUrl("Home");
      } catch (error) {
        console.error('Erro no logout:', error);
        window.location.href = createPageUrl("Home");
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex items-center gap-3">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          <span className="text-slate-600">Carregando...</span>
        </div>
      </div>
    );
  }

  if (!user && !paginasPublicas.includes(currentPageName)) {
    // This case should ideally be handled by the subscription check redirecting to "Precos"
    // or if `UserEntity.me()` fails for a non-public page, it should redirect to "Home".
    // For now, if no user and not public, redirect to Home.
    window.location.href = createPageUrl("Home");
    return null;
  }

  if (paginasPublicas.includes(currentPageName)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
        {children}
      </div>
    );
  }

  const horas = Math.floor(tempoEstudadoHoje / 60);
  const minutos = tempoEstudadoHoje % 60;
  const progressoTempo = Math.min((tempoEstudadoHoje / 180) * 100, 100);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
      <style>{`
        :root {
          --primary-blue: #1e3a8a;
          --primary-gold: #f59e0b;
          --text-primary: #0f172a;
          --text-secondary: #64748b;
          --surface: #ffffff;
          --surface-secondary: #f8fafc;
        }

        .glass-effect {
          background: rgba(255, 255, 255, 0.85);
          backdrop-filter: blur(20px);
          border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .gradient-text {
          background: linear-gradient(135deg, var(--primary-blue), var(--primary-gold));
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }

        .transition-all {
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
      `}</style>
      
      <SidebarProvider>
        <div className="flex min-h-screen w-full">
          <Sidebar className="border-r-0 shadow-xl glass-effect">
            <SidebarHeader className="border-b border-slate-200/60 p-6">
              <div className="flex items-center justify-center">
                <LexmyLogo className="w-32 h-auto" />
              </div>
            </SidebarHeader>

            <SidebarContent className="p-3">
              {/* NOVO: Banner de Teste Gratuito */}
              {assinatura?.status === 'teste' && diasRestantes !== null && (
                <div className="mb-4 mx-3">
                  <div className="bg-gradient-to-r from-blue-50 to-amber-50/50 rounded-xl p-4 border border-blue-200/50">
                    <div className="flex items-center gap-2 mb-2">
                      <Sparkles className="w-4 h-4 text-blue-600" />
                      <span className="text-xs font-semibold text-blue-800">Teste Gratuito</span>
                    </div>
                    <div className="flex items-baseline gap-1 mb-1">
                      <Clock className="w-3 h-3 text-slate-600" />
                      <span className="text-2xl font-bold text-slate-900">{diasRestantes}</span>
                      <span className="text-sm text-slate-600">dias restantes</span>
                    </div>
                    <Button
                      onClick={() => navigate(createPageUrl("Precos"))}
                      size="sm"
                      className="w-full mt-2 bg-blue-600 hover:bg-blue-700 text-xs h-7"
                    >
                      Assinar Agora
                    </Button>
                  </div>
                </div>
              )}

              {/* Botão de Administração (apenas para admins) */}
              {user?.role === 'admin' && (
                <div className="mb-4 mx-3">
                  <Button
                    onClick={() => navigate(createPageUrl("Administracao"))}
                    className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 shadow-lg gap-2 text-white"
                  >
                    <Settings className="w-4 h-4" />
                    Administração
                  </Button>
                </div>
              )}

              <SidebarGroup>
                <SidebarGroupLabel className="text-xs font-semibold text-slate-600 uppercase tracking-wider px-3 py-3 mb-2">
                  Navegação
                </SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu className="space-y-1">
                    {navigationItems.map((item) => {
                      const isActive = location.pathname === item.url;
                      return (
                        <SidebarMenuItem key={item.title}>
                          <SidebarMenuButton
                            asChild
                            className={`
                              group rounded-xl transition-all duration-300
                              hover:bg-gradient-to-r hover:from-blue-50 hover:to-amber-50/50
                              hover:shadow-sm
                              ${isActive ?
                                'bg-gradient-to-r from-blue-100 to-amber-50 shadow-sm border border-blue-200/50' :
                                'hover:bg-slate-50'}
                            `}>
                            <Link
                              to={item.url}
                              className="flex items-center gap-3 w-full min-h-[56px] px-4 py-3">
                              <div
                                className={`
                                  flex-shrink-0 w-9 h-9 rounded-lg flex items-center justify-center transition-all duration-300
                                  ${isActive ?
                                  'bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-md' :
                                  'bg-slate-100 text-slate-600 group-hover:bg-blue-600 group-hover:text-white'}
                                `}>
                                <item.icon className="w-4 h-4" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <span
                                  className={`
                                    block font-semibold text-sm transition-colors leading-tight
                                    ${isActive ? 'text-blue-800' : 'text-slate-700 group-hover:text-blue-700'}
                                  `}>
                                  {item.title}
                                </span>
                              </div>
                            </Link>
                          </SidebarMenuButton>
                        </SidebarMenuItem>
                      );
                    })}
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>

              <SidebarGroup className="mt-6">
                <SidebarGroupLabel className="text-xs font-semibold text-slate-600 uppercase tracking-wider px-3 py-3 mb-2">
                  Temporizador
                </SidebarGroupLabel>
                <SidebarGroupContent className="space-y-3">
                  <TimerSidebarSummary />
                  <BrasiliaClock />
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>

            <SidebarFooter className="border-t border-slate-200/60 p-4">
              <div className="bg-gradient-to-r from-slate-50 to-blue-50/50 p-4 rounded-xl border border-slate-200/50">
                <div className="flex items-center gap-3 mb-3">
                  {user?.foto_perfil ? (
                    <img
                      src={user.foto_perfil}
                      alt="Foto de perfil"
                      className="w-10 h-10 rounded-full object-cover shadow-md border-2 border-white"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.nextElementSibling.style.display = 'flex';
                      }}
                    />
                  ) : null}
                  <div
                    className="w-10 h-10 bg-gradient-to-br from-amber-400 to-amber-500 rounded-full flex items-center justify-center shadow-md"
                    style={{ display: user?.foto_perfil ? 'none' : 'flex' }}
                  >
                    <span className="text-white font-bold text-sm">
                      {user?.nick ?
                        user.nick.slice(0, 2).toUpperCase() :
                        user?.nome ?
                        user.nome.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() :
                        user?.full_name ?
                        user.full_name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() :
                        'U'
                      }
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-800 text-sm truncate">
                      {user?.nick ? `@${user.nick}` :
                       user?.nome || user?.full_name || 'Usuário'}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {user?.objetivo_concurso || 'Concurseiro'}
                    </p>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button
                    onClick={() => navigate(createPageUrl("Perfil"))}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 text-white gap-2 h-9 text-sm"
                  >
                    <UserIcon className="w-4 h-4" />
                    Perfil
                  </Button>
                  <Button
                    onClick={handleLogout}
                    variant="outline"
                    className="h-9 px-3 hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </SidebarFooter>
          </Sidebar>

          <main className="flex-1 flex flex-col overflow-hidden">
            <header className="bg-white/80 backdrop-blur-xl border-b border-slate-200/60 px-6 py-4 md:hidden shadow-sm">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
                  <LexmyLogo className="w-20 h-auto" />
                </div>
                <Button variant="ghost" size="icon" className="relative">
                  <Bell className="w-5 h-5 text-slate-600" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
                </Button>
              </div>
            </header>

            <div className="flex-1 overflow-auto">
              <div className="min-h-full bg-gradient-to-br from-transparent via-white/30 to-transparent">
                {children}
              </div>
            </div>
          </main>
        </div>
      </SidebarProvider>
    </div>
  );
}

export default function Layout({ children, currentPageName }) {
  return (
    <TimerProvider>
      <LayoutContent currentPageName={currentPageName}>
        {children}
      </LayoutContent>
    </TimerProvider>
  );
}

