
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  MessageCircle,
  Heart,
  MessageSquare,
  Plus,
  Search,
  TrendingUp,
  Clock,
  Filter,
  Users
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { base44 } from "@/api/base44Client";
import NovaPostagemDialog from "@/components/comunidade/NovaPostagemDialog";
import RespostaDialog from "@/components/comunidade/RespostaDialog";
import Chat24h from "@/components/comunidade/Chat24h";

const categoriaColors = {
  duvida: "bg-blue-100 text-blue-700 border-blue-200",
  dica: "bg-amber-100 text-amber-700 border-amber-200",
  discussao: "bg-purple-100 text-purple-700 border-purple-200",
  material: "bg-green-100 text-green-700 border-green-200",
  experiencia: "bg-pink-100 text-pink-700 border-pink-200"
};

const categoriaLabels = {
  duvida: "Dúvida",
  dica: "Dica",
  discussao: "Discussão",
  material: "Material",
  experiencia: "Experiência"
};

export default function ComunidadePage() {
  const [posts, setPosts] = useState([]);
  const [respostas, setRespostas] = useState({});
  const [curtidas, setCurtidas] = useState({});
  const [curtidasRespostas, setCurtidasRespostas] = useState({});
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Filtros e busca
  const [filtroCategoria, setFiltroCategoria] = useState("todos");
  const [filtroBusca, setFiltroBusca] = useState("");
  const [ordenacao, setOrdenacao] = useState("recentes");
  
  // Dialogs
  const [showNovaPostagem, setShowNovaPostagem] = useState(false);
  const [showRespostaDialog, setShowRespostaDialog] = useState(false);
  const [postSelecionado, setPostSelecionado] = useState(null);
  
  // Tabs
  const [activeTab, setActiveTab] = useState("postagens");

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = useCallback(async () => {
    setLoading(true);
    try {
      // Carregar usuário usando base44.auth
      const userData = await base44.auth.me();
      setUser(userData);

      // Carregar posts usando base44.entities
      const [postsData, curtidasData, curtidasRespostasData] = await Promise.all([
        base44.entities.PostComunidade.list('-created_date', 100),
        base44.entities.CurtidaPost.filter({ user_email: userData.email }),
        base44.entities.CurtidaResposta.filter({ user_email: userData.email })
      ]);

      setPosts(postsData);

      // Mapear curtidas do usuário
      const curtidasMap = {};
      curtidasData.forEach(curtida => {
        curtidasMap[curtida.post_id] = true;
      });
      setCurtidas(curtidasMap);

      const curtidasRespostasMap = {};
      curtidasRespostasData.forEach(curtida => {
        curtidasRespostasMap[curtida.resposta_id] = true;
      });
      setCurtidasRespostas(curtidasRespostasMap);

      // Carregar respostas para cada post
      const respostasMap = {};
      await Promise.all(
        postsData.map(async (post) => {
          const respostasPost = await base44.entities.RespostaComunidade.filter({
            post_id: post.id
          });
          respostasMap[post.id] = respostasPost;
        })
      );
      setRespostas(respostasMap);

    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleCurtirPost = async (post) => {
    if (!user) return;

    try {
      const jaCurtiu = curtidas[post.id];

      if (jaCurtiu) {
        // Remover curtida
        const curtidaExistente = await base44.entities.CurtidaPost.filter({
          post_id: post.id,
          user_email: user.email
        });
        
        if (curtidaExistente.length > 0) {
          await base44.entities.CurtidaPost.delete(curtidaExistente[0].id);
        }

        await base44.entities.PostComunidade.update(post.id, {
          curtidas: Math.max(0, post.curtidas - 1)
        });

        setCurtidas(prev => {
          const newCurtidas = { ...prev };
          delete newCurtidas[post.id];
          return newCurtidas;
        });
      } else {
        // Adicionar curtida
        await base44.entities.CurtidaPost.create({
          post_id: post.id,
          user_email: user.email
        });

        await base44.entities.PostComunidade.update(post.id, {
          curtidas: post.curtidas + 1
        });

        setCurtidas(prev => ({ ...prev, [post.id]: true }));
      }

      await carregarDados();
    } catch (error) {
      console.error('Erro ao curtir post:', error);
    }
  };

  const handleCurtirResposta = async (resposta) => {
    if (!user) return;

    try {
      const jaCurtiu = curtidasRespostas[resposta.id];

      if (jaCurtiu) {
        // Remover curtida
        const curtidaExistente = await base44.entities.CurtidaResposta.filter({
          resposta_id: resposta.id,
          user_email: user.email
        });
        
        if (curtidaExistente.length > 0) {
          await base44.entities.CurtidaResposta.delete(curtidaExistente[0].id);
        }

        await base44.entities.RespostaComunidade.update(resposta.id, {
          curtidas: Math.max(0, resposta.curtidas - 1)
        });

        setCurtidasRespostas(prev => {
          const newCurtidas = { ...prev };
          delete newCurtidas[resposta.id];
          return newCurtidas;
        });
      } else {
        // Adicionar curtida
        await base44.entities.CurtidaResposta.create({
          resposta_id: resposta.id,
          user_email: user.email
        });

        await base44.entities.RespostaComunidade.update(resposta.id, {
          curtidas: resposta.curtidas + 1
        });

        setCurtidasRespostas(prev => ({ ...prev, [resposta.id]: true }));
      }

      await carregarDados();
    } catch (error) {
      console.error('Erro ao curtir resposta:', error);
    }
  };

  const handleResponder = (post) => {
    setPostSelecionado(post);
    setShowRespostaDialog(true);
  };

  // Filtrar e ordenar posts
  const postsFiltrados = posts
    .filter(post => {
      const matchCategoria = filtroCategoria === "todos" || post.categoria === filtroCategoria;
      const matchBusca = !filtroBusca || 
        post.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        post.conteudo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        post.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase());
      return matchCategoria && matchBusca;
    })
    .sort((a, b) => {
      if (ordenacao === "recentes") {
        return new Date(b.created_date) - new Date(a.created_date);
      } else if (ordenacao === "populares") {
        return (b.curtidas || 0) - (a.curtidas || 0);
      } else if (ordenacao === "respostas") {
        return (respostas[b.id]?.length || 0) - (respostas[a.id]?.length || 0);
      }
      return 0;
    });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Comunidade Lexmy
          </h1>
          <p className="text-slate-600 max-w-2xl">
            Conecte-se com outros concurseiros, compartilhe experiências e cresça junto com a comunidade
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-white/60 backdrop-blur-sm">
            <TabsTrigger value="postagens" className="gap-2">
              <MessageCircle className="w-4 h-4" />
              Postagens ({posts.length})
            </TabsTrigger>
            <TabsTrigger value="chat" className="gap-2">
              <Users className="w-4 h-4" />
              Chat 24h
            </TabsTrigger>
          </TabsList>

          {/* Aba de Postagens */}
          <TabsContent value="postagens" className="space-y-6">
            
            {/* Filtros e Nova Postagem */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
                  <div className="flex-1 w-full space-y-4">
                    {/* Busca */}
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                      <Input
                        placeholder="Buscar postagens..."
                        value={filtroBusca}
                        onChange={(e) => setFiltroBusca(e.target.value)}
                        className="pl-10"
                      />
                    </div>

                    {/* Filtros */}
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant={filtroCategoria === "todos" ? "default" : "outline"}
                        size="sm"
                        onClick={() => setFiltroCategoria("todos")}
                      >
                        Todas
                      </Button>
                      {Object.entries(categoriaLabels).map(([key, label]) => (
                        <Button
                          key={key}
                          variant={filtroCategoria === key ? "default" : "outline"}
                          size="sm"
                          onClick={() => setFiltroCategoria(key)}
                        >
                          {label}
                        </Button>
                      ))}
                    </div>

                    {/* Ordenação */}
                    <div className="flex items-center gap-2">
                      <Filter className="w-4 h-4 text-slate-600" />
                      <span className="text-sm text-slate-600">Ordenar por:</span>
                      <Button
                        variant={ordenacao === "recentes" ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setOrdenacao("recentes")}
                        className="gap-1"
                      >
                        <Clock className="w-3 h-3" />
                        Recentes
                      </Button>
                      <Button
                        variant={ordenacao === "populares" ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setOrdenacao("populares")}
                        className="gap-1"
                      >
                        <TrendingUp className="w-3 h-3" />
                        Populares
                      </Button>
                      <Button
                        variant={ordenacao === "respostas" ? "default" : "ghost"}
                        size="sm"
                        onClick={() => setOrdenacao("respostas")}
                        className="gap-1"
                      >
                        <MessageSquare className="w-3 h-3" />
                        Mais Respondidas
                      </Button>
                    </div>
                  </div>

                  <Button
                    onClick={() => setShowNovaPostagem(true)}
                    className="gap-2 whitespace-nowrap"
                  >
                    <Plus className="w-4 h-4" />
                    Nova Postagem
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Lista de Postagens */}
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
              </div>
            ) : postsFiltrados.length === 0 ? (
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-12 text-center">
                  <MessageCircle className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">
                    {filtroBusca || filtroCategoria !== "todos" ? "Nenhuma postagem encontrada" : "Nenhuma postagem ainda"}
                  </h3>
                  <p className="text-slate-600 mb-6">
                    {filtroBusca || filtroCategoria !== "todos" 
                      ? "Tente ajustar os filtros de busca" 
                      : "Seja o primeiro a compartilhar algo com a comunidade!"}
                  </p>
                  {!filtroBusca && filtroCategoria === "todos" && (
                    <Button onClick={() => setShowNovaPostagem(true)} className="gap-2">
                      <Plus className="w-4 h-4" />
                      Criar Primeira Postagem
                    </Button>
                  )}
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-6">
                {postsFiltrados.map((post) => (
                  <Card key={post.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all">
                    <CardHeader>
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-semibold">
                            {post.autor_nome?.charAt(0).toUpperCase() || 'U'}
                          </div>
                          <div>
                            <p className="font-semibold text-slate-800">{post.autor_nome || 'Usuário'}</p>
                            <p className="text-xs text-slate-500">
                              {formatDistanceToNow(new Date(post.created_date), { addSuffix: true, locale: ptBR })}
                            </p>
                          </div>
                        </div>
                        <Badge className={categoriaColors[post.categoria]}>
                          {categoriaLabels[post.categoria]}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl mb-2">{post.titulo}</CardTitle>
                      <p className="text-slate-600 whitespace-pre-wrap">{post.conteudo}</p>
                      
                      {post.disciplina && (
                        <div className="mt-3">
                          <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                            {post.disciplina}
                          </Badge>
                        </div>
                      )}
                      
                      {post.tags && post.tags.length > 0 && (
                        <div className="flex flex-wrap gap-2 mt-3">
                          {post.tags.map((tag, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              #{tag}
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardHeader>
                    
                    <CardContent>
                      <div className="flex items-center gap-4 pb-4 border-b border-slate-200">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCurtirPost(post)}
                          className={`gap-2 ${curtidas[post.id] ? 'text-red-600' : 'text-slate-600'}`}
                        >
                          <Heart className={`w-4 h-4 ${curtidas[post.id] ? 'fill-current' : ''}`} />
                          {post.curtidas || 0}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleResponder(post)}
                          className="gap-2 text-slate-600"
                        >
                          <MessageSquare className="w-4 h-4" />
                          {respostas[post.id]?.length || 0}
                        </Button>
                      </div>

                      {/* Respostas */}
                      {respostas[post.id] && respostas[post.id].length > 0 && (
                        <div className="mt-4 space-y-3">
                          {respostas[post.id].map((resposta) => (
                            <div key={resposta.id} className="bg-slate-50 p-4 rounded-lg">
                              <div className="flex items-start justify-between mb-2">
                                <div className="flex items-center gap-2">
                                  <div className="w-8 h-8 bg-gradient-to-br from-amber-500 to-orange-500 rounded-full flex items-center justify-center text-white text-sm font-semibold">
                                    {resposta.autor_nome?.charAt(0).toUpperCase() || 'U'}
                                  </div>
                                  <div>
                                    <p className="text-sm font-semibold text-slate-800">{resposta.autor_nome || 'Usuário'}</p>
                                    <p className="text-xs text-slate-500">
                                      {formatDistanceToNow(new Date(resposta.created_date), { addSuffix: true, locale: ptBR })}
                                    </p>
                                  </div>
                                </div>
                              </div>
                              <p className="text-sm text-slate-600 whitespace-pre-wrap mb-2">{resposta.conteudo}</p>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleCurtirResposta(resposta)}
                                className={`gap-1 h-7 text-xs ${curtidasRespostas[resposta.id] ? 'text-red-600' : 'text-slate-500'}`}
                              >
                                <Heart className={`w-3 h-3 ${curtidasRespostas[resposta.id] ? 'fill-current' : ''}`} />
                                {resposta.curtidas || 0}
                              </Button>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Aba do Chat */}
          <TabsContent value="chat">
            <Chat24h />
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      <NovaPostagemDialog
        isOpen={showNovaPostagem}
        onClose={() => setShowNovaPostagem(false)}
        onPostCreated={carregarDados}
      />

      <RespostaDialog
        isOpen={showRespostaDialog}
        onClose={() => {
          setShowRespostaDialog(false);
          setPostSelecionado(null);
        }}
        post={postSelecionado}
        onRespostaAdded={carregarDados}
      />
    </div>
  );
}
