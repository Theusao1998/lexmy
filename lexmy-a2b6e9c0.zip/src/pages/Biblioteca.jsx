import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BookOpen,
  Scale,
  FileText,
  Newspaper,
  Heart,
  Search,
  BookMarked,
  FileImage,
  Filter
} from "lucide-react";
import { Material } from "@/api/entities";
import { User } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import LeitorInteligente from "@/components/leitor/LeitorInteligente";

export default function BibliotecaPage() {
  const [materiais, setMateriais] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // Filtros
  const [activeTab, setActiveTab] = useState("legislacao");
  const [filtroDisciplina, setFiltroDisciplina] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");
  const [mostrarFavoritos, setMostrarFavoritos] = useState(false);

  // Visualização de material
  const [materialSelecionado, setMaterialSelecionado] = useState(null);
  const [showLeitor, setShowLeitor] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setLoading(true);
    try {
      const [userData, materiaisData] = await Promise.all([
        User.me(),
        Material.list('-created_date', 200)
      ]);
      
      setUser(userData);
      setMateriais(materiaisData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = materiais.map(m => m.disciplina).filter(Boolean);
    return [...new Set(disciplinas)].sort();
  }, [materiais]);

  // Filtrar materiais por tipo (aba atual)
  const materiaisPorTipo = React.useMemo(() => {
    return materiais.filter(m => {
      // Mapear "concursos" para "material" no filtro
      const tipoFiltro = activeTab === "concursos" ? "material" : activeTab;
      return m.tipo === tipoFiltro;
    });
  }, [materiais, activeTab]);

  const materiaisFiltrados = React.useMemo(() => {
    return materiaisPorTipo.filter(m => {
      const matchDisciplina = filtroDisciplina === "all" || m.disciplina === filtroDisciplina;
      const matchBusca = !filtroBusca || 
        m.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        m.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase());
      const matchFavorito = !mostrarFavoritos || m.favorito;
      return matchDisciplina && matchBusca && matchFavorito;
    });
  }, [materiaisPorTipo, filtroDisciplina, filtroBusca, mostrarFavoritos]);

  const handleVisualizarMaterial = (material) => {
    setMaterialSelecionado(material);
    setShowLeitor(true);
  };

  const handleToggleFavorito = async (material) => {
    try {
      await Material.update(material.id, {
        ...material,
        favorito: !material.favorito
      });
      carregarDados();
    } catch (error) {
      console.error('Erro ao atualizar favorito:', error);
    }
  };

  const getTipoIcon = (tipo) => {
    switch (tipo) {
      case 'legislacao': return <Scale className="w-5 h-5" />;
      case 'material': return <BookOpen className="w-5 h-5" />;
      case 'jurisprudencia': return <FileText className="w-5 h-5" />;
      case 'informativo': return <Newspaper className="w-5 h-5" />;
      case 'resumo': return <FileImage className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  const getTipoLabel = (tipo) => {
    const labels = {
      legislacao: 'Legislação',
      material: 'Material de Concurso',
      jurisprudencia: 'Jurisprudência',
      informativo: 'Informativo',
      resumo: 'Resumo Visual'
    };
    return labels[tipo] || tipo;
  };

  // Contar materiais por tipo
  const contagemPorTipo = React.useMemo(() => {
    return {
      legislacao: materiais.filter(m => m.tipo === 'legislacao').length,
      concursos: materiais.filter(m => m.tipo === 'material').length,
      jurisprudencia: materiais.filter(m => m.tipo === 'jurisprudencia').length,
      informativo: materiais.filter(m => m.tipo === 'informativo').length,
      resumo: materiais.filter(m => m.tipo === 'resumo').length
    };
  }, [materiais]);

  if (showLeitor && materialSelecionado) {
    return (
      <LeitorInteligente
        material={materialSelecionado}
        onClose={() => {
          setShowLeitor(false);
          setMaterialSelecionado(null);
          carregarDados();
        }}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header */}
        <div className="space-y-4">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Biblioteca Jurídica
          </h1>
          <p className="text-slate-600 max-w-2xl">
            Acesse legislação, materiais de estudo, jurisprudência e informativos
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-white/80 backdrop-blur-sm h-auto">
            <TabsTrigger value="legislacao" className="gap-2">
              <Scale className="w-4 h-4" />
              Legislação
              {contagemPorTipo.legislacao > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {contagemPorTipo.legislacao}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="concursos" className="gap-2">
              <BookMarked className="w-4 h-4" />
              Concursos
              {contagemPorTipo.concursos > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {contagemPorTipo.concursos}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="jurisprudencia" className="gap-2">
              <FileText className="w-4 h-4" />
              Jurisprudência
              {contagemPorTipo.jurisprudencia > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {contagemPorTipo.jurisprudencia}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="informativo" className="gap-2">
              <Newspaper className="w-4 h-4" />
              Informativos
              {contagemPorTipo.informativo > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {contagemPorTipo.informativo}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="resumo" className="gap-2">
              <FileImage className="w-4 h-4" />
              Resumos
              {contagemPorTipo.resumo > 0 && (
                <Badge variant="secondary" className="ml-1 text-xs">
                  {contagemPorTipo.resumo}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Conteúdo de cada aba */}
          {['legislacao', 'concursos', 'jurisprudencia', 'informativo', 'resumo'].map((tipo) => (
            <TabsContent key={tipo} value={tipo} className="space-y-6">
              {/* Filtros */}
              <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardContent className="p-6">
                  <div className="grid md:grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                        <Filter className="w-4 h-4" />
                        Disciplina
                      </label>
                      <Select value={filtroDisciplina} onValueChange={setFiltroDisciplina}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">Todas as disciplinas</SelectItem>
                          {disciplinasUnicas.map(d => (
                            <SelectItem key={d} value={d}>{d}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2 md:col-span-2">
                      <label className="text-sm font-medium text-slate-700 flex items-center gap-2">
                        <Search className="w-4 h-4" />
                        Buscar
                      </label>
                      <Input
                        placeholder="Digite o título ou disciplina..."
                        value={filtroBusca}
                        onChange={(e) => setFiltroBusca(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="mt-4">
                    <Button
                      variant={mostrarFavoritos ? "default" : "outline"}
                      onClick={() => setMostrarFavoritos(!mostrarFavoritos)}
                      className="gap-2"
                    >
                      <Heart className={`w-4 h-4 ${mostrarFavoritos ? 'fill-current' : ''}`} />
                      {mostrarFavoritos ? 'Mostrando Favoritos' : 'Mostrar Favoritos'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Lista de Materiais */}
              {loading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent"></div>
                </div>
              ) : materiaisFiltrados.length === 0 ? (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="p-12 text-center">
                    {getTipoIcon(tipo === 'concursos' ? 'material' : tipo)}
                    <div className="w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                      {getTipoIcon(tipo === 'concursos' ? 'material' : tipo)}
                    </div>
                    <h3 className="text-xl font-semibold text-slate-800 mb-2">
                      Nenhum material encontrado
                    </h3>
                    <p className="text-slate-600">
                      {filtroDisciplina !== "all" || filtroBusca || mostrarFavoritos
                        ? "Tente ajustar os filtros de busca"
                        : `Nenhum material de ${getTipoLabel(tipo === 'concursos' ? 'material' : tipo).toLowerCase()} disponível na biblioteca.`}
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {materiaisFiltrados.map((material) => (
                    <Card key={material.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-all cursor-pointer group">
                      <CardHeader onClick={() => handleVisualizarMaterial(material)}>
                        <div className="flex items-start justify-between mb-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center text-white">
                            {getTipoIcon(material.tipo)}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleToggleFavorito(material);
                            }}
                            className="text-slate-400 hover:text-red-500"
                          >
                            <Heart className={`w-5 h-5 ${material.favorito ? 'fill-red-500 text-red-500' : ''}`} />
                          </Button>
                        </div>
                        <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                          {material.titulo}
                        </CardTitle>
                        {material.descricao && (
                          <p className="text-sm text-slate-600 line-clamp-2 mt-2">
                            {material.descricao}
                          </p>
                        )}
                      </CardHeader>
                      <CardContent onClick={() => handleVisualizarMaterial(material)}>
                        <div className="flex flex-wrap gap-2">
                          {material.disciplina && (
                            <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                              {material.disciplina}
                            </Badge>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}