import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  ShieldCheck,
  Send,
  ArrowLeft,
  Lock,
  AlertTriangle,
  Info
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import MessageBubble from "@/components/agentes/MessageBubble";

export default function AssistenteSegurancaPage() {
  const navigate = useNavigate();
  const [conversationId, setConversationId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    iniciarConversa();
  }, []);

  useEffect(() => {
    if (conversationId) {
      const unsubscribe = base44.agents.subscribeToConversation(conversationId, (data) => {
        setMessages(data.messages || []);
      });

      return () => {
        if (unsubscribe) unsubscribe();
      };
    }
  }, [conversationId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const iniciarConversa = async () => {
    setIsLoading(true);
    try {
      const conversation = await base44.agents.createConversation({
        agent_name: "assistente_seguranca",
        metadata: {
          name: "Auditoria de Segurança",
          description: "Análise de segurança e privacidade da plataforma"
        }
      });
      setConversationId(conversation.id);
    } catch (error) {
      console.error("Erro ao criar conversa:", error);
      alert("Erro ao iniciar assistente de segurança.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() || isSending || !conversationId) return;

    setIsSending(true);
    const messageToSend = inputMessage;
    setInputMessage("");

    try {
      const conversation = await base44.agents.getConversation(conversationId);
      await base44.agents.addMessage(conversation, {
        role: "user",
        content: messageToSend
      });
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      alert("Erro ao enviar mensagem. Tente novamente.");
      setInputMessage(messageToSend);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const sugestoesRapidas = [
    {
      text: "Faça uma auditoria geral de RLS",
      icon: ShieldCheck,
      color: "bg-red-100 text-red-700 border-red-200"
    },
    {
      text: "Analise a segurança da entidade Edital",
      icon: Lock,
      color: "bg-orange-100 text-orange-700 border-orange-200"
    },
    {
      text: "Verifique possíveis vazamentos de dados",
      icon: AlertTriangle,
      color: "bg-amber-100 text-amber-700 border-amber-200"
    },
    {
      text: "Liste as entidades sem RLS configurado",
      icon: Info,
      color: "bg-blue-100 text-blue-700 border-blue-200"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 via-orange-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button
              variant="outline"
              onClick={() => navigate(createPageUrl("Administracao"))}
              className="gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar
            </Button>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
                Assistente de Segurança
              </h1>
              <p className="text-slate-600">Auditoria inteligente de RLS e privacidade</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge className="bg-red-100 text-red-700 border-red-200 px-4 py-2">
              <ShieldCheck className="w-4 h-4 mr-2" />
              Sistema Ativo
            </Badge>
          </div>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="border-b border-slate-200/60">
            <CardTitle className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-red-600 to-orange-600 rounded-xl flex items-center justify-center">
                <ShieldCheck className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-lg font-semibold">Assistente de Segurança</div>
                <div className="text-sm text-slate-500 font-normal">
                  Auditor de RLS e Privacidade
                </div>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[500px] overflow-y-auto p-6 space-y-4">
              {isLoading ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <div className="w-12 h-12 mx-auto mb-4 bg-gradient-to-br from-red-600 to-orange-600 rounded-2xl flex items-center justify-center animate-pulse">
                      <ShieldCheck className="w-6 h-6 text-white" />
                    </div>
                    <p className="text-slate-600">Iniciando assistente de segurança...</p>
                  </div>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full space-y-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-red-600 to-orange-600 rounded-3xl flex items-center justify-center shadow-lg">
                    <ShieldCheck className="w-10 h-10 text-white" />
                  </div>
                  <div className="text-center max-w-md">
                    <h3 className="text-xl font-semibold text-slate-800 mb-2">
                      Assistente de Segurança Pronto
                    </h3>
                    <p className="text-slate-600 mb-6">
                      Peça uma auditoria de segurança, análise de RLS ou verificação de privacidade. 
                      Experimente as sugestões abaixo:
                    </p>
                    <div className="grid gap-3">
                      {sugestoesRapidas.map((sugestao, index) => (
                        <button
                          key={index}
                          onClick={() => setInputMessage(sugestao.text)}
                          className={`flex items-center gap-3 p-3 rounded-lg border-2 ${sugestao.color} hover:shadow-md transition-all text-left`}
                        >
                          <sugestao.icon className="w-5 h-5 flex-shrink-0" />
                          <span className="text-sm font-medium">{sugestao.text}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  {messages.map((message, index) => (
                    <MessageBubble 
                      key={index} 
                      message={message}
                      avatarUrl="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/709d63ff8_ChatGPTImage18deagode202500_35_26.png"
                    />
                  ))}
                  <div ref={messagesEndRef} />
                </>
              )}
            </div>

            <div className="border-t border-slate-200/60 p-4 bg-slate-50/50">
              <div className="flex gap-3">
                <Textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Digite sua solicitação de auditoria ou análise de segurança..."
                  className="flex-1 min-h-[60px] max-h-[120px] resize-none"
                  disabled={isSending || !conversationId}
                />
                <Button
                  onClick={handleSendMessage}
                  disabled={!inputMessage.trim() || isSending || !conversationId}
                  className="bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 h-[60px] px-6"
                >
                  {isSending ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}