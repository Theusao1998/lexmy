
import React, { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { base44 } from "@/api/base44Client";
import MessageBubble from "@/components/agentes/MessageBubble";
import { 
  MessageCircle, 
  Send, 
  Trash2, 
  BookOpen,
  Lightbulb,
  Scale,
  Sparkles
} from "lucide-react";

const AGENT_NAME = 'prof_lex';

export default function ProfLex() {
  const [conversation, setConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [pergunta, setPergunta] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const scrollRef = useRef(null);

  const loadOrCreateConversation = async () => {
    setIsLoading(true);
    try {
      // CORRIGIDO: Buscar conversa do usuário específico sem depender do localStorage
      const user = await base44.auth.me();
      if (!user) {
        console.error('Usuário não autenticado');
        setIsLoading(false);
        return;
      }

      // Buscar conversas existentes do usuário para este agente
      const existing = await base44.agents.listConversations({ 
        agent_name: AGENT_NAME, 
        limit: 1 
      });
      
      if (existing.length > 0) {
        // Usar a conversa mais recente do usuário
        setConversation(existing[0]);
        console.log('Conversa existente carregada:', existing[0].id);
      } else {
        // Criar nova conversa para este usuário
        console.log('Criando nova conversa para o usuário:', user.email);
        const newConv = await base44.agents.createConversation({
          agent_name: AGENT_NAME,
          metadata: {
            name: "Consulta ao Prof. Lex",
            description: "Conversa com o Professor Lex"
          }
        });
        setConversation(newConv);
        console.log('Nova conversa criada:', newConv.id);
      }
    } catch (error) {
      console.error("Erro ao carregar ou criar conversa:", error);
      
      // Se der erro de acesso, criar uma nova conversa
      if (error.message?.includes('Access denied') || error.message?.includes('another user')) {
        console.log('Conversa pertence a outro usuário, criando nova...');
        try {
          const newConv = await base44.agents.createConversation({
            agent_name: AGENT_NAME,
            metadata: {
              name: "Consulta ao Prof. Lex",
              description: "Conversa com o Professor Lex"
            }
          });
          setConversation(newConv);
        } catch (createError) {
          console.error('Erro ao criar nova conversa:', createError);
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadOrCreateConversation();
  }, []);

  useEffect(() => {
    if (conversation?.id) {
      const unsubscribe = base44.agents.subscribeToConversation(conversation.id, (updatedConversation) => {
        setMessages(updatedConversation.messages);
      });

      return () => unsubscribe();
    }
  }, [conversation?.id]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const enviarPergunta = async () => {
    if (!pergunta.trim() || enviando || !conversation) return;

    setEnviando(true);
    setPergunta("");

    try {
      await base44.agents.addMessage(conversation, {
        role: 'user',
        content: pergunta.trim(),
      });
    } catch (error) {
      console.error('Erro ao enviar pergunta:', error);
      // Optional: Show an error message to the user
    } finally {
      setEnviando(false);
    }
  };

  const limparConversa = async () => {
    if (confirm("Deseja iniciar uma nova conversa? A conversa atual será arquivada e uma nova será iniciada.")) {
      setIsLoading(true);
      try {
        const newConv = await base44.agents.createConversation({
          agent_name: AGENT_NAME,
          metadata: {
            name: "Consulta ao Prof. Lex",
            description: "Conversa com o Professor Lex"
          }
        });
        setConversation(newConv);
        console.log('Nova conversa criada após limpar:', newConv.id);
      } catch (error) {
        console.error("Erro ao criar uma nova conversa:", error);
        alert("Erro ao iniciar nova conversa. Tente novamente.");
      } finally {
        setIsLoading(false);
      }
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-6">
        
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-4">
            <div className="relative">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/709d63ff9_ChatGPTImage18deagode202500_35_26.png"
                alt="Professor Lex"
                className="w-20 h-20 rounded-full border-4 border-white shadow-lg"
              />
              <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-2 border-white flex items-center justify-center">
                <div className="w-2 h-2 bg-white rounded-full"></div>
              </div>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
                Prof. Lex
              </h1>
              <p className="text-slate-600">Seu mentor jurídico especializado em concursos</p>
            </div>
          </div>
          
          <div className="flex justify-center gap-4">
            <Badge className="bg-blue-100 text-blue-700 border-blue-200 gap-1">
              <BookOpen className="w-3 h-3" />
              Especialista Jurídico
            </Badge>
            <Badge className="bg-amber-100 text-amber-700 border-amber-200 gap-1">
              <Scale className="w-3 h-3" />
              20+ Anos de Experiência
            </Badge>
            <Badge className="bg-green-100 text-green-700 border-green-200 gap-1">
              <Sparkles className="w-3 h-3" />
              IA Avançada
            </Badge>
          </div>
        </div>

        {/* Chat Container */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5 text-blue-600" />
              Conversa com Prof. Lex
            </CardTitle>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={limparConversa}
              className="gap-2"
            >
              <Trash2 className="w-4 h-4" />
              Limpar
            </Button>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {/* Área de Mensagens */}
            <div 
              ref={scrollRef}
              className="h-[500px] overflow-y-auto space-y-4 p-4 bg-slate-50/50 rounded-xl border border-slate-200/60"
            >
              {isLoading ? (
                <div className="flex justify-center items-center h-full">
                  <div className="flex items-center gap-2 text-slate-600">
                    <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
                    <span>Carregando conversa...</span>
                  </div>
                </div>
              ) : messages.length > 0 ? (
                messages.map((message) => (
                  <MessageBubble key={message.id} message={message} />
                ))
              ) : (
                 <div className="flex justify-center items-center h-full text-slate-500">
                    <span>Faça sua primeira pergunta ao Prof. Lex.</span>
                 </div>
              )}
            </div>

            {/* Input de Pergunta */}
            <div className="space-y-3">
              <Textarea
                value={pergunta}
                onChange={(e) => setPergunta(e.target.value)}
                placeholder="Digite sua dúvida jurídica aqui... Ex: 'Como funciona o princípio da supremacia da constituição?'"
                className="min-h-[100px] resize-none"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    enviarPergunta();
                  }
                }}
                disabled={isLoading || enviando}
              />
              
              <div className="flex justify-between items-center">
                <div className="flex gap-2 text-xs text-slate-500">
                  <Lightbulb className="w-4 h-4" />
                  <span>Seja específico para respostas mais precisas</span>
                </div>
                
                <Button
                  onClick={enviarPergunta}
                  disabled={!pergunta.trim() || enviando || isLoading}
                  className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                >
                  <Send className="w-4 h-4" />
                  {enviando ? 'Enviando...' : 'Enviar'}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Exemplos de Perguntas */}
        <Card className="bg-white/60 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <h3 className="font-semibold text-slate-800 mb-4 flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-amber-600" />
              Exemplos de Perguntas
            </h3>
            
            <div className="grid md:grid-cols-2 gap-3">
              {[
                "Qual a diferença entre poder hierárquico e poder disciplinar?",
                "Como funciona o controle de constitucionalidade concentrado?",
                "Quais são os princípios da administração pública?",
                "O que caracteriza um crime doloso versus culposo?",
              ].map((exemplo, index) => (
                <button
                  key={index}
                  onClick={() => setPergunta(exemplo)}
                  className="text-left p-3 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-sm text-slate-700 transition-colors"
                >
                  "{exemplo}"
                </button>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
