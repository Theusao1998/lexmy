import React, { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  Headphones,
  Music,
  Play,
  Plus,
  FolderOpen
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { LegislacaoAudio, ColecaoLegislacaoAudio } from "@/api/entities";

import { AudioPlayerProvider, useAudioPlayer } from "@/components/audio/AudioPlayerContext";
import GlobalAudioPlayer from "@/components/audio/GlobalAudioPlayer";
import AudioCard from "@/components/audio/AudioCard";

// Componente interno que usa o contexto
function LegislacaoAudioContent() {
  const [audios, setAudios] = useState([]);
  const [colecoes, setColecoes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  const [expandedColecoes, setExpandedColecoes] = useState(new Set());

  const { playCollection, addCollectionToQueue } = useAudioPlayer();

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const [audioData, colecaoData] = await Promise.all([
        LegislacaoAudio.list("-created_date", 200),
        ColecaoLegislacaoAudio.list("ordem", 50)
      ]);
      setAudios(audioData);
      setColecoes(colecaoData);
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
    }
    setIsLoading(false);
  };

  // Organizar áudios por coleção
  const audiosPorColecao = React.useMemo(() => {
    const grupos = {
      sem_colecao: []
    };

    // Inicializar grupos para cada coleção
    colecoes.forEach(colecao => {
      grupos[colecao.id] = [];
    });

    // Agrupar áudios
    audios.forEach(audio => {
      if (audio.colecao_id && grupos[audio.colecao_id]) {
        grupos[audio.colecao_id].push(audio);
      } else {
        grupos.sem_colecao.push(audio);
      }
    });

    // Ordenar áudios dentro de cada grupo
    Object.keys(grupos).forEach(key => {
      grupos[key].sort((a, b) => (a.ordem || 0) - (b.ordem || 0));
    });

    return grupos;
  }, [audios, colecoes]);

  const toggleColecao = (colecaoId) => {
    const newExpanded = new Set(expandedColecoes);
    if (newExpanded.has(colecaoId)) {
      newExpanded.delete(colecaoId);
    } else {
      newExpanded.add(colecaoId);
    }
    setExpandedColecoes(newExpanded);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8 pb-32">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2">
            <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
              Legislação em Áudio
            </h1>
            <p className="text-slate-600">
              Ouça leis e conteúdos jurídicos organizados por coleções
            </p>
          </div>
        </div>

        {/* Filtros e Busca */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Buscar áudios ou coleções..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Lista de Coleções e Áudios */}
        <div className="space-y-6">
          {isLoading ? (
            Array(4).fill(0).map((_, i) => (
              <Card key={i} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg animate-pulse">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="h-6 bg-slate-200 rounded w-1/3"></div>
                    <div className="space-y-2">
                      <div className="h-4 bg-slate-200 rounded w-2/3"></div>
                      <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <>
              {/* Coleções organizadas */}
              {colecoes
                .filter(colecao => {
                  if (searchTerm && !colecao.titulo.toLowerCase().includes(searchTerm.toLowerCase())) return false;
                  return true;
                })
                .map(colecao => {
                  const audiosColecao = audiosPorColecao[colecao.id] || [];
                  const isExpanded = expandedColecoes.has(colecao.id);

                  return (
                    <Card key={colecao.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                      <Collapsible open={isExpanded} onOpenChange={() => toggleColecao(colecao.id)}>
                        <CollapsibleTrigger asChild>
                          <div
                            className="w-full p-6 flex items-center justify-between cursor-pointer hover:bg-slate-50/50"
                          >
                            <div className="flex items-center gap-4">
                              <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl">
                                <FolderOpen className="w-6 h-6 text-white" />
                              </div>
                              <div>
                                <h3 className="text-xl font-bold text-slate-800">{colecao.titulo}</h3>
                                <p className="text-slate-600">{colecao.descricao}</p>
                                <div className="flex items-center gap-2 mt-2">
                                  {colecao.disciplina && (
                                    <Badge variant="outline">{colecao.disciplina}</Badge>
                                  )}
                                  <Badge variant="outline">{audiosColecao.length} áudio{audiosColecao.length !== 1 ? 's' : ''}</Badge>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {/* Controles de reprodução da coleção */}
                              {audiosColecao.length > 0 && (
                                <>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 hover:bg-green-50"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      playCollection(audiosColecao);
                                    }}
                                    title="Reproduzir coleção"
                                  >
                                    <Play className="w-4 h-4 text-green-600" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    className="h-8 w-8 hover:bg-blue-50"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      addCollectionToQueue(audiosColecao);
                                    }}
                                    title="Adicionar coleção à fila"
                                  >
                                    <Plus className="w-4 h-4 text-blue-600" />
                                  </Button>
                                </>
                              )}
                            </div>
                          </div>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <div className="border-t border-slate-200 bg-slate-50/30">
                            {audiosColecao.length > 0 ? (
                              <div className="grid grid-cols-1 gap-3 p-4">
                                {audiosColecao.map(audio => (
                                  <AudioCard
                                    key={audio.id}
                                    audio={audio}
                                    isAdmin={false}
                                    onEdit={null}
                                    onDelete={null}
                                  />
                                ))}
                              </div>
                            ) : (
                              <div className="p-6 text-center text-slate-500">
                                <Music className="w-8 h-8 mx-auto mb-2 text-slate-400" />
                                <p className="text-sm">Nenhum áudio nesta coleção ainda</p>
                              </div>
                            )}
                          </div>
                        </CollapsibleContent>
                      </Collapsible>
                    </Card>
                  );
                })}

              {/* Áudios sem coleção */}
              {audiosPorColecao.sem_colecao.length > 0 && (
                <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-gradient-to-br from-slate-400 to-slate-500 rounded-2xl">
                          <Music className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="text-xl font-bold text-slate-800">Áudios Avulsos</h3>
                          <p className="text-slate-600">Áudios que não pertencem a uma coleção específica</p>
                        </div>
                      </div>

                      {/* Controles para áudios avulsos */}
                      {audiosPorColecao.sem_colecao.length > 1 && (
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2"
                            onClick={() => playCollection(audiosPorColecao.sem_colecao)}
                          >
                            <Play className="w-4 h-4" />
                            Reproduzir Todos
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2"
                            onClick={() => addCollectionToQueue(audiosPorColecao.sem_colecao)}
                          >
                            <Plus className="w-4 h-4" />
                            Adicionar à Fila
                          </Button>
                        </div>
                      )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                      {audiosPorColecao.sem_colecao
                        .filter(audio => {
                          if (searchTerm && !audio.titulo.toLowerCase().includes(searchTerm.toLowerCase())) return false;
                          return true;
                        })
                        .map(audio => (
                          <AudioCard
                            key={audio.id}
                            audio={audio}
                            isAdmin={false}
                            onEdit={null}
                            onDelete={null}
                          />
                        ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </>
          )}

          {/* Estado vazio */}
          {!isLoading && colecoes.length === 0 && audiosPorColecao.sem_colecao.length === 0 && (
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-12 text-center">
                <Music className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhum áudio cadastrado ainda
                </h3>
                <p className="text-slate-600 mb-6 max-w-md mx-auto">
                  Os áudios são adicionados pelos administradores. Em breve teremos conteúdo disponível para você.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Player Global */}
      <GlobalAudioPlayer />
    </div>
  );
}

export default function LegislacaoAudioPage() {
  return (
    <AudioPlayerProvider>
      <LegislacaoAudioContent />
    </AudioPlayerProvider>
  );
}