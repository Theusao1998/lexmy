
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Check,
  Sparkles,
  Brain,
  BookOpen,
  Timer,
  Users,
  Scale,
  MessageCircle,
  Headphones,
  FileText,
  Target,
  Puzzle,
  Calendar,
  TrendingUp,
  Shield,
  Zap
} from "lucide-react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User } from "@/api/entities";
import { createPageUrl } from "@/utils";
import LexmyLogo from "@/components/brand/LexmyLogo";
import { base44 } from "@/api/base44Client";

export default function Precos() {
  const [planoSelecionado, setPlanoSelecionado] = useState("anual");
  const [processando, setProcessando] = useState(false);

  const precosPlanos = {
    mensal: {
      valor: 49.90,
      periodo: "mês",
      total: 49.90,
      economia: 0,
      destaque: false
    },
    semestral: {
      valor: 39.92,
      periodo: "mês",
      total: 239.52,
      economia: 20,
      destaque: false
    },
    anual: {
      valor: 29.94,
      periodo: "mês",
      total: 359.28,
      economia: 40,
      destaque: true
    }
  };

  const recursos = [
    { icon: BookOpen, texto: "Biblioteca Jurídica Completa" },
    { icon: Brain, texto: "Questões Ilimitadas com IA" },
    { icon: Timer, texto: "Temporizador Pomodoro com Música de Foco" },
    { icon: Shield, texto: "Prof. Lex - IA Jurídica 24/7" },
    { icon: Users, texto: "Comunidade Ativa de Concurseiros" },
    { icon: Headphones, texto: "Legislação em Áudio" },
    { icon: FileText, texto: "Verticalização de Editais" },
    { icon: Calendar, texto: "Planner Inteligente com IA" },
    { icon: Puzzle, texto: "Jogos Jurídicos Educativos" },
    { icon: TrendingUp, texto: "Dashboard de Progresso Detalhado" },
    { icon: MessageCircle, texto: "Chat em Tempo Real" },
    { icon: Target, texto: "Sistema de Metas e Revisões" }
  ];

  const faqs = [
    {
      pergunta: "Como funciona o teste gratuito?",
      resposta: "Ao criar sua conta, você recebe automaticamente 14 dias para explorar todas as funcionalidades do Plano Pro sem compromisso. Não é necessário cartão de crédito para começar."
    },
    {
      pergunta: "Posso cancelar a qualquer momento?",
      resposta: "Sim! Você pode cancelar sua assinatura a qualquer momento. Não há multas ou taxas de cancelamento."
    },
    {
      pergunta: "Qual a diferença entre os planos?",
      resposta: "Todos os planos (mensal, semestral e anual) oferecem acesso completo às mesmas funcionalidades. A diferença está apenas no período de cobrança e no desconto aplicado."
    },
    {
      pergunta: "Posso mudar de plano depois?",
      resposta: "Sim! Você pode fazer upgrade ou downgrade entre os planos (mensal, semestral, anual) a qualquer momento através das configurações da sua conta."
    },
    {
      pergunta: "Quais formas de pagamento são aceitas?",
      resposta: "Aceitamos cartão de crédito, débito e PIX. O pagamento é processado de forma segura através de nossa plataforma."
    },
    {
      pergunta: "O que acontece após o período de teste?",
      resposta: "Após os 14 dias de teste gratuito, sua assinatura não será automaticamente renovada. Você precisará escolher e assinar um plano para continuar utilizando o Lexmy."
    }
  ];

  // Função de login/cadastro simplificada que também serve para iniciar o teste gratuito automaticamente
  const handleIniciarAgora = async () => {
    try {
      // After successful login/signup, redirect to the dashboard
      const callbackUrl = window.location.origin + createPageUrl("Dashboard");
      await User.loginWithRedirect(callbackUrl);
    } catch (error) {
      console.error('Erro no login/cadastro:', error);
      // Fallback in case redirect fails
      try {
        await User.login();
      } catch (fallbackError) {
        console.error('Erro no fallback login:', fallbackError);
        alert('Não foi possível iniciar o login. Por favor, tente novamente.');
      }
    }
  };

  // Função para checkout com Mercado Pago
  const handleIniciarCheckout = async () => {
    setProcessando(true);
    try {
      const { data: response } = await base44.functions.invoke('createMercadoPagoCheckout', {
        plano: planoSelecionado
      });

      if (response.init_point) {
        window.location.href = response.init_point;
      } else {
        throw new Error('URL de checkout não recebida');
      }
    } catch (error) {
      console.error('Erro ao iniciar checkout:', error);
      
      // If error is 401, user is not logged in
      if (error.response?.status === 401 || (error.message && error.message.includes('401'))) {
        try {
          const callbackUrl = window.location.origin + createPageUrl("Precos"); // Redirect back to prices page after login
          await User.loginWithRedirect(callbackUrl);
        } catch (loginError) {
          console.error('Erro no login após 401:', loginError);
          alert('Erro ao fazer login. Por favor, tente novamente.');
        }
      } else {
        // This catch block handles any other errors, including a 500 server error,
        // by showing a generic error message to the user.
        alert('Erro ao processar pagamento. Por favor, tente novamente.');
      }
    } finally {
      setProcessando(false);
    }
  };

  const planoAtual = precosPlanos[planoSelecionado];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20">
      {/* Header/Navbar */}
      <header className="sticky top-0 z-50 w-full glass-effect border-b border-slate-200/60">
        <style>{`
          .glass-effect {
            background: rgba(255, 255, 255, 0.85);
            backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.2);
          }
        `}</style>
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <a href={createPageUrl("Home")}>
              <LexmyLogo className="w-40 h-auto cursor-pointer" />
            </a>
            
            <nav className="hidden md:flex items-center gap-6">
              <a 
                href={createPageUrl("Sobre")} 
                className="text-slate-700 hover:text-blue-600 transition-colors font-medium"
              >
                Sobre
              </a>
              <a 
                href={createPageUrl("Precos")} 
                className="text-slate-700 hover:text-blue-600 transition-colors font-medium"
              >
                Preços
              </a>
              <Button 
                onClick={handleIniciarAgora}
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 shadow-lg gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Entrar / Cadastrar
              </Button>
            </nav>

            {/* Menu mobile */}
            <div className="md:hidden">
              <Button 
                onClick={handleIniciarAgora}
                size="sm"
                className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 gap-2"
              >
                <Sparkles className="w-4 h-4" />
                Entrar
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-12 md:py-20">
        
        {/* Header */}
        <div className="text-center space-y-6 mb-16">
          <Badge className="bg-gradient-to-r from-blue-100 to-amber-50 text-blue-800 border-blue-200 px-4 py-2 text-sm">
            <Sparkles className="w-4 h-4 mr-2" />
            14 dias de teste gratuito automático ao criar conta
          </Badge>
          
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-800 to-amber-600 bg-clip-text text-transparent">
            Plano Pro
          </h1>
          
          <p className="text-lg md:text-xl text-slate-600 max-w-3xl mx-auto">
            Acesso completo a todas as funcionalidades da Lexmy.<br />
            Tudo que você precisa para sua aprovação em um único plano.
          </p>
        </div>

        {/* Seletor de Plano */}
        <div className="flex justify-center mb-12">
          <Tabs value={planoSelecionado} onValueChange={setPlanoSelecionado} className="w-full max-w-md">
            <TabsList className="grid w-full grid-cols-3 bg-white/80 backdrop-blur-sm p-2 rounded-2xl shadow-lg h-auto">
              <TabsTrigger 
                value="mensal" 
                className="rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-700 data-[state=active]:text-white py-3"
              >
                Mensal
              </TabsTrigger>
              <TabsTrigger 
                value="semestral" 
                className="rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-700 data-[state=active]:text-white relative py-3"
              >
                <span>Semestral</span>
                <Badge className="absolute -top-2 -right-2 bg-amber-500 text-white text-xs px-1.5 py-0.5 h-5">
                  -20%
                </Badge>
              </TabsTrigger>
              <TabsTrigger 
                value="anual" 
                className="rounded-xl data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-blue-700 data-[state=active]:text-white relative py-3"
              >
                <span>Anual</span>
                <Badge className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-1.5 py-0.5 h-5">
                  -40%
                </Badge>
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* Card do Plano */}
        <Card className="max-w-4xl mx-auto bg-white/90 backdrop-blur-sm border-0 shadow-2xl overflow-hidden">
          {planoAtual.destaque && (
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white text-center py-2 font-semibold text-sm">
              <Zap className="w-4 h-4 inline mr-2" />
              MELHOR OFERTA - Economia de {planoAtual.economia}%
            </div>
          )}
          
          <CardContent className="p-8 md:p-12">
            <div className="grid md:grid-cols-2 gap-12">
              
              {/* Coluna Esquerda - Preço */}
              <div className="space-y-8">
                <div>
                  <p className="text-slate-600 mb-2">Plano Pro - {planoSelecionado.charAt(0).toUpperCase() + planoSelecionado.slice(1)}</p>
                  
                  <div className="flex items-baseline gap-2">
                    <span className="text-5xl md:text-6xl font-bold text-slate-900">
                      R$ {planoAtual.valor.toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-xl text-slate-600">/{planoAtual.periodo}</span>
                  </div>
                  
                  {planoSelecionado !== 'mensal' && (
                    <div className="mt-3 space-y-1">
                      <p className="text-sm text-slate-500 line-through">
                        De R$ 49,90/{planoAtual.periodo}
                      </p>
                      <p className="text-sm font-semibold text-green-600">
                        Total: R$ {planoAtual.total.toFixed(2).replace('.', ',')} ({planoSelecionado === 'semestral' ? '6' : '12'} meses)
                      </p>
                      <Badge className="bg-green-100 text-green-700 border-green-200">
                        Economize {planoAtual.economia}% (R$ {((49.90 - planoAtual.valor) * (planoSelecionado === 'semestral' ? 6 : 12)).toFixed(2).replace('.', ',')})
                      </Badge>
                    </div>
                  )}
                </div>

                <div className="space-y-4">
                  {/* Botão Principal - Começar Agora com Teste Gratuito */}
                  <Button
                    onClick={handleIniciarAgora}
                    className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 shadow-xl py-6 text-lg gap-2"
                  >
                    <Sparkles className="w-5 h-5" />
                    Começar Agora - 14 Dias Grátis
                  </Button>
                  
                  <div className="flex items-center justify-center gap-2 text-sm text-slate-600">
                    <Check className="w-4 h-4 text-green-600" />
                    Teste gratuito ativado automaticamente
                  </div>

                  {/* Divisor */}
                  <div className="relative py-4">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-slate-200"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-4 bg-white text-slate-500">ou assine diretamente</span>
                    </div>
                  </div>

                  {/* Botão Secundário - Assinar com Cartão */}
                  <Button
                    onClick={handleIniciarCheckout}
                    disabled={processando}
                    variant="outline"
                    className="w-full py-6 text-lg gap-2 border-2 hover:bg-blue-50"
                  >
                    {processando ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-600"></div>
                        Processando...
                      </>
                    ) : (
                      <>
                        Assinar com Cartão de Crédito
                      </>
                    )}
                  </Button>
                  
                  <div className="flex items-center justify-center gap-2 text-sm text-slate-600">
                    <Check className="w-4 h-4 text-green-600" />
                    Cancele a qualquer momento
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-200">
                  <p className="text-xs text-slate-500 text-center">
                    Ao criar sua conta, você recebe automaticamente 14 dias de teste gratuito. Sem cartão de crédito necessário. Sem cobranças automáticas.
                  </p>
                </div>
              </div>

              {/* Coluna Direita - Recursos */}
              <div>
                <h3 className="text-2xl font-bold text-slate-900 mb-6">
                  Tudo incluído no Plano Pro:
                </h3>
                
                <div className="space-y-4">
                  {recursos.map((recurso, index) => {
                    const Icon = recurso.icon;
                    return (
                      <div key={index} className="flex items-start gap-3">
                        <div className="flex-shrink-0 w-10 h-10 bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg flex items-center justify-center">
                          <Icon className="w-5 h-5 text-blue-700" />
                        </div>
                        <div className="flex-1 pt-2">
                          <p className="text-slate-700 font-medium">{recurso.texto}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto mt-20">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">
            Perguntas Frequentes
          </h2>
          
          <div className="grid gap-6">
            {faqs.map((faq, index) => (
              <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg text-slate-900">
                    {faq.pergunta}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-slate-600">{faq.resposta}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Final */}
        <div className="max-w-4xl mx-auto mt-20 text-center">
          <Card className="bg-gradient-to-r from-blue-600 to-blue-700 border-0 shadow-2xl">
            <CardContent className="p-12">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Pronto para começar sua jornada?
              </h2>
              <p className="text-xl text-blue-100 mb-8">
                Junte-se a milhares de concurseiros que já escolheram a Lexmy
              </p>
              <Button
                onClick={handleIniciarAgora}
                size="lg"
                className="bg-white text-blue-700 hover:bg-gray-50 shadow-xl px-8 py-6 text-lg gap-2"
              >
                <Sparkles className="w-5 h-5" />
                Iniciar Teste Gratuito Agora
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
