
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { format, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Clock,
  Target,
  BookOpen,
  Brain,
  TrendingUp,
  Calendar,
  Award,
  Flame,
  Timer,
  CheckCircle2,
  ArrowRight,
  BarChart3,
  Plus,
  Pencil,
  Trash2,
  RotateCcw
} from "lucide-react";
import { useTimer } from "@/components/timer/TimerContext";
import { SessaoEstudo, Meta, Disciplina } from "@/api/entities";
import { User } from "@/api/entities";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import MetaForm from "@/components/metas/MetaForm";
import DisciplinaForm from "@/components/disciplinas/DisciplinaForm";
import { obterEstatisticasHoje } from "@/components/utils/metasHelper";

export default function Dashboard() {
  const [metas, setMetas] = useState([]);
  const [disciplinas, setDisciplinas] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Estados para gerenciamento de metas
  const [showMetaForm, setShowMetaForm] = useState(false);
  const [metaEdicao, setMetaEdicao] = useState(null);

  // Estados para estatísticas de questões
  const [estatisticasQuestoes, setEstatisticasQuestoes] = useState({ acertos: 0, total: 0 });

  // Usar função unificada do TimerContext
  const { isAtivo, sessaoIniciadaIso, sessoes, calcularTempoEstudadoHoje } = useTimer();

  // REMOVIDO: useEffect que recalculava horas das disciplinas, pois agora usamos questões

  const carregarDados = useCallback(async () => {
    try {
      // Tentar carregar dados com tratamento individual de erros
      let metasData = [];
      let disciplinasData = [];
      let stats = { acertos: 0, total: 0 };

      // Tentar carregar cada tipo de dado separadamente
      try {
        metasData = await Meta.list('-created_date', 10);
      } catch (metasError) {
        // ADICIONADO: Tratamento silencioso para erro 401
        if (metasError.response?.status === 401 || metasError.message?.includes('401')) {
          metasData = [];
        } else {
          console.error('Erro ao carregar metas:', metasError);
        }
      }

      try {
        disciplinasData = await Disciplina.list('-created_date', 10);
      } catch (disciplinasError) {
        // ADICIONADO: Tratamento silencioso para erro 401
        if (disciplinasError.response?.status === 401 || disciplinasError.message?.includes('401')) {
          disciplinasData = [];
        } else {
          console.error('Erro ao carregar disciplinas:', disciplinasError);
        }
      }

      try {
        stats = await obterEstatisticasHoje();
      } catch (statsError) {
        // ADICIONADO: Tratamento silencioso para erro 401
        if (statsError.response?.status === 401 || statsError.message?.includes('401')) {
          stats = { acertos: 0, total: 0 };
        } else {
          console.error('Erro ao carregar estatísticas:', statsError);
        }
      }

      setMetas(metasData);
      setDisciplinas(disciplinasData);
      setEstatisticasQuestoes(stats);
    } catch (error) {
      console.error('Erro geral ao carregar dados do dashboard:', error);

      // ADICIONADO: Tratamento geral para erro 401
      if (error.response?.status === 401 || error.message?.includes('401') || error.message?.includes('unauthorized')) {
        // O layout já vai gerenciar o redirecionamento, então não fazemos nada aqui
        console.log('User not authenticated in dashboard - using default values');
      }
      
      // Definir valores padrão em caso de erro
      setMetas([]);
      setDisciplinas([]);
      setEstatisticasQuestoes({ acertos: 0, total: 0 });
    }
  }, []);

  const initializeDashboard = useCallback(async () => {
    setIsLoading(true);
    try {
      await carregarDados();
    } catch (error) {
      console.error('Erro na inicialização do dashboard:', error);
    } finally {
      setIsLoading(false);
    }
  }, [carregarDados]);

  useEffect(() => {
    initializeDashboard();
  }, [initializeDashboard]);

  // Funções para gerenciar metas
  const handleCriarMeta = async (dadosMeta) => {
    try {
      await Meta.create(dadosMeta);
      await carregarDados(); // Recarregar dados após criar
      fecharFormulario(); // Fechar formulário após criar
    } catch (error) {
      console.error('Erro ao criar meta:', error);
      alert('Erro ao criar meta. Tente novamente.');
    }
  };

  const handleEditarMeta = async (dadosMeta) => {
    try {
      if (!metaEdicao || !metaEdicao.id) {
        throw new Error('ID da meta para edição não encontrado.');
      }
      await Meta.update(metaEdicao.id, dadosMeta);
      await carregarDados(); // Recarregar dados após editar
      fecharFormulario(); // Fechar formulário após editar
    } catch (error) {
      console.error('Erro ao editar meta:', error);
      alert('Erro ao editar meta. Tente novamente.');
    }
  };

  const handleExcluirMeta = async (meta) => {
    if (confirm(`Tem certeza que deseja excluir a meta "${meta.titulo}"?`)) {
      try {
        await Meta.delete(meta.id);
        await carregarDados(); // Recarregar dados após excluir
      } catch (error) {
        console.error('Erro ao excluir meta:', error);
        alert('Erro ao excluir meta. Tente novamente.');
      }
    }
  };

  const abrirFormularioEdicao = (meta) => {
    setMetaEdicao(meta);
    setShowMetaForm(true);
  };

  const fecharFormulario = () => {
    setShowMetaForm(false);
    setMetaEdicao(null);
  };

  // Função para resetar progresso das disciplinas
  const handleResetarProgresso = async () => {
    if (confirm('Tem certeza que deseja resetar o progresso de todas as disciplinas? Esta ação zerará as questões respondidas de todas as disciplinas.')) {
      try {
        // Resetar questões de todas as disciplinas para 0
        const promises = disciplinas.map(disciplina =>
          Disciplina.update(disciplina.id, { 
            questoes_corretas: 0,
            questoes_total: 0
          })
        );

        await Promise.all(promises);
        await carregarDados(); // Recarregar dados após resetar

        alert('Progresso de todas as disciplinas foi resetado com sucesso!');
      } catch (error) {
        console.error('Erro ao resetar progresso:', error);
        alert('Erro ao resetar progresso. Tente novamente.');
      }
    }
  };

  const hoje = new Date();

  // ATUALIZADO: Cálculo para o gráfico de atividade usando função unificada
  const dadosGrafico = useMemo(() => {
    const hojeData = new Date();
    return Array.from({ length: 7 }, (_, i) => {
      const dataAlvo = subDays(hojeData, 6 - i);

      // Usar fuso horário de Brasília consistente
      let brasiliaTime;
      let dataAlvoStr;
      
      try {
        brasiliaTime = new Date(dataAlvo.toLocaleString("en-US", {timeZone: "America/Sao_Paulo"}));
        if (isNaN(brasiliaTime.getTime())) {
          throw new Error('Invalid date generated for brasiliaTime');
        }
        dataAlvoStr = brasiliaTime.toISOString().split('T')[0];
      } catch (error) {
        console.error('Erro ao processar data do gráfico para dataAlvo:', error);
        // Fallback para uma data válida, e.g., o dia actual
        dataAlvoStr = new Date().toISOString().split('T')[0]; 
      }

      const sessoesDia = sessoes.filter(sessao => {
        if (!sessao.data_inicio || !sessao.duracao_minutos) return false;
        
        try {
          const dataInicioSessao = new Date(sessao.data_inicio);
          if (isNaN(dataInicioSessao.getTime())) {
            console.warn('Sessão com data de início inválida detectada:', sessao.data_inicio);
            return false;
          }
          
          const sessaoBrasiliaTime = new Date(dataInicioSessao.toLocaleString("en-US", {timeZone: "America/Sao_Paulo"}));
          if (isNaN(sessaoBrasiliaTime.getTime())) {
            throw new Error('Invalid date generated for sessaoBrasiliaTime');
          }
          const sessaoDataStr = sessaoBrasiliaTime.toISOString().split('T')[0];
          return sessaoDataStr === dataAlvoStr;
        } catch (error) {
          console.error('Erro ao processar data da sessão no gráfico:', error, sessao);
          return false;
        }
      });

      let minutosDia = sessoesDia.reduce((total, sessao) => total + (sessao.duracao_minutos || 0), 0);

      // Para o dia de hoje (último elemento), usar a função unificada
      if (i === 6) { // último dia (hoje)
        minutosDia = calcularTempoEstudadoHoje();
      }
      
      // CONVERTIDO para horas
      const horasDia = parseFloat((minutosDia / 60).toFixed(1));

      return {
        dia: format(dataAlvo, 'EEE', { locale: ptBR }),
        Horas: horasDia,
      };
    });
  }, [sessoes, calcularTempoEstudadoHoje]);

  // ATUALIZADO: tempoEstudadoHoje agora vem da função unificada
  const tempoEstudadoHoje = calcularTempoEstudadoHoje();

  const metasAtivas = metas.filter(meta => !meta.concluida);

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-blue-600 to-blue-800 rounded-3xl flex items-center justify-center animate-pulse">
            <div className="w-8 h-8 bg-white rounded-full"></div>
          </div>
          <h3 className="text-xl font-semibold text-slate-800 mb-2">Carregando Dashboard...</h3>
          <p className="text-slate-600">Preparando seus dados de estudo</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-3 bg-white/80 backdrop-blur-sm px-6 py-3 rounded-2xl shadow-lg border border-white/50">
            <Calendar className="w-5 h-5 text-blue-600" />
            <span className="text-slate-600 font-medium">
              {format(hoje, "EEEE, d 'de' MMMM 'de' yyyy", { locale: ptBR })}
            </span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-800 via-blue-600 to-amber-600 bg-clip-text text-transparent">
            Bom dia, Concurseiro!
          </h1>
          <p className="text-slate-600 text-lg max-w-2xl mx-auto">
            Vamos continuar sua jornada rumo à aprovação. Cada minuto estudado te aproxima do seu objetivo.
          </p>
        </div>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-blue-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <CardContent className="relative p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl shadow-lg">
                  <Timer className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-blue-100 text-blue-700 border-blue-200 pointer-events-none">
                  Hoje
                </Badge>
              </div>
              <h3 className="text-2xl font-bold text-slate-800">
                {Math.floor(tempoEstudadoHoje / 60)}h {tempoEstudadoHoje % 60}min
              </h3>
              <p className="text-slate-600 text-sm mt-1">Tempo Estudado</p>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span>+15% da semana passada</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-green-500/10 to-emerald-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <CardContent className="relative p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl shadow-lg">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-green-100 text-green-700 border-green-200 pointer-events-none">
                  Hoje
                </Badge>
              </div>
              <h3 className="text-2xl font-bold text-slate-800">
                {estatisticasQuestoes.total}
              </h3>
              <p className="text-slate-600 text-sm mt-1">Questões Resolvidas</p>
              <div className="mt-4 flex items-center text-sm text-green-600">
                <CheckCircle2 className="w-4 h-4 mr-1" />
                <span>
                  {estatisticasQuestoes.total > 0
                    ? `${Math.round((estatisticasQuestoes.acertos / estatisticasQuestoes.total) * 100)}% de acertos`
                    : 'Comece a resolver!'
                  }
                </span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-amber-500/10 to-orange-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <CardContent className="relative p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-amber-500 to-orange-500 rounded-2xl shadow-lg">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-amber-100 text-amber-700 border-amber-200 pointer-events-none">
                  Semana
                </Badge>
              </div>
              <h3 className="text-2xl font-bold text-slate-800">
                {metasAtivas.filter(m => m.concluida).length}/{metasAtivas.length}
              </h3>
              <p className="text-slate-600 text-sm mt-1">Metas Concluídas</p>
              <div className="mt-4 flex items-center text-sm text-amber-600">
                <Award className="w-4 h-4 mr-1" />
                <span>Excelente progresso!</span>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-indigo-600/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <CardContent className="relative p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-2xl shadow-lg">
                  <Flame className="w-6 h-6 text-white" />
                </div>
                <Badge className="bg-purple-100 text-purple-700 border-purple-200 pointer-events-none">
                  Sequência
                </Badge>
              </div>
              <h3 className="text-2xl font-bold text-slate-800">7 dias</h3>
              <p className="text-slate-600 text-sm mt-1">Estudando Consecutivos</p>
              <div className="mt-4 flex items-center text-sm text-purple-600">
                <Flame className="w-4 h-4 mr-1" />
                <span>Continue assim!</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráfico de Atividade Semanal */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3 text-xl">
              <div className="p-2 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-lg">
                <BarChart3 className="w-5 h-5 text-white" />
              </div>
              Atividade dos Últimos 7 Dias
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={dadosGrafico}
                  margin={{ top: 5, right: 20, left: -10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="dia" tick={{ fill: '#64748b', fontSize: 12 }} />
                  <YAxis unit="h" allowDecimals={false} tick={{ fill: '#64748b', fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'rgba(255, 255, 255, 0.8)',
                      backdropFilter: 'blur(5px)',
                      border: '1px solid #e2e8f0',
                      borderRadius: '0.75rem',
                      boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)'
                    }}
                    labelStyle={{ fontWeight: 'bold', color: '#0f172a' }}
                    formatter={(value, name) => {
                      const horas = Math.floor(value);
                      const minutos = Math.round((value % 1) * 60);
                      if (horas > 0 && minutos > 0) {
                        return [`${horas}h ${minutos}min`, 'Tempo estudado'];
                      }
                      if (horas > 0) {
                        return [`${horas}h`, 'Tempo estudado'];
                      }
                      return [`${minutos}min`, 'Tempo estudado'];
                    }}
                  />
                  <Line type="monotone" dataKey="Horas" stroke="#4f46e5" strokeWidth={3} dot={{ r: 5, fill: '#4f46e5' }} activeDot={{ r: 8, className: 'stroke-blue-200' }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Progresso por Disciplina */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg">
                  <BookOpen className="w-5 h-5 text-white" />
                </div>
                Progresso por Disciplina
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2 hover:bg-red-50 hover:text-red-600 hover:border-red-200"
                  onClick={handleResetarProgresso}
                  disabled={disciplinas.filter(d => (d.questoes_total || 0) > 0).length === 0}
                >
                  <RotateCcw className="w-4 h-4" />
                  Resetar
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {(() => {
              // NOVO: Filtrar apenas disciplinas com questões resolvidas
              const disciplinasComQuestoes = disciplinas.filter(d => (d.questoes_total || 0) > 0);
              
              return disciplinasComQuestoes.length > 0 ? (
                <div className="grid gap-4">
                  {disciplinasComQuestoes.map((disciplina) => {
                    const questoesTotal = disciplina.questoes_total || 0;
                    const questoesCorretas = disciplina.questoes_corretas || 0;
                    const percentualAcerto = questoesTotal > 0 ? Math.round((questoesCorretas / questoesTotal) * 100) : 0;
                    
                    return (
                      <div key={disciplina.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-slate-50 to-blue-50/30 rounded-xl border border-slate-200/50">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-4 h-4 rounded-full"
                            style={{ backgroundColor: disciplina.cor || '#3b82f6' }}
                          ></div>
                          <div>
                            <span className="font-semibold text-slate-800">{disciplina.nome}</span>
                            <p className="text-xs text-slate-500 mt-1">
                              {percentualAcerto}% de acerto
                            </p>
                          </div>
                        </div>
                        
                        {/* REMOVIDO: Botões de Ação (Editar e Excluir) */}
                        <div className="flex items-center gap-3">
                          {/* Contagem de Questões */}
                          <div className="text-right">
                            <div className="flex items-center gap-2">
                              <span className="text-lg font-bold text-slate-800">
                                {questoesCorretas}
                              </span>
                              <span className="text-slate-400">/</span>
                              <span className="text-lg font-semibold text-slate-600">
                                {questoesTotal}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500">
                              questões resolvidas
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  <BookOpen className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                  <p className="text-lg">Nenhuma questão resolvida ainda</p>
                  <p className="text-sm mt-2">
                    Resolva questões no <strong>Treinamento</strong> ou <strong>Questões</strong> para ver seu progresso por disciplina
                  </p>
                </div>
              );
            })()}
          </CardContent>
        </Card>

        {/* Metas da Semana */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3 text-xl">
                <div className="p-2 bg-gradient-to-br from-amber-500 to-orange-500 rounded-lg">
                  <Target className="w-5 h-5 text-white" />
                </div>
                Metas da Semana
              </CardTitle>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  onClick={() => {
                    setMetaEdicao(null); // Ensure no meta is being edited
                    setShowMetaForm(true);
                  }}
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Meta
                </Button>
                <Button variant="outline" size="sm" className="gap-2">
                  Ver todas
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {metasAtivas.length > 0 ? (
              <div className="grid gap-4">
                {metasAtivas.slice(0, 4).map((meta) => {
                  const progresso = (meta.valor_atual / meta.valor_meta) * 100;
                  return (
                    <div key={meta.id} className="p-4 rounded-xl bg-gradient-to-r from-slate-50 to-blue-50/30 border border-slate-200/50 group">
                      <div className="flex items-center justify-between mb-3">
                        <h4 className="font-semibold text-slate-800">{meta.titulo}</h4>
                        <div className="flex items-center gap-2">
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0 hover:bg-blue-50"
                              onClick={() => abrirFormularioEdicao(meta)}
                            >
                              <Pencil className="w-3 h-3 text-blue-600" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 w-7 p-0 hover:bg-red-50"
                              onClick={() => handleExcluirMeta(meta)}
                            >
                              <Trash2 className="w-3 h-3 text-red-600" />
                            </Button>
                          </div>
                          <Badge
                            variant={meta.concluida ? "default" : progresso >= 80 ? "secondary" : "outline"}
                            className={
                              meta.concluida
                                ? "bg-green-100 text-green-700 border-green-200"
                                : progresso >= 80
                                  ? "bg-amber-100 text-amber-700 border-amber-200"
                                  : ""
                            }
                          >
                            {meta.concluida ? "Concluída" : `${Math.round(progresso)}%`}
                          </Badge>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm text-slate-600">
                          <span>{meta.valor_atual} {meta.unidade}</span>
                          <span>{meta.valor_meta} {meta.unidade}</span>
                        </div>
                        <Progress value={progresso} className="h-2" />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-12 text-slate-500">
                <Target className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                <p className="text-lg">Nenhuma meta cadastrada ainda</p>
                <p className="text-sm mt-2">Defina suas metas para manter o foco nos estudos</p>
                <Button
                  onClick={() => {
                    setMetaEdicao(null);
                    setShowMetaForm(true);
                  }}
                  className="mt-4 gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Criar Primeira Meta
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Formulário de Meta */}
        <MetaForm
          isOpen={showMetaForm}
          onClose={fecharFormulario}
          onSubmit={metaEdicao ? handleEditarMeta : handleCriarMeta}
          meta={metaEdicao}
        />
      </div>
    </div>
  );
}
