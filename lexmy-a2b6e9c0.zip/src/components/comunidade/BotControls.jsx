import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, Play, Zap, Clock, Shield, AlertCircle } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function BotControls({ onBotExecuted }) {
  const [bots, setBots] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [executingBotId, setExecutingBotId] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      // Verificar se é admin usando base44.auth
      const user = await base44.auth.me();
      setIsAdmin(user?.role === 'admin');
      
      // Carregar bots usando base44.entities
      const listaBots = await base44.entities.ChatBot.filter({ ativo: true });
      setBots(listaBots);
    } catch (error) {
      console.error('Erro ao carregar bots:', error);
      setIsAdmin(false);
      setBots([]);
    } finally {
      setIsLoading(false);
    }
  };

  const executarBot = async (botId) => {
    if (!isAdmin) {
      alert('Apenas administradores podem executar bots.');
      return;
    }

    setExecutingBotId(botId);
    try {
      const { data } = await base44.functions.invoke('executarBot', { botId });

      if (data.success) {
        alert(`Bot executado com sucesso!\n\nMensagens enviadas: ${data.mensagensEnviadas || 0}`);
        
        // Atualizar a última execução no bot
        await base44.entities.ChatBot.update(botId, {
          ultima_execucao: new Date().toISOString()
        });
        
        await carregarDados();
        
        // Notificar o componente pai para recarregar posts/chat
        if (onBotExecuted) {
          onBotExecuted();
        }
      } else {
        alert(`Erro ao executar bot:\n${data.error}`);
      }
    } catch (error) {
      console.error('Erro ao executar bot:', error);
      alert(`Erro ao executar bot:\n${error.message || 'Erro desconhecido'}`);
    } finally {
      setExecutingBotId(null);
    }
  };

  if (!isAdmin) {
    return null;
  }

  if (isLoading) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-12 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando controles administrativos...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-amber-50 to-orange-50/50 border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Shield className="w-5 h-5 text-amber-600" />
              Controles Administrativos
            </CardTitle>
            <CardDescription>Gerenciar bots automáticos da comunidade</CardDescription>
          </div>
          <Badge className="bg-amber-100 text-amber-700 border-amber-200">
            <Shield className="w-3 h-3 mr-1" />
            Admin
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        {bots.length === 0 ? (
          <div className="text-center py-8">
            <Bot className="w-12 h-12 mx-auto mb-4 text-slate-400" />
            <p className="text-slate-600">Nenhum bot ativo no momento</p>
            <p className="text-sm text-slate-500 mt-2">
              Configure bots na seção de administração
            </p>
          </div>
        ) : (
          <div className="grid gap-4">
            {bots.map((bot) => (
              <div
                key={bot.id}
                className="bg-white/60 backdrop-blur-sm p-4 rounded-xl border border-amber-200/50"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-amber-500 to-orange-500 rounded-xl flex items-center justify-center">
                      <Bot className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-slate-800">{bot.nome}</h4>
                      <p className="text-sm text-slate-600 mt-1">{bot.descricao}</p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-200/50">
                  <div className="flex items-center gap-4 text-xs text-slate-600">
                    {bot.config?.frequencia && (
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        <Clock className="w-3 h-3 mr-1" />
                        {bot.config.frequencia}
                      </Badge>
                    )}
                    {bot.ultima_execucao && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        Última execução: {new Date(bot.ultima_execucao).toLocaleString('pt-BR')}
                      </span>
                    )}
                  </div>

                  <Button
                    onClick={() => executarBot(bot.id)}
                    disabled={executingBotId === bot.id}
                    size="sm"
                    className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 gap-2"
                  >
                    {executingBotId === bot.id ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Executando...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4" />
                        Executar Agora
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
          <div className="text-xs text-blue-800">
            <p className="font-medium mb-1">Sobre os bots da comunidade:</p>
            <p>
              Os bots são agentes automáticos que interagem no chat 24h e nos posts da comunidade. 
              Eles podem responder dúvidas, compartilhar dicas e manter a comunidade engajada.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}