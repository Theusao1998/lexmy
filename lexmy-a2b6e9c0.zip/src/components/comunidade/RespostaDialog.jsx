import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import { MessageCircle, Send } from "lucide-react";
import { base44 } from "@/api/base44Client";

export default function RespostaDialog({ isOpen, onClose, post, onRespostaAdded }) {
  const [conteudo, setConteudo] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [erro, setErro] = useState('');

  const handleClose = () => {
    setConteudo('');
    setErro('');
    setIsSubmitting(false);
    onClose();
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!conteudo.trim()) {
      setErro('Digite uma resposta antes de enviar');
      return;
    }

    setIsSubmitting(true);
    setErro('');

    try {
      // Obter dados do usuário atual usando base44.auth
      const user = await base44.auth.me();
      
      // Criar a resposta usando base44.entities
      await base44.entities.RespostaComunidade.create({
        post_id: post.id,
        conteudo: conteudo.trim(),
        autor_nome: user.nome || user.full_name || user.email?.split('@')[0] || 'Usuário',
        curtidas: 0
      });

      // Notificar o componente pai
      if (onRespostaAdded) {
        onRespostaAdded();
      }

      handleClose();

    } catch (error) {
      console.error('Erro ao criar resposta:', error);
      
      if (error.response?.status === 401) {
        setErro('Sua sessão expirou. Faça login novamente para responder.');
      } else {
        setErro('Erro ao enviar resposta. Tente novamente.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!post) return null;

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-blue-600" />
            Responder à Postagem
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Postagem Original */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <h4 className="font-semibold text-slate-800 mb-2">{post.titulo}</h4>
            <p className="text-sm text-slate-600 line-clamp-3">{post.conteudo}</p>
          </div>

          {/* Campo de Resposta */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Sua Resposta
            </label>
            <Textarea
              value={conteudo}
              onChange={(e) => {
                setConteudo(e.target.value);
                if (erro) setErro('');
              }}
              placeholder="Digite sua resposta aqui..."
              rows={6}
              disabled={isSubmitting}
              className="resize-none"
            />
            <p className="text-xs text-slate-500">
              Seja respeitoso e construtivo em sua resposta
            </p>
          </div>

          {/* Erro */}
          {erro && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-600">{erro}</p>
            </div>
          )}

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={handleClose}
              disabled={isSubmitting}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || !conteudo.trim()}
              className="gap-2"
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Enviando...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Enviar Resposta
                </>
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}