import React, { useEffect, useRef, useState, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar } from "@/components/ui/avatar";
import { MessageCircle, Send, LogIn, Trash2, RefreshCw, AlertCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { ptBR } from "date-fns/locale";
import { base44 } from "@/api/base44Client";

export default function Chat24h() {
  const [mensagens, setMensagens] = useState([]);
  const [texto, setTexto] = useState("");
  const [enviando, setEnviando] = useState(false);
  const [me, setMe] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [erroConexao, setErroConexao] = useState(false);
  const [tentandoReconectar, setTentandoReconectar] = useState(false);
  const scrollRef = useRef(null);
  const isFetchingRef = useRef(false);

  const carregarMensagens = useCallback(async (doCleanup, tentativas = 0) => {
    if (isFetchingRef.current) return;
    isFetchingRef.current = true;
    
    const maxTentativas = 3;

    const scrollElement = scrollRef.current;
    const wasAtBottom = scrollElement ?
      scrollElement.scrollHeight - scrollElement.scrollTop <= scrollElement.clientHeight + 50 : true;

    try {
      setErroConexao(false);
      const lista = await base44.entities.ChatMessage.list('-created_date', 120);
      const agora = Date.now();
      const recentes = lista.filter((m) => {
        const t = new Date(m.created_date).getTime();
        return agora - t <= 24 * 60 * 60 * 1000;
      });
      setMensagens(recentes.reverse());

      if (doCleanup) {
        const antigas = lista.filter((m) => {
          const t = new Date(m.created_date).getTime();
          return agora - t > 24 * 60 * 60 * 1000;
        });
        
        for (const msg of antigas) {
          try {
            await base44.entities.ChatMessage.delete(msg.id);
          } catch (error) {
            if (error.response?.status === 404 || error.message?.includes('not found')) {
              continue;
            }
            console.warn('Erro ao deletar mensagem antiga:', error.message);
          }
        }
      }

      if (scrollElement && (wasAtBottom || doCleanup)) {
        setTimeout(() => {
          scrollElement.scrollTop = scrollElement.scrollHeight;
        }, 100);
      }
    } catch (error) {
      console.error('Erro ao carregar mensagens:', error);
      
      const isNetworkError = error.message?.includes('Network Error') || 
                            error.code === 'NETWORK_ERROR' ||
                            error.response?.status >= 500;
      
      if (isNetworkError && tentativas < maxTentativas) {
        console.log(`Tentativa ${tentativas + 1} de ${maxTentativas} para carregar mensagens`);
        setTimeout(() => {
          carregarMensagens(doCleanup, tentativas + 1);
        }, Math.pow(2, tentativas) * 1000);
      } else {
        setErroConexao(true);
      }
    } finally {
      isFetchingRef.current = false;
    }
  }, []);

  useEffect(() => {
    let intervalId;

    const init = async () => {
      try {
        const u = await base44.auth.me();
        setMe(u);
      } catch {
        setMe(null);
      }
      setAuthChecked(true);
      await carregarMensagens(true);
      intervalId = setInterval(() => {
        if (document.visibilityState === "visible" && !erroConexao) {
          carregarMensagens(false);
        }
      }, 5000);
    };
    init();

    const onVisibility = () => {
      if (document.visibilityState === "visible" && !erroConexao) {
        carregarMensagens(false);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      if (intervalId) clearInterval(intervalId);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [erroConexao, carregarMensagens]);

  const enviar = async () => {
    if (!me) {
      await base44.auth.redirectToLogin(window.location.href);
      return;
    }
    const conteudo = (texto || "").trim();
    if (!conteudo) return;
    if (conteudo.length > 2000) return;

    setEnviando(true);
    try {
      await base44.entities.ChatMessage.create({
        conteudo,
        autor_nome: me.full_name || (me.email ? me.email.split("@")[0] : "Usuário")
      });
      setTexto("");
      setErroConexao(false);
      
      await carregarMensagens(false);

      setTimeout(() => {
        if (scrollRef.current) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
      }, 100);
    } catch (error) {
      console.error("Erro ao enviar mensagem:", error);
      
      if (error.response?.status === 401) {
        alert("Sua sessão expirou. Faça login novamente.");
        await base44.auth.redirectToLogin(window.location.href);
      } else {
        alert("Erro ao enviar mensagem. Tente novamente.");
      }
    } finally {
      setEnviando(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      enviar();
    }
  };

  const tentarReconectar = async () => {
    setTentandoReconectar(true);
    await carregarMensagens(false);
    setTentandoReconectar(false);
  };

  if (!authChecked) {
    return (
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-12 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando chat...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader className="border-b border-slate-200/60">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-blue-600" />
            Chat 24h da Comunidade
            <Badge className="bg-green-100 text-green-700 border-green-200 ml-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse mr-2"></div>
              Ao Vivo
            </Badge>
          </CardTitle>
          {erroConexao && (
            <Button
              onClick={tentarReconectar}
              size="sm"
              variant="outline"
              className="gap-2"
              disabled={tentandoReconectar}
            >
              {tentandoReconectar ? (
                <>
                  <div className="w-4 h-4 border-2 border-slate-600 border-t-transparent rounded-full animate-spin" />
                  Reconectando...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4" />
                  Reconectar
                </>
              )}
            </Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="p-0">
        {erroConexao && (
          <div className="bg-amber-50 border-b border-amber-200 p-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0" />
            <p className="text-sm text-amber-800">
              Erro de conexão. As mensagens podem estar desatualizadas.
            </p>
          </div>
        )}

        <div
          ref={scrollRef}
          className="h-[500px] overflow-y-auto p-6 space-y-4 bg-gradient-to-b from-slate-50/50 to-white"
        >
          {mensagens.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <MessageCircle className="w-16 h-16 text-slate-300 mb-4" />
              <h3 className="text-lg font-semibold text-slate-700 mb-2">
                Nenhuma mensagem ainda
              </h3>
              <p className="text-slate-500 max-w-md">
                Seja o primeiro a iniciar uma conversa! As mensagens são excluídas automaticamente após 24 horas.
              </p>
            </div>
          ) : (
            mensagens.map((msg) => {
              const isMe = me && msg.created_by === me.email;
              return (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${isMe ? "flex-row-reverse" : ""}`}
                >
                  <Avatar className="w-10 h-10 flex-shrink-0">
                    <div className="w-full h-full bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-semibold text-sm">
                      {(msg.autor_nome || "U").slice(0, 2).toUpperCase()}
                    </div>
                  </Avatar>

                  <div className={`flex-1 max-w-[70%] ${isMe ? "items-end" : ""}`}>
                    <div className={`flex items-center gap-2 mb-1 ${isMe ? "flex-row-reverse" : ""}`}>
                      <span className="text-sm font-semibold text-slate-700">
                        {msg.autor_nome || "Usuário"}
                      </span>
                      {isMe && (
                        <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                          Você
                        </Badge>
                      )}
                    </div>

                    <div
                      className={`rounded-2xl px-4 py-3 ${
                        isMe
                          ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white"
                          : "bg-white border border-slate-200"
                      }`}
                    >
                      <p className={`text-sm leading-relaxed whitespace-pre-wrap break-words ${isMe ? "text-white" : "text-slate-800"}`}>
                        {msg.conteudo}
                      </p>
                    </div>

                    <p className={`text-xs text-slate-500 mt-1 ${isMe ? "text-right" : ""}`}>
                      {formatDistanceToNow(new Date(msg.created_date), {
                        locale: ptBR,
                        addSuffix: true
                      })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
        </div>

        <div className="border-t border-slate-200/60 p-4 bg-slate-50/50">
          {!me ? (
            <div className="text-center py-4">
              <p className="text-slate-600 mb-3">Faça login para participar do chat</p>
              <Button
                onClick={() => base44.auth.redirectToLogin(window.location.href)}
                className="gap-2"
              >
                <LogIn className="w-4 h-4" />
                Fazer Login
              </Button>
            </div>
          ) : (
            <div className="flex gap-3">
              <Input
                value={texto}
                onChange={(e) => setTexto(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Digite sua mensagem..."
                disabled={enviando}
                maxLength={2000}
                className="flex-1"
              />
              <Button
                onClick={enviar}
                disabled={enviando || !texto.trim()}
                className="bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 gap-2"
              >
                {enviando ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Enviar
                  </>
                )}
              </Button>
            </div>
          )}
          {me && (
            <p className="text-xs text-slate-500 mt-2">
              {texto.length}/2000 caracteres • As mensagens são excluídas após 24h
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}