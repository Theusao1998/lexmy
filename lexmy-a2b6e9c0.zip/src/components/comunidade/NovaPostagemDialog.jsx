import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter
} from "@/components/ui/dialog";
import {
  HelpCircle,
  Lightbulb,
  MessageCircle,
  BookOpen,
  Share2,
  Plus,
  X
} from "lucide-react";
import { base44 } from "@/api/base44Client";

const categoriaIcons = {
  duvida: HelpCircle,
  dica: Lightbulb,
  discussao: MessageCircle,
  material: BookOpen,
  experiencia: Share2
};

const categoriaColors = {
  duvida: "bg-blue-100 text-blue-700 border-blue-200",
  dica: "bg-amber-100 text-amber-700 border-amber-200",
  discussao: "bg-purple-100 text-purple-700 border-purple-200",
  material: "bg-green-100 text-green-700 border-green-200",
  experiencia: "bg-pink-100 text-pink-700 border-pink-200"
};

const categoriaLabels = {
  duvida: "Dúvida",
  dica: "Dica",
  discussao: "Discussão",
  material: "Material",
  experiencia: "Experiência"
};

export default function NovaPostagemDialog({ isOpen, onClose, onPostCreated }) {
  const [formData, setFormData] = useState({
    titulo: '',
    conteudo: '',
    categoria: '',
    disciplina: '',
    tags: []
  });
  const [novaTag, setNovaTag] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [erro, setErro] = useState('');

  const disciplinasComuns = [
    'Direito Constitucional',
    'Direito Administrativo',
    'Direito Civil',
    'Direito Penal',
    'Direito Processual Civil',
    'Direito Processual Penal',
    'Direito do Trabalho',
    'Direito Tributário',
    'Direito Previdenciário',
    'Português',
    'Raciocínio Lógico',
    'Informática',
    'Conhecimentos Gerais'
  ];

  const resetForm = () => {
    setFormData({
      titulo: '',
      conteudo: '',
      categoria: '',
      disciplina: '',
      tags: []
    });
    setNovaTag('');
    setErro('');
    setIsSubmitting(false);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (erro) setErro('');
  };

  const adicionarTag = () => {
    const tag = novaTag.trim().toLowerCase();
    if (tag && !formData.tags.includes(tag) && formData.tags.length < 5) {
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
      setNovaTag('');
    }
  };

  const removerTag = (tagToRemove) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.titulo.trim()) {
      setErro('O título é obrigatório');
      return;
    }
    if (!formData.conteudo.trim()) {
      setErro('O conteúdo é obrigatório');
      return;
    }
    if (!formData.categoria) {
      setErro('Selecione uma categoria');
      return;
    }

    setIsSubmitting(true);
    setErro('');

    try {
      // Obter dados do usuário atual usando base44.auth
      const user = await base44.auth.me();
      
      // Criar a postagem usando base44.entities
      await base44.entities.PostComunidade.create({
        titulo: formData.titulo.trim(),
        conteudo: formData.conteudo.trim(),
        categoria: formData.categoria,
        disciplina: formData.disciplina || null,
        tags: formData.tags.length > 0 ? formData.tags : null,
        autor_nome: user.nome || user.full_name || user.email?.split('@')[0] || 'Usuário',
        curtidas: 0
      });

      onPostCreated?.();
      handleClose();

    } catch (error) {
      console.error('Erro ao criar postagem:', error);
      
      if (error.response?.status === 401) {
        setErro('Sua sessão expirou. Faça login novamente para postar.');
      } else {
        setErro('Erro ao publicar. Tente novamente.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const IconeCategoria = categoriaIcons[formData.categoria];

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5 text-blue-600" />
            Nova Postagem na Comunidade
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Título */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Título da postagem *
            </label>
            <Input
              value={formData.titulo}
              onChange={(e) => handleInputChange('titulo', e.target.value)}
              placeholder="Digite um título claro e objetivo..."
              maxLength={200}
              className="text-base"
            />
            <p className="text-xs text-slate-500">
              {formData.titulo.length}/200 caracteres
            </p>
          </div>

          {/* Categoria */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Categoria *
            </label>
            <Select value={formData.categoria} onValueChange={(value) => handleInputChange('categoria', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a categoria da postagem" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(categoriaLabels).map(([key, label]) => {
                  const Icon = categoriaIcons[key];
                  return (
                    <SelectItem key={key} value={key}>
                      <div className="flex items-center gap-2">
                        <Icon className="w-4 h-4" />
                        {label}
                      </div>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
            {formData.categoria && (
              <div className="flex items-center gap-2">
                <Badge className={`${categoriaColors[formData.categoria]} border flex items-center gap-1`}>
                  <IconeCategoria className="w-3 h-3" />
                  {categoriaLabels[formData.categoria]}
                </Badge>
              </div>
            )}
          </div>

          {/* Disciplina */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Disciplina (opcional)
            </label>
            <Select value={formData.disciplina} onValueChange={(value) => handleInputChange('disciplina', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione a disciplina relacionada" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>Nenhuma disciplina específica</SelectItem>
                {disciplinasComuns.map((disciplina) => (
                  <SelectItem key={disciplina} value={disciplina}>
                    {disciplina}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Conteúdo */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Conteúdo *
            </label>
            <Textarea
              value={formData.conteudo}
              onChange={(e) => handleInputChange('conteudo', e.target.value)}
              placeholder="Compartilhe sua dúvida, dica, experiência ou material..."
              className="min-h-[120px] text-base leading-relaxed"
              maxLength={2000}
            />
            <p className="text-xs text-slate-500">
              {formData.conteudo.length}/2000 caracteres
            </p>
          </div>

          {/* Tags */}
          <div className="space-y-3">
            <label className="text-sm font-medium text-slate-700">
              Tags (opcional)
            </label>
            <div className="flex gap-2">
              <Input
                value={novaTag}
                onChange={(e) => setNovaTag(e.target.value)}
                placeholder="Digite uma tag..."
                className="flex-1"
                maxLength={20}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    adicionarTag();
                  }
                }}
              />
              <Button
                type="button"
                onClick={adicionarTag}
                disabled={!novaTag.trim() || formData.tags.length >= 5}
                variant="outline"
                size="icon"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            
            {formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {formData.tags.map((tag, index) => (
                  <Badge key={index} variant="outline" className="gap-1">
                    #{tag}
                    <button
                      type="button"
                      onClick={() => removerTag(tag)}
                      className="ml-1 hover:text-red-600"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
            <p className="text-xs text-slate-500">
              Máximo 5 tags. Use tags para facilitar a busca da sua postagem.
            </p>
          </div>

          {/* Erro */}
          {erro && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700 flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                {erro}
              </p>
            </div>
          )}
        </form>

        <DialogFooter>
          <Button
            type="button"
            variant="outline"
            onClick={handleClose}
            disabled={isSubmitting}
          >
            Cancelar
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !formData.titulo.trim() || !formData.conteudo.trim() || !formData.categoria}
            className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 gap-2"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                Publicando...
              </>
            ) : (
              <>
                <MessageCircle className="w-4 h-4" />
                Publicar Postagem
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}