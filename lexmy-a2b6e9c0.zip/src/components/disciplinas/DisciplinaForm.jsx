import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

const coresDisponiveis = [
  { nome: "Azul", valor: "#3b82f6" },
  { nome: "Verde", valor: "#10b981" },
  { nome: "Vermelho", valor: "#ef4444" },
  { nome: "Amarelo", valor: "#f59e0b" },
  { nome: "Roxo", valor: "#8b5cf6" },
  { nome: "Rosa", valor: "#ec4899" },
  { nome: "Laranja", valor: "#f97316" },
  { nome: "Ciano", valor: "#06b6d4" },
];

export default function DisciplinaForm({ isOpen, onClose, onSubmit, disciplina = null }) {
  const [form, setForm] = useState({
    nome: disciplina?.nome || "",
    descricao: disciplina?.descricao || "",
    cor: disciplina?.cor || "#3b82f6",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(form);
    onClose();
  };

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{disciplina ? 'Editar Disciplina' : 'Nova Disciplina'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="nome">Nome da Disciplina</Label>
            <Input
              id="nome"
              value={form.nome}
              onChange={(e) => handleChange("nome", e.target.value)}
              placeholder="Ex: Direito Constitucional"
              required
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="descricao">Descrição (opcional)</Label>
            <Textarea
              id="descricao"
              value={form.descricao}
              onChange={(e) => handleChange("descricao", e.target.value)}
              placeholder="Descrição da disciplina..."
              className="h-20"
            />
          </div>

          <div className="grid gap-2">
            <Label>Cor de Identificação</Label>
            <div className="grid grid-cols-4 gap-2">
              {coresDisponiveis.map((cor) => (
                <button
                  key={cor.valor}
                  type="button"
                  className={`w-12 h-12 rounded-lg border-2 transition-all hover:scale-105 ${
                    form.cor === cor.valor ? 'border-slate-400 ring-2 ring-slate-300' : 'border-slate-200'
                  }`}
                  style={{ backgroundColor: cor.valor }}
                  onClick={() => handleChange("cor", cor.valor)}
                  title={cor.nome}
                />
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">
              {disciplina ? 'Atualizar' : 'Criar'} Disciplina
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}