import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  BookOpen,
  FileText,
  Scale,
  Newspaper,
  Image as ImageIcon,
  Upload
} from "lucide-react";
import { Material } from "@/api/entities";
import { FiltroQuestao } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function AdministracaoBiblioteca() {
  const [materiais, setMateriais] = useState([]);
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filtros
  const [filtroTipo, setFiltroTipo] = useState("all");
  const [filtroDisciplina, setFiltroDisciplina] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Modal de criação/edição
  const [showModal, setShowModal] = useState(false);
  const [editingMaterial, setEditingMaterial] = useState(null);
  const [formData, setFormData] = useState({
    titulo: '',
    tipo: 'legislacao',
    disciplina: '',
    conteudo_puro: '',
    imagem_url: '',
    tags: [],
    descricao: ''
  });
  const [salvando, setSalvando] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const [materiaisData, filtrosData] = await Promise.all([
        Material.list('-created_date', 200),
        FiltroQuestao.list('-created_date', 100)
      ]);
      
      setMateriais(materiaisData);
      setFiltrosDisponiveis(filtrosData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar materiais.');
    } finally {
      setIsLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = filtrosDisponiveis.map(f => f.disciplina);
    return [...new Set(disciplinas)].sort();
  }, [filtrosDisponiveis]);

  const materiaisFiltrados = React.useMemo(() => {
    return materiais.filter(m => {
      const matchTipo = filtroTipo === "all" || m.tipo === filtroTipo;
      const matchDisciplina = filtroDisciplina === "all" || m.disciplina === filtroDisciplina;
      const matchBusca = !filtroBusca || 
        m.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        m.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase());
      return matchTipo && matchDisciplina && matchBusca;
    });
  }, [materiais, filtroTipo, filtroDisciplina, filtroBusca]);

  const resetForm = useCallback(() => {
    setFormData({
      titulo: '',
      tipo: 'legislacao',
      disciplina: '',
      conteudo_puro: '',
      imagem_url: '',
      tags: [],
      descricao: ''
    });
    setEditingMaterial(null);
  }, []);

  const handleNovoMaterial = useCallback(() => {
    resetForm();
    setShowModal(true);
  }, [resetForm]);

  const handleEditarMaterial = useCallback((material) => {
    setEditingMaterial(material);
    setFormData({
      titulo: material.titulo || '',
      tipo: material.tipo || 'legislacao',
      disciplina: material.disciplina || '',
      conteudo_puro: material.conteudo_puro || '',
      imagem_url: material.imagem_url || '',
      tags: material.tags || [],
      descricao: material.descricao || ''
    });
    setShowModal(true);
  }, []);

  const handleUploadImagem = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    try {
      const { data } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, imagem_url: data.file_url }));
      toast.success('Imagem enviada com sucesso!');
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      toast.error('Erro ao enviar imagem.');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSalvarMaterial = useCallback(async () => {
    if (!formData.titulo || !formData.tipo) {
      toast.error('Preencha o título e o tipo.');
      return;
    }

    if (formData.tipo === 'resumo' && !formData.imagem_url) {
      toast.error('Resumos visuais precisam de uma imagem.');
      return;
    }

    if (formData.tipo !== 'resumo' && !formData.conteudo_puro) {
      toast.error('Preencha o conteúdo do material.');
      return;
    }

    setSalvando(true);
    try {
      if (editingMaterial) {
        await Material.update(editingMaterial.id, formData);
        toast.success('Material atualizado com sucesso!');
      } else {
        await Material.create(formData);
        toast.success('Material criado com sucesso!');
      }

      setShowModal(false);
      resetForm();
      carregarDados();

    } catch (error) {
      console.error('Erro ao salvar material:', error);
      toast.error('Erro ao salvar material.');
    } finally {
      setSalvando(false);
    }
  }, [formData, editingMaterial, resetForm]);

  const handleExcluirMaterial = useCallback(async (materialId) => {
    if (!confirm('Tem certeza que deseja excluir este material? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await Material.delete(materialId);
      toast.success('Material excluído com sucesso!');
      carregarDados();
    } catch (error) {
      console.error('Erro ao excluir material:', error);
      toast.error('Erro ao excluir material.');
    }
  }, []);

  const getTipoIcon = (tipo) => {
    switch (tipo) {
      case 'legislacao': return <Scale className="w-4 h-4" />;
      case 'material': return <BookOpen className="w-4 h-4" />;
      case 'jurisprudencia': return <FileText className="w-4 h-4" />;
      case 'informativo': return <Newspaper className="w-4 h-4" />;
      case 'resumo': return <ImageIcon className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const getTipoLabel = (tipo) => {
    const labels = {
      legislacao: 'Legislação',
      material: 'Material',
      jurisprudencia: 'Jurisprudência',
      informativo: 'Informativo',
      resumo: 'Resumo Visual'
    };
    return labels[tipo] || tipo;
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Materiais da Biblioteca
          </h3>
          <Button onClick={handleNovoMaterial} className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Material
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">
            {/* Filtros */}
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Tipo</label>
                <Select value={filtroTipo} onValueChange={setFiltroTipo}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os tipos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os tipos</SelectItem>
                    <SelectItem value="legislacao">Legislação</SelectItem>
                    <SelectItem value="material">Material</SelectItem>
                    <SelectItem value="jurisprudencia">Jurisprudência</SelectItem>
                    <SelectItem value="informativo">Informativo</SelectItem>
                    <SelectItem value="resumo">Resumo Visual</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Disciplina</label>
                <Select value={filtroDisciplina} onValueChange={setFiltroDisciplina}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas as disciplinas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as disciplinas</SelectItem>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-700">Buscar</label>
                <Input
                  placeholder="Digite o título ou disciplina..."
                  value={filtroBusca}
                  onChange={(e) => setFiltroBusca(e.target.value)}
                />
              </div>
            </div>

            {/* Lista de Materiais */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando materiais...</p>
              </div>
            ) : materiaisFiltrados.length === 0 ? (
              <div className="text-center py-12">
                <BookOpen className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhum material encontrado
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtroTipo || filtroDisciplina || filtroBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhum material cadastrado ainda."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {materiaisFiltrados.map((material) => (
                  <Card key={material.id} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                              {getTipoIcon(material.tipo)}
                            </div>
                            <div>
                              <h4 className="font-semibold text-slate-800">{material.titulo}</h4>
                              {material.descricao && (
                                <p className="text-sm text-slate-600 line-clamp-1">{material.descricao}</p>
                              )}
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            <Badge variant="outline">
                              {getTipoLabel(material.tipo)}
                            </Badge>
                            {material.disciplina && (
                              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                                {material.disciplina}
                              </Badge>
                            )}
                            {material.tags && material.tags.length > 0 && (
                              <Badge variant="outline" className="text-xs">
                                {material.tags.length} tags
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarMaterial(material)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirMaterial(material.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Criar/Editar Material */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              {editingMaterial ? 'Editar Material' : 'Novo Material'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Título *</Label>
                <Input
                  value={formData.titulo}
                  onChange={(e) => setFormData(prev => ({ ...prev, titulo: e.target.value }))}
                  placeholder="Ex: Constituição Federal de 1988"
                />
              </div>

              <div className="space-y-2">
                <Label>Tipo *</Label>
                <Select
                  value={formData.tipo}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, tipo: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="legislacao">Legislação</SelectItem>
                    <SelectItem value="material">Material</SelectItem>
                    <SelectItem value="jurisprudencia">Jurisprudência</SelectItem>
                    <SelectItem value="informativo">Informativo</SelectItem>
                    <SelectItem value="resumo">Resumo Visual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Disciplina</Label>
              <Select
                value={formData.disciplina}
                onValueChange={(value) => setFormData(prev => ({ ...prev, disciplina: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a disciplina" />
                </SelectTrigger>
                <SelectContent>
                  {disciplinasUnicas.map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={formData.descricao}
                onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Breve descrição do material..."
                className="h-20"
              />
            </div>

            {formData.tipo === 'resumo' ? (
              <div className="space-y-2">
                <Label>Imagem do Resumo *</Label>
                <div className="flex gap-2">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleUploadImagem}
                    disabled={uploadingImage}
                    className="flex-1"
                  />
                  {uploadingImage && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                      Enviando...
                    </div>
                  )}
                </div>
                {formData.imagem_url && (
                  <div className="mt-2 relative w-full h-48 bg-slate-100 rounded-lg overflow-hidden">
                    <img
                      src={formData.imagem_url}
                      alt="Preview"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                <Label>Conteúdo *</Label>
                <Textarea
                  value={formData.conteudo_puro}
                  onChange={(e) => setFormData(prev => ({ ...prev, conteudo_puro: e.target.value }))}
                  placeholder="Cole o conteúdo completo do material aqui..."
                  className="min-h-[300px] font-mono text-sm"
                />
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarMaterial} disabled={salvando}>
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingMaterial ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}