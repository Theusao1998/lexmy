import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useTimer } from "./TimerContext";
import { Timer as TimerIcon, Play, Pause, Square } from "lucide-react";

export default function TimerSidebarSummary() {
  const { tempoRestante, tempoTotal, isAtivo, iniciarPausar, resetar, formatarTempo } = useTimer();

  return (
    <div className="px-3">
      <div className="bg-blue-50 p-4 rounded-xl border border-slate-200/50 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-gradient-to-r from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
              <TimerIcon className="w-3 h-3 text-white" />
            </div>
            <span className="text-xs font-medium text-slate-700">
              {isAtivo ? 'Estudando' : 'Pausado'}
            </span>
          </div>
          {isAtivo && (
            <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          )}
        </div>
        
        <div className="text-center">
          <p className="text-2xl font-bold font-mono text-slate-800">
            {formatarTempo(tempoRestante)}
          </p>
          <div className="w-full bg-slate-200 rounded-full h-1.5 mt-2">
            <div 
              className="bg-gradient-to-r from-blue-500 to-blue-600 h-1.5 rounded-full transition-all duration-1000"
              style={{width: `${((tempoTotal - tempoRestante) / tempoTotal) * 100}%`}}
            ></div>
          </div>
        </div>
        
        <div className="flex justify-center gap-2">
          <Button 
            onClick={iniciarPausar}
            size="sm" 
            className="bg-gradient-to-r from-blue-500 to-blue-600 hover:opacity-90 text-white px-3 py-1 h-7 text-xs"
          >
            {isAtivo ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
          </Button>
          <Button 
            onClick={resetar}
            variant="outline" 
            size="sm"
            className="px-3 py-1 h-7 text-xs"
          >
            <Square className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </div>
  );
}