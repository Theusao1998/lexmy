
import React, { createContext, useContext, useEffect, useState, useMemo, useRef, useCallback } from "react";
import { MusicaFoco } from "@/api/entities";
import { SessaoEstudo } from "@/api/entities";
import { User } from "@/api/entities";

const TimerContext = createContext(null);

export function TimerProvider({ children }) {
  // Estados do temporizador (persistidos no localStorage)
  const [tempoRestante, setTempoRestante] = useState(() => Number(localStorage.getItem("timer_tempoRestante") || 25 * 60));
  const [tempoTotal, setTempoTotal] = useState(() => Number(localStorage.getItem("timer_tempoTotal") || 25 * 60));
  const [isAtivo, setIsAtivo] = useState(() => localStorage.getItem("timer_isAtivo") === "true");
  const [sessaoIniciadaIso, setSessaoIniciadaIso] = useState(() => localStorage.getItem("timer_sessaoIniciadaIso"));

  // NOVO: Estado para controlar timestamps precisos do temporizador
  const [ultimoTimestamp, setUltimoTimestamp] = useState(null);

  // Configurações do usuário
  const [tempoPersonalizado, setTempoPersonalizado] = useState(25);
  const [selectedMusicId, setSelectedMusicId] = useState("");
  const [selectedMusicTitle, setSelectedMusicTitle] = useState(""); // ADICIONADO
  const [volumeMusica, setVolumeMusica] = useState(0.5);
  const [configuracoesCarregadas, setConfiguracoesCarregadas] = useState(false);

  // Dados de sessão
  const [sessoes, setSessoes] = useState([]);
  
  const audioRef = useRef(null);
  
  // Persistência no localStorage
  useEffect(() => { localStorage.setItem("timer_tempoRestante", String(tempoRestante)) }, [tempoRestante]);
  useEffect(() => { localStorage.setItem("timer_tempoTotal", String(tempoTotal)) }, [tempoTotal]);
  useEffect(() => { localStorage.setItem("timer_isAtivo", String(isAtivo)) }, [isAtivo]);
  useEffect(() => {
    if (sessaoIniciadaIso) localStorage.setItem("timer_sessaoIniciadaIso", sessaoIniciadaIso);
    else localStorage.removeItem("timer_sessaoIniciadaIso");
  }, [sessaoIniciadaIso]);

  // Carregar dados iniciais (configurações do usuário e sessões salvas)
  useEffect(() => {
    const carregarDadosIniciais = async () => {
      try {
        const user = await User.me();
        const config = user.timer_config || {};
        setTempoPersonalizado(config.tempo_personalizado || 25);
        setSelectedMusicId(config.selected_music_id || "");
        setSelectedMusicTitle(config.selected_music_title || ""); // ADICIONADO
        setVolumeMusica(config.volume_musica || 0.5);

        // Define o tempo inicial apenas se não houver uma sessão em andamento salva
        if (!localStorage.getItem("timer_tempoRestante") && !localStorage.getItem("timer_sessaoIniciadaIso")) {
          const novoTempoSegundos = (config.tempo_personalizado || 25) * 60;
          setTempoRestante(novoTempoSegundos);
          setTempoTotal(novoTempoSegundos);
        }
        
        // Carrega as sessões já salvas
        const sessoesSalvas = await SessaoEstudo.list('-data_inicio', 200);
        setSessoes(sessoesSalvas);

      } catch (error) {
        console.log('Usuário não autenticado - usando configurações padrão do timer');
      } finally {
        setConfiguracoesCarregadas(true);
      }
    };
    carregarDadosIniciais();
  }, []);

  // Lógica de música
  useEffect(() => {
    const loadMusic = async () => {
      if (!selectedMusicId) {
        setSelectedMusicTitle(""); // Clear title if no music ID
        return;
      }
      try {
        const [musica] = await MusicaFoco.filter({ id: selectedMusicId });
        if (musica?.audio_url && audioRef.current) {
          audioRef.current.src = musica.audio_url;
          setSelectedMusicTitle(musica.nome || ""); // Update title when music is loaded
        } else {
          setSelectedMusicTitle(""); // Clear title if music not found or URL missing
        }
      } catch (e) { 
        console.error("Erro ao carregar música", e); 
        setSelectedMusicTitle(""); // Clear title on error
      }
    };
    if (configuracoesCarregadas) loadMusic();
  }, [selectedMusicId, configuracoesCarregadas]);

  useEffect(() => {
    if (!audioRef.current) audioRef.current = new Audio();
    audioRef.current.loop = true;
    audioRef.current.volume = volumeMusica;

    if (isAtivo && selectedMusicId) {
      audioRef.current.play().catch(() => {});
    } else {
      audioRef.current.pause();
    }
  }, [isAtivo, volumeMusica, selectedMusicId]);

  // Função central para salvar a sessão atual
  const salvarSessaoAtual = useCallback(async () => {
    if (!sessaoIniciadaIso) return null;

    const inicioSessao = new Date(sessaoIniciadaIso);
    const duracaoSegundos = Math.floor((new Date().getTime() - inicioSessao.getTime()) / 1000);
    
    // Não salvar sessões muito curtas
    if (duracaoSegundos < 5) {
      setSessaoIniciadaIso(null); // Limpa a sessão em andamento
      return null;
    }

    const duracaoMinutos = parseFloat((duracaoSegundos / 60).toFixed(2));

    const novaSessao = {
      duracao_minutos: duracaoMinutos,
      data_inicio: sessaoIniciadaIso,
      data_fim: new Date().toISOString()
    };
    
    // ATUALIZAÇÃO OTIMISTA: Adiciona a nova sessão ao estado local imediatamente
    setSessoes(prevSessoes => [novaSessao, ...prevSessoes]);
    
    // Limpa a sessão em andamento
    setSessaoIniciadaIso(null);

    // Salva no banco de dados em segundo plano
    try {
      await SessaoEstudo.create(novaSessao);
      console.log(`Sessão salva: ${duracaoMinutos.toFixed(2)} minutos`);
    } catch (error) {
      console.error('Erro ao salvar sessão no banco de dados:', error);
      // Opcional: implementar lógica para remover a sessão otimista em caso de falha
    }
    
    return novaSessao;
  }, [sessaoIniciadaIso]);

  // ATUALIZADO: Tick do temporizador com salvamento automático ao esgotar
  useEffect(() => {
    let intervalo = null;
    
    if (isAtivo && tempoRestante > 0) {
      // Inicializar o timestamp quando o timer começar ou retomar
      if (ultimoTimestamp === null) {
        setUltimoTimestamp(Date.now());
      }
      
      intervalo = setInterval(() => {
        const agora = Date.now();
        setUltimoTimestamp(prevUltimoTimestamp => {
          const tempoDecorrido = Math.floor((agora - (prevUltimoTimestamp || agora)) / 1000);
          
          if (tempoDecorrido > 0) {
            setTempoRestante(prev => {
              const novoTempo = Math.max(0, prev - tempoDecorrido);
              
              // CORRIGIDO: Se chegou a zero, salvar sessão automaticamente
              if (novoTempo === 0) {
                setIsAtivo(false);
                
                // Salvar a sessão atual antes de limpar
                (async () => {
                  try {
                    await salvarSessaoAtual();
                    console.log('Sessão salva automaticamente ao esgotar o tempo do temporizador');
                  } catch (error) {
                    console.error('Erro ao salvar sessão automaticamente:', error);
                  }
                })();
                
                // Limpar o timestamp e a sessão em andamento
                setUltimoTimestamp(null);
                setSessaoIniciadaIso(null);
              }
              
              return novoTempo;
            });
            
            return agora;
          }
          return prevUltimoTimestamp;
        });
      }, 1000);
    } else {
      // Resetar o timestamp quando o timer não estiver ativo
      if (!isAtivo || tempoRestante === 0) {
        setUltimoTimestamp(null);
      }
    }
    
    return () => {
      if (intervalo) {
        clearInterval(intervalo);
      }
    };
  }, [isAtivo, tempoRestante, ultimoTimestamp, salvarSessaoAtual]);

  // Controles do temporizador
  const iniciarPausar = useCallback(async () => {
    if (isAtivo) { // Se está ativo, vamos pausar e salvar
      await salvarSessaoAtual();
      setUltimoTimestamp(null); // NOVO: Resetar timestamp ao pausar
    } else { // Se está pausado, vamos iniciar uma nova sessão
      setSessaoIniciadaIso(new Date().toISOString());
      setUltimoTimestamp(Date.now()); // NOVO: Inicializar timestamp ao iniciar
    }
    setIsAtivo(prev => !prev);
  }, [isAtivo, salvarSessaoAtual]);

  const resetar = useCallback(async () => {
    // Primeiro, salva a sessão atual, se houver
    await salvarSessaoAtual();

    // Depois, reseta o estado do temporizador para os valores padrão
    setIsAtivo(false);
    const novoTempo = tempoPersonalizado * 60;
    setTempoRestante(novoTempo);
    setTempoTotal(novoTempo);
    setSessaoIniciadaIso(null); // Garante que a sessão em andamento foi limpa
    setUltimoTimestamp(null); // NOVO: Resetar timestamp ao resetar
  }, [salvarSessaoAtual, tempoPersonalizado]);
  
  // Função de cálculo de tempo estudado - CORRIGIDA
  const calcularTempoEstudadoHoje = useCallback(() => {
    // ADICIONADO: Verificação de segurança
    if (!Array.isArray(sessoes)) {
      console.log('Sessões ainda não carregadas, retornando 0');
      return 0;
    }

    try {
      // CORRIGIDO: Usar uma lógica mais simples e confiável para a data de hoje
      const hoje = new Date();
      const ano = hoje.getFullYear();
      const mes = String(hoje.getMonth() + 1).padStart(2, '0');
      const dia = String(hoje.getDate()).padStart(2, '0');
      const hojeStr = `${ano}-${mes}-${dia}`;

      console.log('=== CÁLCULO TEMPO ESTUDADO ===');
      console.log('Data de hoje (calculada):', hojeStr);

      // 1. CORRIGIDO: Soma apenas sessões JÁ SALVAS e FINALIZADAS do dia de hoje
      const sessoesHoje = sessoes.filter(sessao => {
        if (!sessao || !sessao.data_inicio || typeof sessao.duracao_minutos !== 'number') return false;
        
        // Extrair apenas a parte da data (YYYY-MM-DD) do ISO string
        const dataInicioSessao = sessao.data_inicio.split('T')[0];
        return dataInicioSessao === hojeStr;
      });

      console.log(`Sessões salvas encontradas para hoje: ${sessoesHoje.length}`);
      sessoesHoje.forEach((s, i) => {
        console.log(`  ${i+1}. ${s.duracao_minutos} min - ${s.data_inicio}`);
      });

      // CORRIGIDO: Usar Math.round para evitar decimais imprecisos
      const minutosSessoesSalvas = Math.round(
        sessoesHoje.reduce((total, sessao) => {
          return total + (sessao.duracao_minutos || 0);
        }, 0)
      );

      console.log(`Total de minutos de sessões salvas: ${minutosSessoesSalvas}`);

      // 2. CORRIGIDO: Adiciona apenas o tempo da sessão EM ANDAMENTO (se houver e for de hoje)
      let minutosEmAndamento = 0;
      if (isAtivo && sessaoIniciadaIso) {
        // Extrair apenas a parte da data do início da sessão atual
        const inicioDataStr = sessaoIniciadaIso.split('T')[0];
        
        if (inicioDataStr === hojeStr) {
          // CORRIGIDO: Calcular o tempo decorrido desde o início da sessão atual
          const inicioSessao = new Date(sessaoIniciadaIso);
          const agora = new Date();
          const segundosDecorridos = Math.floor((agora.getTime() - inicioSessao.getTime()) / 1000);
          minutosEmAndamento = Math.floor(segundosDecorridos / 60);
          console.log(`Sessão em andamento (hoje): ${minutosEmAndamento} min (${segundosDecorridos}s decorridos)`);
        } else {
          console.log('Sessão em andamento é de outro dia, não somando');
        }
      } else if (sessaoIniciadaIso && !isAtivo) {
        // CORRIGIDO: Se há uma sessão pausada, calcular o tempo já estudado nela
        const inicioDataStr = sessaoIniciadaIso.split('T')[0];
        
        if (inicioDataStr === hojeStr) {
          // Calcular baseado no progresso do temporizador
          const segundosEstudados = tempoTotal - tempoRestante;
          minutosEmAndamento = Math.floor(segundosEstudados / 60);
          console.log(`Sessão pausada (hoje): ${minutosEmAndamento} min`);
        }
      } else {
        console.log('Não há sessão em andamento ou pausada');
      }

      // CORRIGIDO: Garantir que o resultado final seja um número inteiro
      const totalMinutos = Math.round(minutosSessoesSalvas + minutosEmAndamento);
      console.log(`TOTAL: ${minutosSessoesSalvas} (salvas) + ${minutosEmAndamento} (em andamento) = ${totalMinutos} min`);
      console.log('=== FIM CÁLCULO ===');
      
      return totalMinutos;
    } catch (error) {
      console.error('Erro ao calcular tempo estudado:', error);
      return 0;
    }
  }, [sessoes, isAtivo, sessaoIniciadaIso, tempoTotal, tempoRestante]);
  
  // Atualizar tempo personalizado
  const atualizarTempoPersonalizado = useCallback((novoTempo) => {
    setTempoPersonalizado(novoTempo);
    if (!isAtivo && !sessaoIniciadaIso) {
      const novoTempoSegundos = novoTempo * 60;
      setTempoRestante(novoTempoSegundos);
      setTempoTotal(novoTempoSegundos);
    }
  }, [isAtivo, sessaoIniciadaIso]);

  // Formatar tempo para exibição
  const formatarTempo = useCallback((segundos) => {
    const min = Math.floor(segundos / 60).toString().padStart(2, "0");
    const seg = (segundos % 60).toString().padStart(2, "0");
    return `${min}:${seg}`;
  }, []);

  // Valor do contexto
  const value = useMemo(() => ({
    tempoRestante,
    tempoTotal,
    isAtivo,
    setIsAtivo,
    iniciarPausar,
    resetar,
    formatarTempo,
    calcularTempoEstudadoHoje,
    tempoPersonalizado,
    atualizarTempoPersonalizado,
    volumeMusica,
    setVolumeMusica,
    selectedMusicId,
    setSelectedMusicId,
    selectedMusicTitle, // ADICIONADO
    setSelectedMusicTitle, // ADICIONADO
    configuracoesCarregadas,
    sessoes,
    sessaoIniciadaIso,
    setSessaoIniciadaIso,
    salvarSessaoAtual,
    audioRef
  }), [
    tempoRestante, tempoTotal, isAtivo,
    iniciarPausar, resetar, formatarTempo,
    calcularTempoEstudadoHoje,
    tempoPersonalizado, atualizarTempoPersonalizado,
    volumeMusica, selectedMusicId, selectedMusicTitle, // ADICIONADO selectedMusicTitle
    configuracoesCarregadas,
    sessoes, sessaoIniciadaIso, salvarSessaoAtual
  ]);

  return <TimerContext.Provider value={value}>{children}</TimerContext.Provider>;
}

export function useTimer() {
  const ctx = useContext(TimerContext);
  if (!ctx) throw new Error("useTimer deve ser usado dentro de TimerProvider");
  return ctx;
}
