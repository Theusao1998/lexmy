import React from "react";

export default function LexmyLogo({ className = "w-32 h-auto" }) {
  return (
    <img
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/689cc9827607abbfa2b6e9c0/7a76d99c4_lexmy.png"
      alt="Lexmy - Estudos para Concursos Jurídicos"
      className={`${className} object-contain`}
      draggable="false"
    />
  );
}