import React from 'react';
import { Button } from '@/components/ui/button';
import { Edit } from 'lucide-react';

export default function HighlightToolbar({ state, onAction }) {
    if (!state) return null;

    const colors = ['yellow', 'green', 'blue', 'pink'];

    return (
        <div
            className="highlight-toolbar absolute z-10 flex items-center gap-1 bg-slate-800 p-1.5 rounded-lg shadow-lg transform -translate-x-1/2"
            style={{
                top: `${state.top}px`,
                left: `${state.left}px`,
            }}
        >
            {colors.map(color => (
                <button
                    key={color}
                    onClick={() => onAction('highlight', color)}
                    className="h-7 w-7 rounded-md border-2 border-transparent hover:border-blue-400 transition-all"
                    style={{ backgroundColor: { yellow: '#fef9c3', green: '#dcfce7', blue: '#dbeafe', pink: '#fce7f3' }[color] }}
                    aria-label={`Marcar com ${color}`}
                />
            ))}
            <div className="w-px h-5 bg-slate-600 mx-1"></div>
            <Button
                size="sm"
                variant="ghost"
                onClick={() => onAction('note')}
                className="text-white hover:bg-slate-700 hover:text-white gap-1.5 h-7 px-2"
            >
                <Edit className="w-4 h-4" />
                <span className="text-xs">Nota</span>
            </Button>
        </div>
    );
}