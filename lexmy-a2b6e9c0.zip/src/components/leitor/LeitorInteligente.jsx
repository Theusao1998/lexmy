
import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import { Anotacao } from '@/api/entities';
import { Marcacao } from '@/api/entities';
import { Material } from '@/api/entities'; // Importa a entidade Material
import HighlightToolbar from './HighlightToolbar';
import SumarioLateral from './SumarioLateral'; // Importa o novo componente
import { Loader2, ArrowLeft, X } from 'lucide-react'; // X adicionado para o botão de fechar modal
import { toast } from "sonner";
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog'; // Componentes para o novo modal

const applyInteractions = (text, interactions) => {
    if (!interactions || interactions.length === 0 || !text) {
        return text;
    }

    let result = text;
    // Sort interactions by length of selected text in descending order
    // This ensures that longer selections are processed before shorter ones that might be substrings
    [...interactions]
        .sort((a, b) => (b.texto_selecionado?.length || 0) - (a.texto_selecionado?.length || 0))
        .forEach(interaction => {
            if (!interaction.texto_selecionado) return;
            
            // Escape special characters in the selection for use in regex
            const escapedSelection = interaction.texto_selecionado.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            // Use 'gi' for global and case-insensitive replacement if desired, or just 'g'
            const regex = new RegExp(escapedSelection, 'g'); 
            
            // Only replace if the text contains the selection to avoid unnecessary processing
            if (!result.includes(interaction.texto_selecionado)) {
                return;
            }

            if (interaction.interaction_type === 'marcacao' && interaction.cor) {
                // Replace selected text with a highlighted span
                result = result.replace(regex, `<mark class="highlight-${interaction.cor}">${interaction.texto_selecionado}</mark>`);
            } else if (interaction.interaction_type === 'anotacao' && interaction.texto_anotacao) {
                // Replace selected text with an annotated span including a tooltip
                result = result.replace(regex, `<span class="annotated-text">${interaction.texto_selecionado}<span class="annotation-tooltip">${interaction.texto_anotacao}</span></span>`);
            }
        });

    return result;
};

// NOVO: Função para processar conteúdo com marcações especiais
const processContent = (content) => {
    if (!content) return content;

    let processed = content;

    // Processar títulos hierárquicos - Estes são tratados no parser, mas podem aparecer dentro de artigos se não estiverem em suas próprias linhas
    processed = processed.replace(/\[NIVEL 1\](.*?)\[\/NIVEL 1\]/g, '<h1 class="nivel-1-titulo">$1</h1>');
    processed = processed.replace(/\[NIVEL 2\](.*?)\[\/NIVEL 2\]/g, '<h2 class="nivel-2-titulo">$1</h2>');
    processed = processed = processed.replace(/\[NIVEL 3\](.*?)\[\/NIVEL 3\]/g, '<h3 class="nivel-3-titulo">$1</h3>');

    // Processar blocos estilizados. Usar 'gs' para global e dotAll para que '.' também case novas linhas.
    processed = processed.replace(/\[COMENTARIO\](.*?)\[\/COMENTARIO\]/gs, '<div class="bloco-comentario"><div class="bloco-header">💬 Comentário</div><div class="bloco-content">$1</div></div>');
    processed = processed.replace(/\[JURISPRUDENCIA\](.*?)\[\/JURISPRUDENCIA\]/gs, '<div class="bloco-jurisprudencia"><div class="bloco-header">⚖️ Jurisprudência</div><div class="bloco-content">$1</div></div>');
    processed = processed.replace(/\[EXEMPLO\](.*?)\[\/EXEMPLO\]/gs, '<div class="bloco-exemplo"><div class="bloco-header">💡 Exemplo</div><div class="bloco-content">$1</div></div>');

    // Processar links para resumos
    processed = processed.replace(/\[LINK:(.*?)\]/g, '<button class="link-resumo" data-resumo-id="$1">📖 Ver Resumo</button>');

    // ADICIONADO: Processar negrito com Markdown
    processed = processed.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    return processed;
};

// Helper component for rendering structured legal content
const Node = ({ node, interactions, onResumoClick }) => { // onResumoClick adicionado
    // Filter interactions relevant to this specific node using its ID
    const relevantInteractions = useMemo(() => {
        return interactions.filter(i => i.node_id === node.id);
    }, [interactions, node.id]);

    // ATUALIZADO: Para títulos hierárquicos
    if (node.type === 'nivel-1') {
        return (
            <h1 
                id={node.id} 
                data-node-id={node.id} 
                className="text-3xl font-extrabold text-blue-900 mt-12 mb-8 border-b-3 border-blue-300 pb-4"
            >
                {node.text}
            </h1>
        );
    }

    if (node.type === 'nivel-2') {
        return (
            <h2 
                id={node.id} 
                data-node-id={node.id} 
                className="text-2xl font-bold text-blue-800 mt-10 mb-6 border-b-2 border-blue-200 pb-3"
            >
                {node.text}
            </h2>
        );
    }

    if (node.type === 'nivel-3') {
        return (
            <h3 
                id={node.id} 
                data-node-id={node.id} 
                className="text-xl font-bold text-blue-700 mt-8 mb-4 border-b border-blue-100 pb-2"
            >
                {node.text}
            </h3>
        );
    }

    if (node.type === 'heading') {
        return (
            <h3 
                id={node.id} 
                data-node-id={node.id} 
                className="text-2xl font-extrabold text-blue-800 mt-8 mb-6 border-b-2 border-blue-200 pb-3"
            >
                {node.text}
            </h3>
        );
    }

    if (node.type === 'article') {
        // Primeiro aplica as interações (marcações, anotações), depois processa os blocos especiais e links
        const processedHtml = processContent(applyInteractions(node.html, relevantInteractions));

        return (
            <div id={node.id} data-node-id={node.id} className="my-4 node-container">
                <div
                    className="prose max-w-none font-sans text-base leading-relaxed text-slate-800"
                    dangerouslySetInnerHTML={{ __html: processedHtml }}
                    // Adiciona handler de clique para links de resumo
                    onClick={(e) => {
                        if (e.target.classList.contains('link-resumo')) {
                            const resumoId = e.target.getAttribute('data-resumo-id');
                            if (resumoId) {
                                onResumoClick(resumoId);
                            }
                        }
                    }}
                />
            </div>
        );
    }
    
    return null; // Fallback for unrecognized node types
};


export default function LeitorInteligente({ material, onClose }) {
    const [interactions, setInteractions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [toolbarState, setToolbarState] = useState(null);
    const contentRef = useRef(null);
    const scrollableContainerRef = useRef(null); // Ref para o container de rolagem
    const [noteContent, setNoteContent] = useState('');
    const [showNoteModal, setShowNoteModal] = useState(false);

    // NOVO: Estados para modal de resumo
    const [showResumoModal, setShowResumoModal] = useState(false);
    const [resumoSelecionado, setResumoSelecionado] = useState(null);
    const [loadingResumo, setLoadingResumo] = useState(false);

    const loadInteractions = useCallback(async () => {
        setLoading(true);
        try {
            const [marcacoesData, anotacoesData] = await Promise.all([
                Marcacao.filter({ material_id: material.id }),
                Anotacao.filter({ material_id: material.id }),
            ]);
            // Type the interactions for unified handling, and include node_id if available
            const typedMarcacoes = marcacoesData.map(m => ({ ...m, interaction_type: 'marcacao', node_id: m.node_id || null }));
            const typedAnotacoes = anotacoesData.map(a => ({ ...a, interaction_type: 'anotacao', node_id: a.node_id || null }));
            setInteractions([...typedMarcacoes, ...typedAnotacoes]);
        } catch (error) {
            toast.error("Erro ao carregar marcações e notas.");
            console.error(error);
        } finally {
            setLoading(false);
        }
    }, [material.id]);

    useEffect(() => {
        loadInteractions();
    }, [loadInteractions]);

    // NOVO: Função para lidar com clique em links de resumo
    const handleResumoClick = async (resumoId) => {
        setLoadingResumo(true);
        setResumoSelecionado(null); // Limpa o resumo anterior
        setShowResumoModal(true);
        try {
            const resumo = await Material.filter({ id: resumoId }); // Assumindo que Material.filter pode buscar por ID
            if (resumo && resumo.length > 0) {
                setResumoSelecionado(resumo[0]);
            } else {
                toast.error("Resumo não encontrado.");
                setShowResumoModal(false);
            }
        } catch (error) {
            toast.error("Erro ao carregar resumo.");
            console.error(error);
            setShowResumoModal(false);
        } finally {
            setLoadingResumo(false);
        }
    };

    const handleMouseUp = (e) => {
        // Prevent toolbar from closing if clicking inside toolbar or note modal
        if (e.target.closest('.highlight-toolbar') || e.target.closest('.note-modal')) {
            return;
        }

        const selection = window.getSelection();
        // Check if there's a selection and it's within the content area
        if (selection && !selection.isCollapsed && contentRef.current?.contains(selection.anchorNode)) {
            const range = selection.getRangeAt(0);
            const containerRect = scrollableContainerRef.current.getBoundingClientRect(); // Usa o container de rolagem
            const rangeRect = range.getBoundingClientRect();
            
            // CORREÇÃO: Calcula o 'top' usando o scrollTop do container de rolagem
            const scrollTop = scrollableContainerRef.current.scrollTop;
            
            // Find the closest ancestor with a data-node-id to associate the interaction
            const commonAncestor = range.commonAncestorContainer;
            const closestNodeContainer = commonAncestor.nodeType === Node.ELEMENT_NODE 
                ? commonAncestor.closest('[data-node-id]') 
                : commonAncestor.parentElement?.closest('[data-node-id]');
            const nodeId = closestNodeContainer ? closestNodeContainer.dataset.nodeId : null;
            
            // Calculate toolbar position relative to the contentRef
            setToolbarState({
                top: rangeRect.top - containerRect.top + scrollTop - 45, // Adjust for toolbar height
                left: rangeRect.left - containerRect.left + (rangeRect.width / 2),
                text: selection.toString(),
                nodeId: nodeId, // Store the determined node ID
            });
        } else {
            // Clear toolbar if no selection or selection outside content area
            setToolbarState(null);
        }
    };
    
    const handleAction = async (action, value) => {
        if (!toolbarState) return;

        const { text, nodeId } = toolbarState; // Destructure text and nodeId from toolbarState

        if (action === 'highlight') {
            const optimisticId = `optimistic_${Date.now()}`;
            const newMarcacao = {
                id: optimisticId,
                material_id: material.id,
                texto_selecionado: text,
                cor: value,
                interaction_type: 'marcacao',
                node_id: nodeId, // Include node_id
            };

            // Atualização otimista do estado
            setInteractions(prev => [...prev, newMarcacao]);
            setToolbarState(null);
            
            try {
                // Salva no banco de dados em segundo plano
                const createdMarcacao = await Marcacao.create({
                    material_id: material.id,
                    texto_selecionado: text,
                    cor: value,
                    tipo: 'grifo', // 'grifo' means highlight
                    node_id: nodeId, // Pass node_id to the persistence layer
                });
                // Substitui a marcação otimista pela real com o ID do banco
                setInteractions(prev => prev.map(i => (i.id === optimisticId ? { ...createdMarcacao, interaction_type: 'marcacao', node_id: createdMarcacao.node_id } : i)));
                toast.success(`Texto destacado em ${value}.`);
            } catch (err) {
                toast.error("Falha ao salvar marcação. O destaque foi removido.");
                // Reverte a atualização otimista em caso de erro
                setInteractions(prev => prev.filter(i => i.id !== optimisticId));
                console.error("Erro ao salvar marcação:", err);
            }
        } else if (action === 'note') {
            setShowNoteModal(true);
            return; // Don't hide toolbar immediately, wait for modal interaction
        }
    };

    const handleSaveNote = async () => {
        if (!noteContent.trim() || !toolbarState) return;

        const { text, nodeId } = toolbarState; // Destructure text and nodeId from toolbarState

        const optimisticId = `optimistic_${Date.now()}`;
        const newAnotacao = {
            id: optimisticId,
            material_id: material.id,
            texto_selecionado: text,
            texto_anotacao: noteContent,
            interaction_type: 'anotacao',
            node_id: nodeId, // Include node_id
        };

        // Atualização otimista e fechamento do modal
        setInteractions(prev => [...prev, newAnotacao]);
        setShowNoteModal(false);
        setNoteContent('');
        setToolbarState(null);

        try {
            // Salva no banco de dados em segundo plano
            const createdAnotacao = await Anotacao.create({
                material_id: material.id,
                texto_selecionado: text,
                texto_anotacao: noteContent,
                node_id: nodeId, // Pass node_id to the persistence layer
            });
            // Substitui a anotação otimista pela real com o ID do banco
            setInteractions(prev => prev.map(i => (i.id === optimisticId ? { ...createdAnotacao, interaction_type: 'anotacao', node_id: createdAnotacao.node_id } : i)));
            toast.success("Anotação salva!");
        } catch (err) {
            toast.error("Falha ao salvar anotação. A nota foi removida.");
            // Reverte a atualização otimista em caso de erro
            setInteractions(prev => prev.filter(i => i.id !== optimisticId));
            console.error("Erro ao salvar anotação:", err);
        }
    };
    
    // ATUALIZADO: Parsear conteúdo com verificações de segurança
    const parsedContent = useMemo(() => {
        if (!material?.conteudo_puro) return { nodes: [], headings: [] };

        const lines = material.conteudo_puro.split('\n');
        const nodes = [];
        const headings = [];
        let currentArticleHtml = '';
        let articleCounter = 0;

        const closeArticle = () => {
            if (currentArticleHtml.trim()) {
                const articleId = `article-${material.id}-${articleCounter++}`;
                nodes.push({ type: 'article', html: currentArticleHtml, id: articleId });
                currentArticleHtml = '';
            }
        };

        lines.forEach((line, index) => {
            // CORRIGIDO: Verificar se line existe antes de chamar trim()
            // material.conteudo_puro.split('\n') garante que 'line' é uma string,
            // mas pode ser null/undefined se 'conteudo_puro' não for uma string.
            // O check `!material?.conteudo_puro` acima já previne a maioria desses casos.
            // Para segurança extra caso 'line' seja um valor falsy que não seja '',
            // usamos um fallback para string vazia.
            const safeLine = line || ''; 
            const trimmedLine = safeLine.trim();
            
            // CORRIGIDO: Não processar linhas completamente vazias para títulos ou artigos
            if (!trimmedLine) {
                return;
            }
            
            // Verificar títulos hierárquicos com verificações de segurança
            let nivel1Match, nivel2Match, nivel3Match;
            
            // Usar um bloco try-catch para capturar erros inesperados no regex
            try {
                nivel1Match = trimmedLine.match(/\[NIVEL 1\](.*?)\[\/NIVEL 1\]/);
                nivel2Match = trimmedLine.match(/\[NIVEL 2\](.*?)\[\/NIVEL 2\]/);
                nivel3Match = trimmedLine.match(/\[NIVEL 3\](.*?)\[\/NIVEL 3\]/);
            } catch (error) {
                console.error('Erro ao processar linha no parsing:', error, 'Linha:', trimmedLine);
                return; // Pular esta linha problemática
            }

            if (nivel1Match || nivel2Match || nivel3Match) {
                closeArticle(); // Fecha qualquer artigo pendente antes de um novo título
                let type, text, headingId, level;
                
                if (nivel1Match) {
                    type = 'nivel-1';
                    text = nivel1Match[1] ? nivel1Match[1].trim() : ''; // Acessar [1] com segurança
                    headingId = `nivel1-${material.id}-${index}`;
                    level = 1;
                } else if (nivel2Match) {
                    type = 'nivel-2';
                    text = nivel2Match[1] ? nivel2Match[1].trim() : ''; // Acessar [1] com segurança
                    headingId = `nivel2-${material.id}-${index}`;
                    level = 2;
                } else { // nivel3Match
                    type = 'nivel-3';
                    text = nivel3Match[1] ? nivel3Match[1].trim() : ''; // Acessar [1] com segurança
                    headingId = `nivel3-${material.id}-${index}`;
                    level = 3;
                }
                
                if (text) { // Só adicionar se tiver texto extraído
                    headings.push({ 
                        id: headingId, 
                        text: text, 
                        level: level
                    });
                    nodes.push({ type: type, text: text, id: headingId });
                }
            }
            // Fallback para títulos antigos (apenas maiúsculas) com verificações de segurança
            else if (trimmedLine.length > 1 && trimmedLine === trimmedLine.toUpperCase()) {
                closeArticle(); // Fecha qualquer artigo pendente antes de um novo título
                const headingId = `heading-${material.id}-${index}`; // Unique ID for heading
                headings.push({ id: headingId, text: trimmedLine, level: 1 }); // Assume level 1 para títulos antigos
                nodes.push({ type: 'heading', text: trimmedLine, id: headingId });
            } else if (trimmedLine) { // If it's not a heading and not empty, it's part of an article
                // CORRIGIDO: Usar 'safeLine' para garantir que não é null/undefined
                currentArticleHtml += `<p>${safeLine}</p>`;
            }
        });

        closeArticle(); // Close the last article if there's any pending content

        return { nodes, headings };
    }, [material?.conteudo_puro, material?.id]);
    
    
    // Scroll to a specific heading when a TOC item is clicked
    const handleTocClick = (id) => {
        const element = document.getElementById(id);
        if (element && scrollableContainerRef.current) {
            // Calculate position relative to the scrollable container
            const elementRect = element.getBoundingClientRect();
            const containerRect = scrollableContainerRef.current.getBoundingClientRect();
            const offset = elementRect.top - containerRect.top + scrollableContainerRef.current.scrollTop;
            
            scrollableContainerRef.current.scrollTo({ top: offset, behavior: 'smooth' });
        }
    };


    return (
        <div className="flex flex-col h-screen overflow-hidden p-4 md:p-8">
             {/* Global styles for highlights, annotations and special blocks */}
             <style jsx global>{`
                .highlight-yellow { background-color: #fef9c3; color: #713f12; }
                .highlight-green { background-color: #dcfce7; color: #166534; }
                .highlight-blue { background-color: #dbeafe; color: #1e40af; }
                .highlight-pink { background-color: #fce7f3; color: #831843; }
                .annotated-text {
                    border-bottom: 2px dotted #fbbf24;
                    cursor: help;
                    position: relative;
                }
                .annotation-tooltip {
                    visibility: hidden;
                    width: 250px;
                    background-color: #1f2937;
                    color: #fff;
                    text-align: left;
                    border-radius: 6px;
                    padding: 8px;
                    position: absolute;
                    z-index: 10;
                    bottom: 125%;
                    left: 50%;
                    margin-left: -125px;
                    opacity: 0;
                    transition: opacity 0.3s;
                    font-size: 0.8rem;
                    line-height: 1.4;
                    pointer-events: none;
                    white-space: normal;
                }
                .annotation-tooltip::after {
                    content: "";
                    position: absolute;
                    top: 100%;
                    left: 50%;
                    margin-left: -5px;
                    border-width: 5px;
                    border-style: solid;
                    border-color: #1f2937 transparent transparent transparent;
                }
                .annotated-text:hover .annotation-tooltip {
                    visibility: visible;
                    opacity: 1;
                }

                /* Estilos para blocos especiais */
                .bloco-comentario {
                    background-color: #eff6ff;
                    border-left: 4px solid #3b82f6;
                    border-radius: 8px;
                    margin: 16px 0;
                    overflow: hidden;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }
                .bloco-jurisprudencia {
                    background-color: #f0fdf4;
                    border-left: 4px solid #22c55e;
                    border-radius: 8px;
                    margin: 16px 0;
                    overflow: hidden;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }
                .bloco-exemplo {
                    background-color: #fffbeb;
                    border-left: 4px solid #f59e0b;
                    border-radius: 8px;
                    margin: 16px 0;
                    overflow: hidden;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
                }
                .bloco-header {
                    background-color: rgba(255,255,255,0.6);
                    padding: 8px 16px;
                    font-weight: 600;
                    font-size: 0.875rem;
                    border-bottom: 1px solid rgba(0,0,0,0.1);
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                .bloco-content {
                    padding: 16px;
                    line-height: 1.6;
                }
                .link-resumo {
                    display: inline-flex;
                    align-items: center;
                    gap: 4px;
                    background-color: #dbeafe;
                    color: #1e40af;
                    padding: 4px 8px;
                    border-radius: 6px;
                    border: 1px solid #93c5fd;
                    font-size: 0.875rem;
                    cursor: pointer;
                    transition: all 0.2s;
                    text-decoration: none; /* Remove underline */
                }
                .link-resumo:hover {
                    background-color: #bfdbfe;
                    border-color: #60a5fa;
                    transform: translateY(-1px);
                }
            `}</style>

            <div className="flex-shrink-0 max-w-7xl mx-auto w-full"> {/* Added w-full for centering */}
                <Button onClick={onClose} variant="outline" className="mb-6 gap-2">
                    <ArrowLeft className="w-4 h-4" />
                    Voltar para a Biblioteca
                </Button>
            </div>
                
            <div className="flex-1 flex gap-8 overflow-hidden max-w-7xl mx-auto w-full"> {/* Added w-full for centering */}
                {/* Sumário Lateral - Fixed width, not scrollable itself */}
                <SumarioLateral headings={parsedContent.headings} onHeadingClick={handleTocClick} />

                {/* Conteúdo Principal - Scrolls independently */}
                <div ref={scrollableContainerRef} className="relative flex-1 overflow-y-auto pr-4">
                    <header className="mb-8">
                        <h1 className="text-3xl font-bold text-slate-800">{material.titulo}</h1>
                        <p className="text-slate-500">{material.descricao}</p>
                    </header>
                    <main 
                        ref={contentRef} 
                        onMouseUp={handleMouseUp} 
                        className="prose prose-slate max-w-none"
                    >
                        {loading ? (
                            <div className="text-center py-12">
                                <Loader2 className="mx-auto h-8 w-8 animate-spin text-blue-600" />
                                <p className="mt-2 text-slate-500">Carregando conteúdo...</p>
                            </div>
                        ) : (
                            parsedContent.nodes.length > 0 ? (
                                parsedContent.nodes.map((node) => (
                                    <Node 
                                        key={node.id} 
                                        node={node} 
                                        interactions={interactions} 
                                        onResumoClick={handleResumoClick} // Passa a função para o Node
                                    />
                                ))
                            ) : (
                                <p className="text-center py-12 text-slate-500">Nenhum conteúdo disponível para este material.</p>
                            )
                        )}
                    </main>

                    {toolbarState && (
                        <HighlightToolbar state={toolbarState} onAction={handleAction} />
                    )}
                </div>
            </div>

            {/* Modal de anotação existente */}
            {showNoteModal && (
                <div className="note-modal fixed inset-0 bg-black/30 flex items-center justify-center z-50">
                    <div className="bg-white p-6 rounded-lg shadow-xl w-full max-w-md">
                        <h3 className="text-lg font-semibold mb-2">Adicionar Anotação</h3>
                        <blockquote className="text-sm text-slate-600 bg-slate-100 p-3 rounded-md mb-4 border-l-4 border-slate-300">
                           {toolbarState?.text}
                        </blockquote>
                        <Textarea 
                            value={noteContent}
                            onChange={(e) => setNoteContent(e.target.value)}
                            placeholder="Escreva sua anotação aqui..."
                            className="min-h-[120px]"
                            autoFocus
                        />
                        <div className="flex justify-end gap-2 mt-4">
                            <Button variant="outline" onClick={() => { setShowNoteModal(false); setToolbarState(null); setNoteContent(''); }}>Cancelar</Button>
                            <Button onClick={handleSaveNote}>Salvar Nota</Button>
                        </div>
                    </div>
                </div>
            )}

            {/* NOVO: Modal para exibir resumo */}
            <Dialog open={showResumoModal} onOpenChange={setShowResumoModal}>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                    <DialogHeader>
                        <DialogTitle className="flex items-center justify-between">
                            {loadingResumo ? 'Carregando...' : resumoSelecionado?.titulo || 'Resumo'}
                            <Button variant="ghost" size="sm" onClick={() => setShowResumoModal(false)}>
                                <X className="w-4 h-4" />
                            </Button>
                        </DialogTitle>
                    </DialogHeader>
                    
                    {loadingResumo ? (
                        <div className="flex items-center justify-center py-8">
                            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
                        </div>
                    ) : resumoSelecionado ? (
                        <div className="space-y-4">
                            {resumoSelecionado.descricao && (
                                <p className="text-slate-600">{resumoSelecionado.descricao}</p>
                            )}
                            <div 
                                className="prose prose-slate max-w-none"
                                dangerouslySetInnerHTML={{ 
                                    __html: processContent(resumoSelecionado.conteudo_puro || '') 
                                }}
                            />
                        </div>
                    ) : (
                        <p className="text-slate-500">Resumo não encontrado ou não disponível.</p>
                    )}
                </DialogContent>
            </Dialog>
        </div>
    );
}
