import React from 'react';
import { List } from 'lucide-react';

export default function SumarioLateral({ headings, onHeadingClick }) {
  if (!headings || headings.length === 0) {
    return (
      <aside className="w-64 flex-shrink-0 p-4 bg-slate-50 rounded-lg border border-slate-200">
        <h3 className="font-semibold text-lg mb-4 text-slate-800 flex items-center gap-2">
          <List className="w-5 h-5" />
          Sumário
        </h3>
        <p className="text-sm text-slate-500">Nenhum título encontrado neste material.</p>
      </aside>
    );
  }

  return (
    <aside className="w-64 flex-shrink-0 bg-slate-50/70 backdrop-blur-sm rounded-lg border border-slate-200 flex flex-col max-h-[calc(100vh-8rem)]">
      <div className="p-4 flex-shrink-0">
        <h3 className="font-semibold text-lg text-slate-800 flex items-center gap-2">
          <List className="w-5 h-5" />
          Sumário
        </h3>
      </div>
      <div className="overflow-y-auto px-4 pb-4">
        <ul className="space-y-2">
          {headings.map((heading) => (
            <li key={heading.id}>
              <button
                onClick={() => onHeadingClick(heading.id)}
                className={`text-left text-sm text-slate-600 hover:text-blue-600 hover:font-medium transition-all duration-150 w-full p-1 rounded-md ${
                  heading.level === 1 ? 'font-semibold text-slate-800' : 
                  heading.level === 2 ? 'font-medium' : ''
                }`}
              >
                {heading.text}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
}