
import React, { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Clock, Trash2, CheckCircle2, Check, Pencil } from "lucide-react";

export default function BlocoRotinaCard({ bloco, editais, onDelete, onConcluir, onEdit }) {
  // Verificar se o tópico vinculado já foi concluído
  const topicoConcluido = useMemo(() => {
    if (!bloco.topico_edital_ref || !editais || editais.length === 0) {
      return false;
    }

    const { edital_id, disciplina_nome, topico_titulo } = bloco.topico_edital_ref;
    
    // Encontrar o edital correspondente
    const edital = editais.find(e => e.id === edital_id);
    if (!edital || !edital.disciplinas) return false;

    // Encontrar a disciplina
    const disciplina = edital.disciplinas.find(d => d.nome === disciplina_nome);
    if (!disciplina || !disciplina.topicos) return false;

    // Encontrar o tópico
    const topico = disciplina.topicos.find(t => t.titulo === topico_titulo);
    if (!topico) return false;

    // Verificar conclusão baseado no tipo de atividade
    if (bloco.tipo_atividade === 'revisao' && bloco.revisao_tipo) {
      // Para revisões, verificar o campo específico de revisão
      const campoRevisao = `revisao_${bloco.revisao_tipo}_em`;
      return !!topico[campoRevisao];
    } else if (bloco.tipo_atividade === 'estudo' || bloco.tipo_atividade === 'exercicios') {
      // Para estudo/exercícios, verificar estudado_em
      return !!topico.estudado_em;
    }
    
    return false;
  }, [bloco, editais]);

  const temVinculoEdital = bloco.topico_edital_ref && 
                           bloco.topico_edital_ref.edital_id && 
                           bloco.topico_edital_ref.disciplina_nome && 
                           bloco.topico_edital_ref.topico_titulo;

  // Determinar o label do badge de tipo de revisão
  const labelRevisao = bloco.tipo_atividade === 'revisao' && bloco.revisao_tipo 
    ? `Revisão ${bloco.revisao_tipo.replace('d', ' dia(s)')}`
    : null;

  return (
    <Card className={`backdrop-blur-sm border-0 shadow-md hover:shadow-lg transition-all duration-300 ${
      topicoConcluido ? 'bg-green-50/80 border-l-4 border-green-500' : 'bg-white/80'
    }`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h4 className={`font-medium truncate ${topicoConcluido ? 'text-green-800 line-through' : 'text-slate-800'}`}>
                {bloco.atividade}
              </h4>
              {labelRevisao && (
                <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full whitespace-nowrap">
                  {labelRevisao}
                </span>
              )}
            </div>
            <p className="text-sm text-slate-600 flex items-center gap-1 mt-1">
              <Clock className="w-3 h-3" />
              {bloco.horario_inicio} - {bloco.horario_fim}
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            {temVinculoEdital && (
              topicoConcluido ? (
                <div className="flex items-center gap-2 px-3 py-1.5 bg-green-100 text-green-700 rounded-lg border border-green-200">
                  <Check className="w-4 h-4" />
                  <span className="text-sm font-medium">Concluido</span>
                </div>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 gap-2 hover:bg-green-50 hover:text-green-600 hover:border-green-200"
                  onClick={() => onConcluir(bloco)}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  Concluir
                </Button>
              )
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 hover:bg-blue-50 hover:text-blue-600"
              onClick={() => onEdit(bloco)}
            >
              <Pencil className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 hover:bg-red-50 hover:text-red-600"
              onClick={() => onDelete(bloco.id)}
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
