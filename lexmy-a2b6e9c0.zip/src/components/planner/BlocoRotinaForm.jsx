import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

const diasSemanaOpcoes = [
  { value: "segunda", label: "Segunda-feira" },
  { value: "terca", label: "Terça-feira" },
  { value: "quarta", label: "Quarta-feira" },
  { value: "quinta", label: "Quinta-feira" },
  { value: "sexta", label: "Sexta-feira" },
  { value: "sabado", label: "Sábado" },
  { value: "domingo", label: "Domingo" }
];

const tiposAtividade = [
  { value: "estudo", label: "Estudo" },
  { value: "revisao", label: "Revisão" },
  { value: "exercicios", label: "Exercícios" },
  { value: "simulado", label: "Simulado" },
  { value: "lazer", label: "Lazer" },
  { value: "trabalho", label: "Trabalho" },
  { value: "refeicao", label: "Refeição" },
  { value: "sono", label: "Sono" },
  { value: "outro", label: "Outro" }
];

const coresDisponiveis = [
  { nome: "Azul", valor: "#3b82f6" },
  { nome: "Verde", valor: "#10b981" },
  { nome: "Vermelho", valor: "#ef4444" },
  { nome: "Amarelo", valor: "#f59e0b" },
  { nome: "Roxo", valor: "#8b5cf6" },
  { nome: "Rosa", valor: "#ec4899" },
  { nome: "Laranja", valor: "#f97316" },
  { nome: "Ciano", valor: "#06b6d4" },
];

export default function BlocoRotinaForm({ isOpen, onClose, onSubmit, bloco = null, diaSemanaInicial = "segunda" }) {
  const [form, setForm] = useState({
    dia_semana: bloco?.dia_semana || diaSemanaInicial,
    horario_inicio: bloco?.horario_inicio || "08:00",
    horario_fim: bloco?.horario_fim || "09:00",
    atividade: bloco?.atividade || "",
    disciplina: bloco?.disciplina || "",
    tipo_atividade: bloco?.tipo_atividade || "estudo",
    cor: bloco?.cor || "#3b82f6",
    ativo: bloco?.ativo ?? true,
    data_inicio_vigencia: bloco?.data_inicio_vigencia ? new Date(bloco.data_inicio_vigencia) : null,
    data_fim_vigencia: bloco?.data_fim_vigencia ? new Date(bloco.data_fim_vigencia) : null,
    recorrente: bloco?.recorrente ?? false,
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Validações básicas
    if (!form.atividade.trim()) {
      alert("Por favor, preencha o nome da atividade.");
      return;
    }

    const dadosBloco = {
      ...form,
      data_inicio_vigencia: form.data_inicio_vigencia ? format(form.data_inicio_vigencia, 'yyyy-MM-dd') : null,
      data_fim_vigencia: form.data_fim_vigencia ? format(form.data_fim_vigencia, 'yyyy-MM-dd') : null,
    };

    onSubmit(dadosBloco);
    onClose();
  };

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{bloco ? 'Editar Bloco de Rotina' : 'Novo Bloco de Rotina'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Dia da Semana */}
          <div className="grid gap-2">
            <Label>Dia da Semana</Label>
            <Select value={form.dia_semana} onValueChange={(value) => handleChange("dia_semana", value)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {diasSemanaOpcoes.map((dia) => (
                  <SelectItem key={dia.value} value={dia.value}>
                    {dia.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Horários */}
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="horario_inicio">Horário de Início</Label>
              <Input
                id="horario_inicio"
                type="time"
                value={form.horario_inicio}
                onChange={(e) => handleChange("horario_inicio", e.target.value)}
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="horario_fim">Horário de Fim</Label>
              <Input
                id="horario_fim"
                type="time"
                value={form.horario_fim}
                onChange={(e) => handleChange("horario_fim", e.target.value)}
                required
              />
            </div>
          </div>

          {/* Atividade */}
          <div className="grid gap-2">
            <Label htmlFor="atividade">Atividade</Label>
            <Textarea
              id="atividade"
              value={form.atividade}
              onChange={(e) => handleChange("atividade", e.target.value)}
              placeholder="Ex: Estudar Direito Constitucional - Princípios Fundamentais"
              className="h-20"
              required
            />
          </div>

          {/* Tipo de Atividade e Disciplina */}
          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Tipo de Atividade</Label>
              <Select value={form.tipo_atividade} onValueChange={(value) => handleChange("tipo_atividade", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {tiposAtividade.map((tipo) => (
                    <SelectItem key={tipo.value} value={tipo.value}>
                      {tipo.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label htmlFor="disciplina">Disciplina (opcional)</Label>
              <Input
                id="disciplina"
                value={form.disciplina}
                onChange={(e) => handleChange("disciplina", e.target.value)}
                placeholder="Ex: Direito Constitucional"
              />
            </div>
          </div>

          {/* Cor */}
          <div className="grid gap-2">
            <Label>Cor de Identificação</Label>
            <div className="grid grid-cols-4 gap-2">
              {coresDisponiveis.map((cor) => (
                <button
                  key={cor.valor}
                  type="button"
                  className={`w-full h-12 rounded-lg border-2 transition-all hover:scale-105 ${
                    form.cor === cor.valor ? 'border-slate-800 ring-2 ring-slate-400' : 'border-slate-200'
                  }`}
                  style={{ backgroundColor: cor.valor }}
                  onClick={() => handleChange("cor", cor.valor)}
                  title={cor.nome}
                />
              ))}
            </div>
          </div>

          {/* Vigência */}
          <div className="grid gap-2">
            <Label>Período de Vigência (opcional)</Label>
            <div className="grid grid-cols-2 gap-4">
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {form.data_inicio_vigencia ? format(form.data_inicio_vigencia, 'PPP', { locale: ptBR }) : "Data de início"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={form.data_inicio_vigencia}
                    onSelect={(date) => handleChange("data_inicio_vigencia", date)}
                    locale={ptBR}
                  />
                </PopoverContent>
              </Popover>

              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {form.data_fim_vigencia ? format(form.data_fim_vigencia, 'PPP', { locale: ptBR }) : "Data de fim"}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={form.data_fim_vigencia}
                    onSelect={(date) => handleChange("data_fim_vigencia", date)}
                    locale={ptBR}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Recorrente e Ativo */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="recorrente"
                checked={form.recorrente}
                onCheckedChange={(checked) => handleChange("recorrente", checked)}
              />
              <label
                htmlFor="recorrente"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Recorrente (toda semana)
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="ativo"
                checked={form.ativo}
                onCheckedChange={(checked) => handleChange("ativo", checked)}
              />
              <label
                htmlFor="ativo"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
              >
                Bloco ativo
              </label>
            </div>
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              {bloco ? 'Atualizar' : 'Criar'} Bloco
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}