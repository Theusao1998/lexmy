import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { LayoutGrid, Plus, RefreshCw } from "lucide-react";
import BlocoRotinaCard from "./BlocoRotinaCard";

const diasSemana = ["segunda", "terca", "quarta", "quinta", "sexta", "sabado", "domingo"];
const diasSemanaLabel = {
  "segunda": "Segunda",
  "terca": "Terça",
  "quarta": "Quarta",
  "quinta": "Quinta",
  "sexta": "Sexta",
  "sabado": "Sábado",
  "domingo": "Domingo"
};

export default function GradeRotinaSemanal({ blocos, onRefresh, onDelete }) {
  // Agrupar blocos por dia da semana
  const blocosPorDia = diasSemana.reduce((acc, dia) => {
    acc[dia] = blocos
      .filter(b => b.dia_semana === dia && b.ativo)
      .sort((a, b) => a.horario_inicio.localeCompare(b.horario_inicio));
    return acc;
  }, {});

  // Calcular total de horas de estudo por dia
  const calcularHorasEstudo = (blocosDia) => {
    return blocosDia
      .filter(b => ['estudo', 'revisao', 'exercicios', 'simulado'].includes(b.tipo_atividade))
      .reduce((total, bloco) => {
        const [h1, m1] = bloco.horario_inicio.split(':').map(Number);
        const [h2, m2] = bloco.horario_fim.split(':').map(Number);
        const minutos = (h2 * 60 + m2) - (h1 * 60 + m1);
        return total + minutos;
      }, 0);
  };

  return (
    <div className="space-y-6">
      {/* Resumo Semanal */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <LayoutGrid className="w-5 h-5 text-blue-600" />
              Resumo da Semana
            </CardTitle>
            <Button onClick={onRefresh} variant="outline" size="sm" className="gap-2">
              <RefreshCw className="w-4 h-4" />
              Atualizar
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <p className="text-2xl font-bold text-blue-700">
                {blocos.filter(b => b.ativo).length}
              </p>
              <p className="text-sm text-slate-600">Blocos de Atividade</p>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <p className="text-2xl font-bold text-green-700">
                {Math.round(
                  blocos
                    .filter(b => b.ativo && ['estudo', 'revisao', 'exercicios', 'simulado'].includes(b.tipo_atividade))
                    .reduce((total, bloco) => {
                      const [h1, m1] = bloco.horario_inicio.split(':').map(Number);
                      const [h2, m2] = bloco.horario_fim.split(':').map(Number);
                      return total + ((h2 * 60 + m2) - (h1 * 60 + m1));
                    }, 0) / 60
                )}h
              </p>
              <p className="text-sm text-slate-600">Estudo Semanal</p>
            </div>
            <div className="text-center p-4 bg-amber-50 rounded-lg">
              <p className="text-2xl font-bold text-amber-700">
                {new Set(blocos.filter(b => b.ativo && b.disciplina).map(b => b.disciplina)).size}
              </p>
              <p className="text-sm text-slate-600">Disciplinas</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <p className="text-2xl font-bold text-purple-700">
                {diasSemana.filter(dia => blocosPorDia[dia].length > 0).length}
              </p>
              <p className="text-sm text-slate-600">Dias Planejados</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Grade por Dia */}
      <div className="grid grid-cols-1 gap-6">
        {diasSemana.map(dia => {
          const blocosDia = blocosPorDia[dia];
          const horasEstudo = calcularHorasEstudo(blocosDia);
          
          return (
            <Card key={dia} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-lg">{diasSemanaLabel[dia]}</CardTitle>
                    <Badge variant="secondary" className="text-xs">
                      {blocosDia.length} atividades
                    </Badge>
                    {horasEstudo > 0 && (
                      <Badge className="bg-blue-100 text-blue-700 border-blue-200 text-xs">
                        {Math.round(horasEstudo / 60)}h de estudo
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {blocosDia.length === 0 ? (
                  <div className="text-center py-8 text-slate-500">
                    <p className="text-sm">Nenhuma atividade planejada para este dia</p>
                    <p className="text-xs mt-2">
                      Use o assistente para criar sua rotina
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {blocosDia.map(bloco => (
                      <BlocoRotinaCard 
                        key={bloco.id} 
                        bloco={bloco} 
                        onDelete={onDelete}
                      />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}