import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function MetaForm({ isOpen, onClose, onSubmit, meta = null }) {
  const [form, setForm] = useState({
    titulo: meta?.titulo || "",
    descricao: meta?.descricao || "",
    tipo: meta?.tipo || "semanal",
    disciplina: meta?.disciplina || "",
    valor_meta: meta?.valor_meta || "",
    unidade: meta?.unidade || "horas",
    data_limite: meta?.data_limite ? new Date(meta.data_limite) : null,
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...form,
      valor_meta: Number(form.valor_meta),
      data_limite: form.data_limite ? format(form.data_limite, 'yyyy-MM-dd') : null,
    });
    onClose();
  };

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{meta ? 'Editar Meta' : 'Nova Meta'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid gap-2">
            <Label htmlFor="titulo">Título</Label>
            <Input
              id="titulo"
              value={form.titulo}
              onChange={(e) => handleChange("titulo", e.target.value)}
              placeholder="Ex: Estudar 20 horas esta semana"
              required
            />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="descricao">Descrição (opcional)</Label>
            <Textarea
              id="descricao"
              value={form.descricao}
              onChange={(e) => handleChange("descricao", e.target.value)}
              placeholder="Descrição da meta..."
              className="h-20"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label>Tipo</Label>
              <Select value={form.tipo} onValueChange={(value) => handleChange("tipo", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="diaria">Diária</SelectItem>
                  <SelectItem value="semanal">Semanal</SelectItem>
                  <SelectItem value="mensal">Mensal</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-2">
              <Label>Unidade</Label>
              <Select value={form.unidade} onValueChange={(value) => handleChange("unidade", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="horas">Horas</SelectItem>
                  <SelectItem value="questoes">Questões</SelectItem>
                  <SelectItem value="materiais">Materiais</SelectItem>
                  <SelectItem value="revisoes">Revisões</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="grid gap-2">
              <Label htmlFor="valor_meta">Meta</Label>
              <Input
                id="valor_meta"
                type="number"
                min="1"
                value={form.valor_meta}
                onChange={(e) => handleChange("valor_meta", e.target.value)}
                placeholder="Ex: 20"
                required
              />
            </div>

            <div className="grid gap-2">
              <Label htmlFor="disciplina">Disciplina (opcional)</Label>
              <Input
                id="disciplina"
                value={form.disciplina}
                onChange={(e) => handleChange("disciplina", e.target.value)}
                placeholder="Ex: Direito Constitucional"
              />
            </div>
          </div>

          <div className="grid gap-2">
            <Label>Data Limite (opcional)</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="justify-start text-left font-normal">
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {form.data_limite ? format(form.data_limite, 'PPP', { locale: ptBR }) : "Selecionar data"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={form.data_limite}
                  onSelect={(date) => handleChange("data_limite", date)}
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button type="submit">
              {meta ? 'Atualizar' : 'Criar'} Meta
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}