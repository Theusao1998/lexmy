import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Sparkles, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function EmBreveCard({ 
  titulo = "Funcionalidade Em Breve",
  descricao = "Estamos trabalhando para trazer esta funcionalidade para você em breve!",
  icone: Icone = Sparkles
}) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8 flex items-center justify-center">
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl max-w-2xl w-full">
        <CardContent className="p-12 text-center space-y-6">
          <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-500 to-purple-600 rounded-3xl flex items-center justify-center shadow-lg">
            <Icone className="w-10 h-10 text-white" />
          </div>
          
          <div className="space-y-3">
            <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-800 to-purple-600 bg-clip-text text-transparent">
              {titulo}
            </h2>
            <p className="text-slate-600 text-lg">
              {descricao}
            </p>
          </div>

          <div className="pt-4">
            <Button
              onClick={() => navigate(createPageUrl("Dashboard"))}
              className="gap-2 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar ao Dashboard
            </Button>
          </div>

          <div className="pt-6 border-t border-slate-200">
            <p className="text-sm text-slate-500">
              💡 Enquanto isso, explore outras funcionalidades como <strong>Treinamento</strong>, <strong>Questões</strong> e <strong>Mapas Mentais</strong>!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}