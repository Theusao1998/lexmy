import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Plus, X, GripVertical } from "lucide-react";

export default function DisciplinaForm({ open, onOpenChange, disciplina = null, onSave }) {
  const [form, setForm] = useState({
    nome: "",
    peso: "",
    topicos: []
  });

  useEffect(() => {
    if (disciplina) {
      setForm({
        nome: disciplina.nome || "",
        peso: disciplina.peso ? String(disciplina.peso) : "",
        topicos: disciplina.topicos || []
      });
    } else {
      resetForm();
    }
  }, [disciplina, open]);

  const resetForm = () => {
    setForm({
      nome: "",
      peso: "",
      topicos: []
    });
  };

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleAdicionarTopico = () => {
    setForm(prev => ({
      ...prev,
      topicos: [...prev.topicos, { titulo: "" }]
    }));
  };

  const handleRemoverTopico = (index) => {
    setForm(prev => ({
      ...prev,
      topicos: prev.topicos.filter((_, i) => i !== index)
    }));
  };

  const handleTopicoChange = (index, value) => {
    setForm(prev => {
      const novosTopicos = [...prev.topicos];
      novosTopicos[index] = { ...novosTopicos[index], titulo: value };
      return { ...prev, topicos: novosTopicos };
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!form.nome.trim()) {
      alert('O nome da disciplina é obrigatório.');
      return;
    }

    // Filtrar tópicos vazios
    const topicosValidos = form.topicos.filter(t => t.titulo && t.titulo.trim());

    const dadosParaSalvar = {
      nome: form.nome.trim(),
      peso: form.peso ? parseFloat(form.peso) : null,
      topicos: topicosValidos
    };

    onSave(dadosParaSalvar);
    onOpenChange(false);
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { 
      onOpenChange(v); 
      if (!v) resetForm(); 
    }}>
      <DialogContent className="sm:max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{disciplina ? 'Editar Disciplina' : 'Nova Disciplina'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Informações Básicas */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="nome">Nome da Disciplina *</Label>
              <Input
                id="nome"
                value={form.nome}
                onChange={(e) => handleChange("nome", e.target.value)}
                placeholder="Ex: Direito Constitucional"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="peso">Peso (opcional)</Label>
              <Input
                id="peso"
                type="number"
                step="0.1"
                min="0"
                value={form.peso}
                onChange={(e) => handleChange("peso", e.target.value)}
                placeholder="Ex: 3"
              />
            </div>
          </div>

          {/* Tópicos */}
          <div className="space-y-3 border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <Label>Tópicos Programáticos</Label>
                <p className="text-xs text-slate-500 mt-1">
                  Adicione os tópicos que fazem parte desta disciplina
                </p>
              </div>
              <Button 
                type="button" 
                variant="outline" 
                size="sm" 
                onClick={handleAdicionarTopico}
                className="gap-2"
              >
                <Plus className="w-4 h-4" />
                Adicionar Tópico
              </Button>
            </div>

            {form.topicos.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-lg border-2 border-dashed border-slate-200">
                <p className="text-sm text-slate-600 mb-3">
                  Nenhum tópico adicionado ainda
                </p>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={handleAdicionarTopico}
                  className="gap-2"
                >
                  <Plus className="w-4 h-4" />
                  Adicionar Primeiro Tópico
                </Button>
              </div>
            ) : (
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {form.topicos.map((topico, index) => (
                  <Card key={index} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-3">
                      <div className="flex items-center gap-2">
                        <GripVertical className="w-4 h-4 text-slate-400 flex-shrink-0" />
                        <div className="flex-1">
                          <Input
                            value={topico.titulo || ""}
                            onChange={(e) => handleTopicoChange(index, e.target.value)}
                            placeholder={`Tópico ${index + 1}`}
                            className="bg-white"
                          />
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoverTopico(index)}
                          className="flex-shrink-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
            
            {form.topicos.length > 0 && (
              <p className="text-xs text-slate-500 text-right">
                {form.topicos.length} {form.topicos.length === 1 ? 'tópico adicionado' : 'tópicos adicionados'}
              </p>
            )}
          </div>

          {/* Botões */}
          <div className="flex justify-end gap-3 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                onOpenChange(false);
                resetForm();
              }}
            >
              Cancelar
            </Button>
            <Button type="submit">
              {disciplina ? 'Atualizar' : 'Criar'} Disciplina
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}