import React, { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, BookOpen, GripVertical } from "lucide-react";
import { Edital } from "@/api/entities";
import { toast } from "sonner";
import DisciplinaForm from "./DisciplinaForm";

export default function GerenciarDisciplinasDialog({ open, onOpenChange, edital, onSave }) {
  const [disciplinas, setDisciplinas] = useState([]);
  const [showDisciplinaForm, setShowDisciplinaForm] = useState(false);
  const [disciplinaEditando, setDisciplinaEditando] = useState(null);
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (edital && edital.disciplinas) {
      setDisciplinas([...edital.disciplinas]);
    }
  }, [edital]);

  const handleAdicionarDisciplina = () => {
    setDisciplinaEditando(null);
    setShowDisciplinaForm(true);
  };

  const handleEditarDisciplina = (disciplina, index) => {
    setDisciplinaEditando({ ...disciplina, index });
    setShowDisciplinaForm(true);
  };

  const handleSalvarDisciplina = (disciplinaData) => {
    if (disciplinaEditando && disciplinaEditando.index !== undefined) {
      // Editando disciplina existente
      const novasDisciplinas = [...disciplinas];
      novasDisciplinas[disciplinaEditando.index] = disciplinaData;
      setDisciplinas(novasDisciplinas);
      toast.success('Disciplina atualizada!');
    } else {
      // Adicionando nova disciplina
      setDisciplinas([...disciplinas, disciplinaData]);
      toast.success('Disciplina adicionada!');
    }
    setShowDisciplinaForm(false);
    setDisciplinaEditando(null);
  };

  const handleRemoverDisciplina = (index) => {
    if (!confirm('Tem certeza que deseja remover esta disciplina?')) {
      return;
    }
    const novasDisciplinas = disciplinas.filter((_, i) => i !== index);
    setDisciplinas(novasDisciplinas);
    toast.success('Disciplina removida!');
  };

  const handleSalvarTudo = async () => {
    setSalvando(true);
    try {
      await Edital.update(edital.id, {
        ...edital,
        disciplinas
      });
      toast.success('Disciplinas salvas com sucesso!');
      onSave();
      onOpenChange(false);
    } catch (error) {
      console.error('Erro ao salvar disciplinas:', error);
      toast.error('Erro ao salvar disciplinas.');
    } finally {
      setSalvando(false);
    }
  };

  const contarTopicos = (disciplina) => {
    return disciplina.topicos ? disciplina.topicos.length : 0;
  };

  return (
    <>
      <Dialog open={open && !showDisciplinaForm} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Gerenciar Disciplinas - {edital?.nome_concurso}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Botão Adicionar */}
            <div className="flex justify-between items-center">
              <p className="text-sm text-slate-600">
                {disciplinas.length} {disciplinas.length === 1 ? 'disciplina cadastrada' : 'disciplinas cadastradas'}
              </p>
              <Button onClick={handleAdicionarDisciplina} className="gap-2">
                <Plus className="w-4 h-4" />
                Nova Disciplina
              </Button>
            </div>

            {/* Lista de Disciplinas */}
            {disciplinas.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-lg border-2 border-dashed border-slate-200">
                <BookOpen className="w-12 h-12 mx-auto mb-4 text-slate-400" />
                <h3 className="text-lg font-semibold text-slate-700 mb-2">
                  Nenhuma disciplina cadastrada
                </h3>
                <p className="text-sm text-slate-600 mb-4">
                  Adicione disciplinas e seus tópicos programáticos ao edital
                </p>
                <Button onClick={handleAdicionarDisciplina} className="gap-2">
                  <Plus className="w-4 h-4" />
                  Adicionar Primeira Disciplina
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {disciplinas.map((disciplina, index) => (
                  <Card key={index} className="bg-white border border-slate-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex items-start gap-3 flex-1">
                          <div className="mt-1">
                            <GripVertical className="w-5 h-5 text-slate-400" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-semibold text-slate-900">
                                {disciplina.nome}
                              </h4>
                              {disciplina.peso && (
                                <Badge variant="outline" className="text-xs">
                                  Peso: {disciplina.peso}
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-slate-600">
                              <Badge className="bg-blue-50 text-blue-700 border-blue-200">
                                {contarTopicos(disciplina)} {contarTopicos(disciplina) === 1 ? 'tópico' : 'tópicos'}
                              </Badge>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarDisciplina(disciplina, index)}
                          >
                            Editar
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRemoverDisciplina(index)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}

            {/* Botões de Ação */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => onOpenChange(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSalvarTudo} disabled={salvando || disciplinas.length === 0}>
                {salvando ? 'Salvando...' : 'Salvar Tudo'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Dialog de Adicionar/Editar Disciplina */}
      <DisciplinaForm
        open={showDisciplinaForm}
        onOpenChange={setShowDisciplinaForm}
        disciplina={disciplinaEditando}
        onSave={handleSalvarDisciplina}
      />
    </>
  );
}