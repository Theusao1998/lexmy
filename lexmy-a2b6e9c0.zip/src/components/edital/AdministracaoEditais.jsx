
import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Edit,
  Trash2,
  FileText,
  Building,
  Briefcase,
  Calendar,
  DollarSign,
  Users,
  // Sparkles, // Removed
  BookOpen,
  // Download, // Removed
  CheckCircle2,
  Archive
} from "lucide-react";
import { Edital } from "@/api/entities";
import { User } from "@/api/entities";
// import { base44 } from "@/api/base44Client"; // Removed as verticalization and PDF export are removed
import { toast } from "sonner";
import EditalForm from "./EditalForm";
// import VerticalizeResultDialog from "./VerticalizeResultDialog"; // Removed
import GerenciarDisciplinasDialog from "./GerenciarDisciplinasDialog";

export default function AdministracaoEditais() {
  const [editais, setEditais] = useState([]);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [filtroBusca, setFiltroBusca] = useState("");

  // Estados para formulário de edital
  const [showEditalForm, setShowEditalForm] = useState(false);
  const [editalParaEditar, setEditalParaEditar] = useState(null);

  // Estados para verticalização - REMOVIDOS
  // const [verticalizando, setVerticalizando] = useState(false);
  // const [textoVerticalizar, setTextoVerticalizar] = useState("");
  // const [editalParaVerticalizar, setEditalParaVerticalizar] = useState(null);
  // const [showVerticalizeDialog, setShowVerticalizeDialog] = useState(false);
  // const [verticalizeResult, setVerticalizeResult] = useState(null);

  // Estados para gerenciar disciplinas
  const [showGerenciarDialog, setShowGerenciarDialog] = useState(false);
  const [editalParaGerenciar, setEditalParaGerenciar] = useState(null);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const [userData, editaisData] = await Promise.all([
        User.me(),
        Edital.filter({ tipo: 'template' })
      ]);
      
      setUser(userData);
      setEditais(editaisData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar editais.');
    } finally {
      setIsLoading(false);
    }
  };

  const editaisFiltrados = React.useMemo(() => {
    if (!filtroBusca) return editais;
    const busca = filtroBusca.toLowerCase();
    return editais.filter(e =>
      e.nome_concurso?.toLowerCase().includes(busca) ||
      e.cargo?.toLowerCase().includes(busca) ||
      e.orgao?.toLowerCase().includes(busca)
    );
  }, [editais, filtroBusca]);

  const handleCriarEdital = async (formData) => {
    try {
      if (editalParaEditar) {
        await Edital.update(editalParaEditar.id, formData);
        toast.success('Edital atualizado com sucesso!');
      } else {
        await Edital.create({ 
          ...formData, 
          tipo: "template", 
          disciplinas: [],
          created_by: user.email
        });
        toast.success('Edital criado com sucesso!');
      }
      setShowEditalForm(false);
      setEditalParaEditar(null);
      await carregarDados();
    } catch (error) {
      console.error('Erro ao salvar edital:', error);
      toast.error('Erro ao salvar edital.');
    }
  };

  const handleEditarEdital = (edital) => {
    setEditalParaEditar(edital);
    setShowEditalForm(true);
  };

  const handleExcluirEdital = async (editalId) => {
    if (!confirm('Tem certeza que deseja excluir este edital template? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await Edital.delete(editalId);
      toast.success('Edital excluído com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao excluir edital:', error);
      toast.error('Erro ao excluir edital.');
    }
  };

  // Função para publicar edital
  const handlePublicarEdital = async (edital) => {
    if (!confirm(`Publicar o edital "${edital.nome_concurso}"? Ele ficará visível para todos os usuários na biblioteca.`)) {
      return;
    }

    try {
      await Edital.update(edital.id, {
        ...edital,
        status: 'publicado'
      });
      toast.success('Edital publicado com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao publicar edital:', error);
      toast.error('Erro ao publicar edital.');
    }
  };

  // Função para arquivar edital
  const handleArquivarEdital = async (edital) => {
    if (!confirm(`Arquivar o edital "${edital.nome_concurso}"? Ele continuará visível mas será marcado como histórico.`)) {
      return;
    }

    try {
      await Edital.update(edital.id, {
        ...edital,
        status: 'arquivado'
      });
      toast.success('Edital arquivado com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao arquivar edital:', error);
      toast.error('Erro ao arquivar edital.');
    }
  };

  // REMOVIDO: Função handleIniciarVerticalizacao
  // const handleIniciarVerticalizacao = (edital) => {
  //   setEditalParaVerticalizar(edital);
  //   setTextoVerticalizar("");
  //   setShowVerticalizeDialog(true);
  // };

  // REMOVIDO: Função handleVerticalizar
  // const handleVerticalizar = async () => {
  //   if (!textoVerticalizar.trim() || textoVerticalizar.trim().length < 100) {
  //     toast.error('O texto do edital deve ter pelo menos 100 caracteres.');
  //     return;
  //   }

  //   setVerticalizando(true);

  //   try {
  //     const { data } = await base44.functions.invoke('verticalizeEdital', {
  //       editalId: editalParaVerticalizar.id,
  //       textoEdital: textoVerticalizar
  //     });

  //     if (data.success) {
  //       setVerticalizeResult(data);
  //       toast.success('Verticalização concluída com sucesso!');
  //       await carregarDados();
  //     } else {
  //       toast.error(data.error || 'Erro ao verticalizar edital.');
  //     }
  //   } catch (error) {
  //     console.error('Erro ao verticalizar:', error);
  //     toast.error('Erro ao verticalizar edital.');
  //   } finally {
  //     setVerticalizando(false);
  //   }
  // };

  const handleGerenciarDisciplinas = (edital) => {
    setEditalParaGerenciar(edital);
    setShowGerenciarDialog(true);
  };

  // REMOVIDO: Função handleExportarPDF
  // const handleExportarPDF = async (edital) => {
  //   try {
  //     toast.info('Gerando PDF...');
  //     const { data } = await base44.functions.invoke('exportEditalPdf', {
  //       editalId: edital.id
  //     });

  //     if (data && data.pdfUrl) {
  //       window.open(data.pdfUrl, '_blank');
  //       toast.success('PDF gerado com sucesso!');
  //     } else {
  //       toast.error('Erro ao gerar PDF.');
  //     }
  //   } catch (error) {
  //     console.error('Erro ao exportar PDF:', error);
  //     toast.error('Erro ao exportar PDF.');
  //   }
  // };

  // Função para obter badge de status
  const getStatusBadge = (status) => {
    const configs = {
      rascunho: { color: 'bg-yellow-100 text-yellow-700 border-yellow-200', label: 'Rascunho' },
      publicado: { color: 'bg-green-100 text-green-700 border-green-200', label: 'Publicado' },
      arquivado: { color: 'bg-slate-100 text-slate-700 border-slate-200', label: 'Arquivado' }
    };

    const config = configs[status] || configs.rascunho;

    return (
      <Badge className={`${config.color} border`}>
        {config.label}
      </Badge>
    );
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Editais Template
          </h3>
          <Button onClick={() => { setEditalParaEditar(null); setShowEditalForm(true); }} className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Edital Template
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">
            {/* Busca */}
            <div className="space-y-2">
              <Input
                placeholder="Buscar por concurso, cargo ou órgão..."
                value={filtroBusca}
                onChange={(e) => setFiltroBusca(e.target.value)}
              />
            </div>

            {/* Lista de Editais */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando editais...</p>
              </div>
            ) : editaisFiltrados.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhum edital encontrado
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtroBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhum edital template cadastrado ainda."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {editaisFiltrados.map((edital) => (
                  <Card key={edital.id} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 space-y-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-semibold text-slate-800 text-lg">
                                {edital.nome_concurso}
                              </h4>
                              {getStatusBadge(edital.status)}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-slate-600">
                              {edital.orgao && (
                                <span className="flex items-center gap-1">
                                  <Building className="w-3 h-3" />
                                  {edital.orgao}
                                </span>
                              )}
                              <span className="flex items-center gap-1">
                                <Briefcase className="w-3 h-3" />
                                {edital.cargo}
                              </span>
                            </div>
                          </div>

                          <div className="flex flex-wrap gap-2">
                            {edital.vagas && (
                              <Badge variant="outline" className="gap-1">
                                <Users className="w-3 h-3" />
                                {edital.vagas} vagas
                              </Badge>
                            )}
                            {edital.salario && (
                              <Badge variant="outline" className="gap-1 bg-green-50 text-green-700 border-green-200">
                                <DollarSign className="w-3 h-3" />
                                R$ {edital.salario.toLocaleString('pt-BR')}
                              </Badge>
                            )}
                            {edital.data_prova && (
                              <Badge variant="outline" className="gap-1">
                                <Calendar className="w-3 h-3" />
                                {new Date(edital.data_prova).toLocaleDateString('pt-BR')}
                              </Badge>
                            )}
                            {edital.disciplinas && edital.disciplinas.length > 0 && (
                              <Badge className="gap-1 bg-blue-100 text-blue-700">
                                <BookOpen className="w-3 h-3" />
                                {edital.disciplinas.length} disciplinas
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div className="flex flex-col gap-2">
                          {/* Botão Publicar - apenas se status for rascunho */}
                          {edital.status === 'rascunho' && (
                            <Button
                              size="sm"
                              className="gap-1 bg-green-600 hover:bg-green-700"
                              onClick={() => handlePublicarEdital(edital)}
                            >
                              <CheckCircle2 className="w-3 h-3" />
                              Publicar
                            </Button>
                          )}
                          
                          {/* Botão Arquivar - apenas se status for publicado */}
                          {edital.status === 'publicado' && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="gap-1"
                              onClick={() => handleArquivarEdital(edital)}
                            >
                              <Archive className="w-3 h-3" />
                              Arquivar
                            </Button>
                          )}

                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarEdital(edital)}
                            className="gap-1"
                          >
                            <Edit className="w-3 h-3" />
                            Editar
                          </Button>
                          {/* REMOVIDO: Botão Verticalizar */}
                          {/* <Button
                            size="sm"
                            className="gap-1 bg-purple-600 hover:bg-purple-700"
                            onClick={() => handleIniciarVerticalizacao(edital)}
                          >
                            <Sparkles className="w-3 h-3" />
                            Verticalizar
                          </Button> */}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleGerenciarDisciplinas(edital)}
                            className="gap-1"
                          >
                            <BookOpen className="w-3 h-3" />
                            Disciplinas
                          </Button>
                          {/* REMOVIDO: Botão PDF */}
                          {/* <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleExportarPDF(edital)}
                            className="gap-1"
                          >
                            <Download className="w-3 h-3" />
                            PDF
                          </Button> */}
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirEdital(edital.id)}
                          >
                            <Trash2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Form de Edital */}
      <EditalForm
        open={showEditalForm}
        onOpenChange={setShowEditalForm}
        onSubmit={handleCriarEdital}
        titulo={editalParaEditar ? "Editar Edital Template" : "Novo Edital Template"}
        subtitulo={editalParaEditar ? "Altere as informações do edital" : "Informações básicas do edital template"}
        editalInicial={editalParaEditar}
        isTemplate={true}
      />

      {/* Dialog de Verticalização - REMOVIDO */}
      {/* <VerticalizeResultDialog
        open={showVerticalizeDialog}
        onOpenChange={setShowVerticalizeDialog}
        textoEdital={textoVerticalizar}
        onTextoChange={setTextoVerticalizar}
        onVerticalizar={handleVerticalizar}
        verticalizando={verticalizando}
        result={verticalizeResult}
      /> */}

      {/* Dialog de Gerenciar Disciplinas */}
      {editalParaGerenciar && (
        <GerenciarDisciplinasDialog
          open={showGerenciarDialog}
          onOpenChange={setShowGerenciarDialog}
          edital={editalParaGerenciar}
          onSave={carregarDados}
        />
      )}
    </>
  );
}
