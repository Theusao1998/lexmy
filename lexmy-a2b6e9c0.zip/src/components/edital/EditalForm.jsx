import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FileText, Building, Users, DollarSign, Calendar, FileCheck } from "lucide-react";

export default function EditalForm({ 
  open, 
  onOpenChange, 
  onSubmit, 
  titulo = "Novo Edital", 
  subtitulo = "Informações básicas do edital",
  editalInicial = null,
  isTemplate = false // NOVO: Prop para indicar se é um edital template
}) {
  const [form, setForm] = React.useState({
    nome_concurso: "",
    orgao: "",
    cargo: "",
    data_inscricoes: "",
    data_prova: "",
    vagas: "",
    salario: "",
    status: "rascunho" // NOVO: Campo de status
  });

  const [erro, setErro] = React.useState("");

  // Preencher formulário quando editalInicial mudar
  React.useEffect(() => {
    if (editalInicial) {
      setForm({
        nome_concurso: editalInicial.nome_concurso || "",
        orgao: editalInicial.orgao || "",
        cargo: editalInicial.cargo || "",
        data_inscricoes: editalInicial.data_inscricoes || "",
        data_prova: editalInicial.data_prova || "",
        vagas: editalInicial.vagas ? String(editalInicial.vagas) : "",
        salario: editalInicial.salario ? String(editalInicial.salario) : "",
        status: editalInicial.status || "rascunho" // NOVO: Preencher status
      });
    } else {
      resetar();
    }
  }, [editalInicial]);

  const handleChange = (k, v) => setForm(prev => ({ ...prev, [k]: v }));

  const finalizar = (e) => {
    e.preventDefault();
    
    if (!form.nome_concurso.trim()) {
      setErro("O nome do concurso é obrigatório.");
      return;
    }
    if (!form.cargo.trim()) {
      setErro("O cargo é obrigatório.");
      return;
    }

    setErro("");
    
    // ATUALIZADO: Preparar dados para envio
    const dadosParaEnvio = {
      nome_concurso: form.nome_concurso,
      orgao: form.orgao || null,
      cargo: form.cargo,
      data_inscricoes: form.data_inscricoes || null,
      data_prova: form.data_prova || null,
      vagas: form.vagas ? parseInt(form.vagas) : null,
      salario: form.salario ? parseFloat(form.salario) : null
    };

    // NOVO: Incluir status apenas se for um template
    if (isTemplate) {
      dadosParaEnvio.status = form.status;
    }

    onSubmit(dadosParaEnvio);
  };

  const resetar = () => {
    setForm({
      nome_concurso: "",
      orgao: "",
      cargo: "",
      data_inscricoes: "",
      data_prova: "",
      vagas: "",
      salario: "",
      status: "rascunho"
    });
    setErro("");
  };

  return (
    <Dialog open={open} onOpenChange={(v) => { onOpenChange(v); if (!v) resetar(); }}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            {titulo}
          </DialogTitle>
          <p className="text-sm text-slate-600">{subtitulo}</p>
        </DialogHeader>

        <form onSubmit={finalizar} className="space-y-4">
          {/* Informações Obrigatórias */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="nome_concurso">Nome do Concurso *</Label>
              <Input
                id="nome_concurso"
                placeholder="Ex.: 23º Concurso de Ingresso na Carreira..."
                value={form.nome_concurso}
                onChange={(e) => handleChange("nome_concurso", e.target.value)}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="orgao">Órgão</Label>
              <Input
                id="orgao"
                placeholder="Ex.: Procuradoria Geral do Estado"
                value={form.orgao}
                onChange={(e) => handleChange("orgao", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="cargo">Cargo *</Label>
              <Input
                id="cargo"
                placeholder="Ex.: Procurador do Estado"
                value={form.cargo}
                onChange={(e) => handleChange("cargo", e.target.value)}
                required
              />
            </div>
          </div>

          {/* NOVO: Campo de Status - Apenas para Templates */}
          {isTemplate && (
            <div className="border-t pt-4">
              <div className="space-y-2">
                <Label htmlFor="status" className="flex items-center gap-2">
                  <FileCheck className="w-4 h-4" />
                  Status de Publicação *
                </Label>
                <Select
                  value={form.status}
                  onValueChange={(value) => handleChange("status", value)}
                >
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Selecione o status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rascunho">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                        <span>Rascunho - Visível apenas para administradores</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="publicado">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-green-500"></div>
                        <span>Publicado - Visível para todos os usuários</span>
                      </div>
                    </SelectItem>
                    <SelectItem value="arquivado">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-slate-500"></div>
                        <span>Arquivado - Visível mas marcado como histórico</span>
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  Templates publicados estarão disponíveis na Biblioteca para todos os usuários copiarem.
                </p>
              </div>
            </div>
          )}

          {/* Informações Opcionais */}
          <div className="border-t pt-4">
            <h4 className="text-sm font-medium text-slate-700 mb-3">Informações Adicionais (Opcional)</h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="data_inscricoes">Data Limite das Inscrições</Label>
                <Input
                  id="data_inscricoes"
                  type="date"
                  value={form.data_inscricoes}
                  onChange={(e) => handleChange("data_inscricoes", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="data_prova">Data da Prova</Label>
                <Input
                  id="data_prova"
                  type="date"
                  value={form.data_prova}
                  onChange={(e) => handleChange("data_prova", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="vagas">Número de Vagas</Label>
                <Input
                  id="vagas"
                  type="number"
                  placeholder="Ex.: 10"
                  value={form.vagas}
                  onChange={(e) => handleChange("vagas", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="salario">Salário (R$)</Label>
                <Input
                  id="salario"
                  type="number"
                  step="0.01"
                  placeholder="Ex.: 25000.00"
                  value={form.salario}
                  onChange={(e) => handleChange("salario", e.target.value)}
                />
              </div>
            </div>
          </div>

          {erro && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700">{erro}</p>
            </div>
          )}

          {/* Próximos Passos - Apenas para novos editais pessoais */}
          {!editalInicial && !isTemplate && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="text-sm font-medium text-blue-800 mb-2">📋 Próximos Passos:</h4>
              <ul className="text-xs text-blue-700 space-y-1">
                <li>• Após criar o edital, você poderá verticalizar o conteúdo programático</li>
                <li>• Cole o texto do edital oficial e a IA extrairá todos os tópicos</li>
                <li>• Acompanhe seu progresso marcando os tópicos estudados</li>
              </ul>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancelar
            </Button>
            <Button type="submit" className="gap-2">
              <FileText className="w-4 h-4" />
              {editalInicial ? "Salvar Alterações" : (isTemplate ? "Criar Template" : "Criar Edital")}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}