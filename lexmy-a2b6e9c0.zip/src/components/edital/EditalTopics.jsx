import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { addDays, format } from "date-fns";
import { ptBR } from "date-fns/locale";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { ChevronDown, BookOpen, ArrowLeft, Building, Briefcase, Calendar, Users, DollarSign } from "lucide-react";

export default function EditalTopics({ edital, onToggle, onBack }) {
  const [expandedDisciplinas, setExpandedDisciplinas] = useState({});

  if (!edital?.disciplinas?.length) {
    return null;
  }

  const toggleDisciplina = (index) => {
    setExpandedDisciplinas(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  // Calcula as datas de revisão esperadas com base na data de estudo
  const calcularDatasRevisao = (dataEstudo) => {
    if (!dataEstudo) return null;
    const base = new Date(dataEstudo);
    return {
      revisao_24h: addDays(base, 1),
      revisao_7d: addDays(base, 7),
      revisao_14d: addDays(base, 14),
      revisao_30d: addDays(base, 30),
      revisao_90d: addDays(base, 90)
    };
  };

  // Renderiza os botões de ação (sempre visíveis)
  const renderBotoesAcao = (disciplinaIndex, topicoIndex, topico) => {
    const datasRevisao = topico.estudado_em ? calcularDatasRevisao(topico.estudado_em) : null;
    
    const acoes = [
      { 
        campo: 'estudado_em', 
        label: 'Estudado',
        tooltip: 'Marcar como estudado hoje'
      },
      { 
        campo: 'revisao_24h_em', 
        label: '1 dia',
        tooltip: datasRevisao ? `Revisar em ${format(datasRevisao.revisao_24h, 'dd/MM/yyyy')}` : 'Estude primeiro'
      },
      { 
        campo: 'revisao_7d_em', 
        label: '7 dias',
        tooltip: datasRevisao ? `Revisar em ${format(datasRevisao.revisao_7d, 'dd/MM/yyyy')}` : 'Estude primeiro'
      },
      { 
        campo: 'revisao_14d_em', 
        label: '14 dias',
        tooltip: datasRevisao ? `Revisar em ${format(datasRevisao.revisao_14d, 'dd/MM/yyyy')}` : 'Estude primeiro'
      },
      { 
        campo: 'revisao_30d_em', 
        label: '30 dias',
        tooltip: datasRevisao ? `Revisar em ${format(datasRevisao.revisao_30d, 'dd/MM/yyyy')}` : 'Estude primeiro'
      },
      { 
        campo: 'revisao_90d_em', 
        label: '90 dias',
        tooltip: datasRevisao ? `Revisar em ${format(datasRevisao.revisao_90d, 'dd/MM/yyyy')}` : 'Estude primeiro'
      }
    ];

    return (
      <div className="flex flex-wrap items-center gap-2 mt-3">
        {acoes.map((acao, idx) => {
          const jaConcluido = !!topico[acao.campo];
          const desabilitado = acao.campo !== 'estudado_em' && !topico.estudado_em;
          
          return (
            <TooltipProvider key={idx}>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button
                    onClick={() => {
                      if (!desabilitado) {
                        onToggle(disciplinaIndex, topicoIndex, acao.campo);
                      }
                    }}
                    disabled={desabilitado}
                    className={`
                      px-3 py-1.5 text-xs rounded-md border transition-all font-medium
                      ${jaConcluido 
                        ? 'bg-green-100 text-green-700 border-green-300 hover:bg-green-200' 
                        : desabilitado
                        ? 'bg-slate-50 text-slate-400 border-slate-200 cursor-not-allowed'
                        : 'bg-white text-slate-700 border-slate-300 hover:bg-blue-50 hover:border-blue-300 hover:text-blue-700'
                      }
                    `}
                  >
                    {acao.label}
                  </button>
                </TooltipTrigger>
                <TooltipContent>
                  <p className="text-xs">{acao.tooltip}</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          );
        })}
      </div>
    );
  };

  const totalTopicos = edital.disciplinas.reduce((acc, d) => acc + (d.topicos?.length || 0), 0);
  const topicosEstudados = edital.disciplinas.reduce((acc, d) => 
    acc + (d.topicos?.filter(t => t.estudado_em)?.length || 0), 0
  );
  const percentualGeral = totalTopicos > 0 ? Math.round((topicosEstudados / totalTopicos) * 100) : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50/30 to-amber-50/20 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Cabeçalho com informações do edital */}
        <div className="space-y-4">
          <Button
            onClick={onBack}
            variant="ghost"
            className="gap-2 hover:bg-white/60 -ml-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Voltar para Editais
          </Button>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">
                    {edital.nome_concurso}
                  </h1>
                  <div className="flex flex-wrap items-center gap-3 text-sm text-slate-600">
                    {edital.orgao && (
                      <span className="flex items-center gap-1">
                        <Building className="w-4 h-4" />
                        {edital.orgao}
                      </span>
                    )}
                    <span className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      {edital.cargo}
                    </span>
                    {edital.vagas && (
                      <Badge variant="outline" className="gap-1">
                        <Users className="w-3 h-3" />
                        {edital.vagas} vagas
                      </Badge>
                    )}
                    {edital.salario && (
                      <Badge variant="outline" className="gap-1 bg-green-50 text-green-700 border-green-200">
                        <DollarSign className="w-3 h-3" />
                        R$ {edital.salario.toLocaleString('pt-BR')}
                      </Badge>
                    )}
                    {edital.data_prova && (
                      <Badge variant="outline" className="gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(edital.data_prova).toLocaleDateString('pt-BR')}
                      </Badge>
                    )}
                  </div>
                </div>

                {/* Estatísticas gerais */}
                <div className="pt-4 border-t border-slate-200">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Disciplinas</p>
                      <p className="text-2xl font-bold text-slate-800">{edital.disciplinas.length}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Total de Tópicos</p>
                      <p className="text-2xl font-bold text-slate-800">{totalTopicos}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Estudados</p>
                      <p className="text-2xl font-bold text-green-600">{topicosEstudados}</p>
                    </div>
                    <div>
                      <p className="text-xs text-slate-500 mb-1">Progresso</p>
                      <p className="text-2xl font-bold text-blue-600">{percentualGeral}%</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Lista de disciplinas */}
        <div className="space-y-4">
          {edital.disciplinas.map((d, di) => {
            const isExpanded = expandedDisciplinas[di] ?? false;
            const totalTopicos = d.topicos?.length || 0;
            const topicosEstudados = d.topicos?.filter(t => t.estudado_em)?.length || 0;
            const percentualConcluido = totalTopicos > 0 ? Math.round((topicosEstudados / totalTopicos) * 100) : 0;

            return (
              <Collapsible
                key={di}
                open={isExpanded}
                onOpenChange={() => toggleDisciplina(di)}
              >
                <Card className="bg-white/70 border-0 shadow hover:shadow-lg transition-shadow">
                  <CollapsibleTrigger asChild>
                    <button className="w-full text-left">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3 flex-1">
                            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                              <BookOpen className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <h3 className="font-semibold text-slate-800 text-lg">
                                {d.nome}
                                {typeof d.peso === 'number' && (
                                  <span className="ml-2 text-sm text-slate-500 font-normal">
                                    (peso {d.peso})
                                  </span>
                                )}
                              </h3>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <Badge variant="outline" className="text-xs">
                                  {totalTopicos} {totalTopicos === 1 ? 'tópico' : 'tópicos'}
                                </Badge>
                                {topicosEstudados > 0 && (
                                  <Badge className="bg-green-100 text-green-700 border-green-200 text-xs">
                                    {percentualConcluido}% concluído
                                  </Badge>
                                )}
                              </div>
                            </div>
                          </div>
                          <ChevronDown 
                            className={`w-5 h-5 text-slate-400 transition-transform duration-200 flex-shrink-0 ml-2 ${
                              isExpanded ? 'transform rotate-180' : ''
                            }`}
                          />
                        </div>
                      </CardContent>
                    </button>
                  </CollapsibleTrigger>

                  <CollapsibleContent>
                    <CardContent className="pt-0 pb-4 px-4">
                      <div className="space-y-3 pl-2 border-l-2 border-blue-200 ml-5">
                        {(d.topicos || []).map((t, ti) => (
                          <div 
                            key={ti}
                            className="p-3 rounded-lg border border-slate-200 bg-white ml-4"
                          >
                            <div className="text-sm text-slate-700">
                              {t.titulo}
                            </div>
                            {renderBotoesAcao(di, ti, t)}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </CollapsibleContent>
                </Card>
              </Collapsible>
            );
          })}
        </div>
      </div>
    </div>
  );
}