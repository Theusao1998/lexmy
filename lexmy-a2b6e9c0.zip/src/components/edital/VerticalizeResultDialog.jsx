import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, ListChecks } from "lucide-react";

export default function VerticalizeResultDialog({ open, onOpenChange, result, onDownload, onListar }) {
  const totalDisciplinas = result?.disciplinas?.length || 0;
  const totalTopicos = result?.disciplinas?.reduce((acc, d) => acc + (d.topicos?.length || 0), 0) || 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Edital verticalizado!</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 rounded-lg bg-slate-50 border">
            <p className="text-sm text-slate-600">
              Disciplinas: <b>{totalDisciplinas}</b> • Tópicos: <b>{totalTopicos}</b>
            </p>
            {result?.resumo && (
              <p className="text-sm text-slate-600 mt-2 line-clamp-3">{result.resumo}</p>
            )}
          </div>

          <div className="grid gap-3">
            <Button variant="outline" className="gap-2 w-full" onClick={onListar}>
              <ListChecks className="w-4 h-4" /> Listar conteúdo
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}