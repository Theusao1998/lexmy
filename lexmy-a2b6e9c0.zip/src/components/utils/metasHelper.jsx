import { Meta } from "@/api/entities";
import { HistoricoQuestao } from "@/api/entities";
import { Disciplina } from "@/api/entities";
import { User } from "@/api/entities";

export const atualizarMetasQuestoes = async () => {
  try {
    // Buscar metas ativas de questões do usuário
    const metas = await Meta.filter({
      unidade: "questoes",
      concluida: false
    });

    // Para cada meta, incrementar o valor atual
    for (const meta of metas) {
      const novoValorAtual = (meta.valor_atual || 0) + 1;
      const concluida = novoValorAtual >= meta.valor_meta;

      await Meta.update(meta.id, {
        valor_atual: novoValorAtual,
        concluida: concluida
      });
    }

    return metas.length; // Retorna quantas metas foram atualizadas
  } catch (error) {
    console.error('Erro ao atualizar metas de questões:', error);
    return 0;
  }
};

// CORRIGIDO: Função para atualizar estatísticas da disciplina (sem espelhamento entre usuários)
export const atualizarEstatisticasDisciplina = async (disciplina, acertou) => {
  try {
    if (!disciplina || disciplina === 'Não especificada') return;
    
    // CORRIGIDO: Buscar disciplinas do usuário atual (RLS já garante isso)
    const disciplinasEncontradas = await Disciplina.filter({ nome: disciplina });
    
    let disciplinaObj;
    
    if (disciplinasEncontradas.length > 0) {
      // Usar a primeira disciplina encontrada (que será específica do usuário atual devido ao RLS)
      disciplinaObj = disciplinasEncontradas[0];
    } else {
      // NOVO: Se não encontrar disciplina para este usuário, criar uma nova automaticamente
      try {
        disciplinaObj = await Disciplina.create({
          nome: disciplina,
          cor: '#3b82f6', // Cor padrão azul
          questoes_total: 0,
          questoes_corretas: 0
        });
        console.log(`Nova disciplina criada automaticamente para o usuário: ${disciplina}`);
      } catch (createError) {
        console.error('Erro ao criar nova disciplina automaticamente:', createError);
        return; // Sair da função se não conseguir criar
      }
    }
    
    // Atualizar estatísticas da disciplina específica do usuário
    const novoTotal = (disciplinaObj.questoes_total || 0) + 1;
    const novosAcertos = (disciplinaObj.questoes_corretas || 0) + (acertou ? 1 : 0);
    
    await Disciplina.update(disciplinaObj.id, {
      questoes_total: novoTotal,
      questoes_corretas: novosAcertos
    });
    
    console.log(`Disciplina ${disciplina} atualizada para o usuário: ${novosAcertos}/${novoTotal} questões`);
    
  } catch (error) {
    console.error('Erro ao atualizar estatísticas da disciplina:', error);
  }
};

export const registrarQuestao = async (tipo, disciplina, acertou) => {
  try {
    await HistoricoQuestao.create({
      data: new Date().toISOString().split('T')[0], // Data atual no formato YYYY-MM-DD
      tipo: tipo,
      disciplina: disciplina || '',
      acertou: acertou
    });

    // Atualizar as metas
    await atualizarMetasQuestoes();
    
    // CORRIGIDO: Atualizar estatísticas da disciplina (agora sem espelhamento)
    await atualizarEstatisticasDisciplina(disciplina, acertou);
  } catch (error) {
    console.error('Erro ao registrar questão:', error);
  }
};

export const obterEstatisticasHoje = async () => {
  try {
    const hoje = new Date().toISOString().split('T')[0];
    const questoesHoje = await HistoricoQuestao.filter({
      data: hoje
    });

    const total = questoesHoje.length;
    const acertos = questoesHoje.filter(q => q.acertou).length;

    return { acertos, total };
  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    return { acertos: 0, total: 0 };
  }
};