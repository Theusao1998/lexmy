
import React, { useState, useEffect } from 'react';
import { Clock } from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export default function BrasiliaClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      try {
        setTime(new Date());
      } catch (error) {
        console.error('Erro ao atualizar relógio:', error);
      }
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = () => {
    try {
      // Converter para horário de Brasília
      // Using toLocaleString with en-US and then parsing back to Date ensures correct timezone interpretation
      const brasiliaTime = new Date(time.toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));

      // Verificar se a data é válida
      if (isNaN(brasiliaTime.getTime())) {
        return "00:00:00";
      }

      return format(brasiliaTime, 'HH:mm:ss', { locale: ptBR });
    } catch (error) {
      console.error('Erro ao formatar horário:', error);
      return "00:00:00";
    }
  };

  const formatDate = () => {
    try {
      // Converter para horário de Brasília
      const brasiliaTime = new Date(time.toLocaleString("en-US", { timeZone: "America/Sao_Paulo" }));

      // Verificar se a data é válida
      if (isNaN(brasiliaTime.getTime())) {
        return "Data inválida";
      }

      return format(brasiliaTime, "EEEE, dd 'de' MMMM", { locale: ptBR });
    } catch (error) {
      console.error('Erro ao formatar data:', error);
      return "Data inválida";
    }
  };

  return (
    <div className="px-3">
      <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/50 space-y-2 text-center">
        <div className="flex items-center justify-center gap-2">
            <Clock className="w-4 h-4 text-slate-500" />
            <span className="text-xs font-medium text-slate-700">
              Horário de Brasília
            </span>
        </div>
        <p className="text-2xl font-bold font-mono text-slate-800">
          {formatTime()}
        </p>
        <p className="text-sm font-medium text-slate-600">
          {formatDate()}
        </p>
      </div>
    </div>
  );
}
