import React, { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  List,
  Headphones
} from "lucide-react";
import { useAudioPlayer } from "./AudioPlayerContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

export default function GlobalAudioPlayer() {
  const {
    currentAudio,
    isPlaying,
    currentTime,
    duration,
    volume,
    queue,
    currentIndex,
    togglePlayPause,
    seekTo,
    setVolume,
    nextTrack,
    previousTrack,
    removeFromQueue,
    clearQueue
  } = useAudioPlayer();

  const [showQueue, setShowQueue] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [lastVolume, setLastVolume] = useState(volume);

  if (!currentAudio) return null;

  const formatTime = (time) => {
    if (isNaN(time)) return "0:00";
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const handleVolumeChange = (value) => {
    const newVolume = value[0];
    setVolume(newVolume);
    if (newVolume > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setVolume(lastVolume);
      setIsMuted(false);
    } else {
      setLastVolume(volume);
      setVolume(0);
      setIsMuted(true);
    }
  };

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <>
      {/* Player Global Fixo */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-t border-slate-200 shadow-2xl">
        <Card className="rounded-none border-0 bg-transparent">
          <CardContent className="p-4">
            <div className="flex items-center gap-4">
              {/* Informações do Áudio */}
              <div className="flex items-center gap-3 min-w-0 flex-1">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl flex items-center justify-center flex-shrink-0">
                  <Headphones className="w-6 h-6 text-blue-600" />
                </div>
                <div className="min-w-0 flex-1">
                  <h4 className="font-semibold text-slate-800 truncate text-sm">
                    {currentAudio.titulo}
                  </h4>
                  <p className="text-xs text-slate-500 truncate">
                    {currentAudio.descricao || "Legislação em Áudio"}
                  </p>
                </div>
              </div>

              {/* Controles Centrais */}
              <div className="flex items-center gap-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={previousTrack}
                  disabled={currentIndex <= 0}
                  className="h-8 w-8 p-0"
                >
                  <SkipBack className="w-4 h-4" />
                </Button>

                <Button
                  onClick={togglePlayPause}
                  className="h-10 w-10 p-0 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
                >
                  {isPlaying ? (
                    <Pause className="w-5 h-5 text-white" />
                  ) : (
                    <Play className="w-5 h-5 text-white ml-0.5" />
                  )}
                </Button>

                <Button
                  variant="ghost"
                  size="sm"
                  onClick={nextTrack}
                  disabled={currentIndex >= queue.length - 1}
                  className="h-8 w-8 p-0"
                >
                  <SkipForward className="w-4 h-4" />
                </Button>
              </div>

              {/* Progresso e Tempo */}
              <div className="hidden md:flex items-center gap-3 flex-1 max-w-md">
                <span className="text-xs text-slate-500 w-10 text-right">
                  {formatTime(currentTime)}
                </span>
                <div 
                  className="flex-1 h-2 bg-slate-200 rounded-full cursor-pointer relative group"
                  onClick={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect();
                    const x = e.clientX - rect.left;
                    const percentage = x / rect.width;
                    seekTo(percentage * duration);
                  }}
                >
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full transition-all duration-200 group-hover:from-blue-600 group-hover:to-blue-700"
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
                <span className="text-xs text-slate-500 w-10">
                  {formatTime(duration)}
                </span>
              </div>

              {/* Controles de Volume e Fila */}
              <div className="hidden lg:flex items-center gap-3">
                {/* Volume */}
                <div className="flex items-center gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={toggleMute}
                    className="h-8 w-8 p-0"
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="w-4 h-4" />
                    ) : (
                      <Volume2 className="w-4 h-4" />
                    )}
                  </Button>
                  <Slider
                    value={[isMuted ? 0 : volume]}
                    onValueChange={handleVolumeChange}
                    max={1}
                    step={0.01}
                    className="w-20"
                  />
                </div>

                {/* Fila */}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowQueue(true)}
                  className="gap-2 h-8 px-3"
                >
                  <List className="w-4 h-4" />
                  <Badge variant="secondary" className="text-xs">
                    {queue.length}
                  </Badge>
                </Button>
              </div>

              {/* Botão de Fila (Mobile) */}
              <div className="lg:hidden">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowQueue(true)}
                  className="h-8 w-8 p-0"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Progresso (Mobile) */}
            <div className="md:hidden mt-3">
              <div 
                className="w-full h-1 bg-slate-200 rounded-full cursor-pointer"
                onClick={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = e.clientX - rect.left;
                  const percentage = x / rect.width;
                  seekTo(percentage * duration);
                }}
              >
                <div 
                  className="h-full bg-gradient-to-r from-blue-500 to-blue-600 rounded-full"
                  style={{ width: `${progressPercentage}%` }}
                />
              </div>
              <div className="flex justify-between text-xs text-slate-500 mt-1">
                <span>{formatTime(currentTime)}</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modal da Fila */}
      <Dialog open={showQueue} onOpenChange={setShowQueue}>
        <DialogContent className="sm:max-w-md max-h-[70vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between">
              Fila de Reprodução
              {queue.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearQueue}
                  className="text-red-600 hover:bg-red-50"
                >
                  Limpar Fila
                </Button>
              )}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-2 overflow-y-auto">
            {queue.length === 0 ? (
              <div className="text-center py-8 text-slate-500">
                <List className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Fila vazia</p>
                <p className="text-xs mt-1">Adicione áudios à fila para reproduzir em sequência</p>
              </div>
            ) : (
              queue.map((audio, index) => (
                <div
                  key={audio.id}
                  className={`flex items-center gap-3 p-3 rounded-lg border transition-all ${
                    index === currentIndex
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <div className="w-8 h-8 bg-gradient-to-br from-blue-100 to-blue-200 rounded-lg flex items-center justify-center flex-shrink-0">
                    {index === currentIndex && isPlaying ? (
                      <div className="w-3 h-3 bg-blue-600 rounded-full animate-pulse" />
                    ) : (
                      <span className="text-xs font-semibold text-blue-600">
                        {index + 1}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">
                      {audio.titulo}
                    </p>
                    <p className="text-xs text-slate-500 truncate">
                      {audio.descricao || "Sem descrição"}
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFromQueue(index)}
                    className="h-8 w-8 p-0 text-red-500 hover:bg-red-50"
                  >
                    ×
                  </Button>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}