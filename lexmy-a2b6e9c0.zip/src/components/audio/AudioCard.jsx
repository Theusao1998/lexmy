import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Play,
  Pause,
  Plus,
  Pencil,
  Trash2
} from "lucide-react";
import { useAudioPlayer } from "./AudioPlayerContext";

export default function AudioCard({ audio, isAdmin, onEdit, onDelete }) {
  const {
    currentAudio,
    isPlaying,
    playAudio,
    addToQueue
  } = useAudioPlayer();

  const isCurrentAudio = currentAudio && currentAudio.id === audio.id;
  const isCurrentlyPlaying = isCurrentAudio && isPlaying;

  const handlePlayClick = (e) => {
    e.stopPropagation();
    playAudio(audio);
  };

  const handleAddToQueue = (e) => {
    e.stopPropagation();
    addToQueue(audio);
  };

  return (
    <Card 
      className={`bg-white border shadow-sm hover:shadow-md transition-all cursor-pointer ${
        isCurrentAudio ? 'border-blue-300 shadow-blue-100' : 'hover:border-slate-300'
      }`}
      onClick={() => playAudio(audio)}
    >
      <CardContent className="p-3">
        <div className="flex items-center gap-3 w-full">
          {/* Left: Play/Pause Button */}
          <div className="flex-shrink-0">
            <Button
              onClick={handlePlayClick}
              size="icon"
              className={`h-10 w-10 rounded-lg flex-shrink-0 ${
                isCurrentlyPlaying
                  ? 'bg-red-500 hover:bg-red-600'
                  : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700'
              }`}
            >
              {isCurrentlyPlaying ? (
                <Pause className="w-4 h-4 text-white" />
              ) : (
                <Play className="w-4 h-4 text-white ml-0.5" />
              )}
            </Button>
          </div>

          {/* Middle: Title and Description */}
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-slate-800 text-sm truncate" title={audio.titulo}>
              {audio.titulo}
            </h4>
            <p className="text-xs text-slate-500 truncate mt-1" title={audio.descricao}>
              {audio.descricao || "Sem descrição"}
            </p>
          </div>

          {/* Right: Actions */}
          <div className="flex items-center gap-1.5">
            <Button
              variant="outline"
              size="icon"
              className="h-9 w-9 hover:bg-green-50 hover:border-green-200 flex-shrink-0"
              onClick={handleAddToQueue}
              title="Adicionar à fila"
            >
              <Plus className="w-4 h-4" />
            </Button>

            {isAdmin && onEdit && onDelete && (
              <>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 hover:bg-blue-50"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEdit(audio);
                  }}
                  title="Editar"
                >
                  <Pencil className="w-4 h-4 text-blue-600" />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-9 w-9 hover:bg-red-50"
                  onClick={(e) => {
                    e.stopPropagation();
                    onDelete(audio);
                  }}
                  title="Excluir"
                >
                  <Trash2 className="w-4 h-4 text-red-600" />
                </Button>
              </>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}