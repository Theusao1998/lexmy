import React, { createContext, useContext, useState, useRef, useEffect, useCallback } from "react";

const AudioPlayerContext = createContext(null);

export function AudioPlayerProvider({ children }) {
  // Estado do player
  const [currentAudio, setCurrentAudio] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  const [queue, setQueue] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  
  // Referência do elemento audio
  const audioRef = useRef(null);

  // Função para próxima faixa (definida antes do useEffect)
  const nextTrack = useCallback(() => {
    if (queue.length === 0) return;
    
    const nextIndex = currentIndex + 1;
    if (nextIndex < queue.length) {
      setCurrentIndex(nextIndex);
      // Não precisamos chamar playAudio aqui para evitar dependência circular
      const nextAudio = queue[nextIndex];
      setCurrentAudio(nextAudio);
      if (audioRef.current) {
        audioRef.current.src = nextAudio.audio_url;
        audioRef.current.play().then(() => setIsPlaying(true));
      }
    } else {
      // Fim da fila
      setIsPlaying(false);
      setCurrentIndex(-1);
    }
  }, [queue, currentIndex]);

  // Inicializar o elemento audio
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.volume = volume;
    }

    const audio = audioRef.current;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleDurationChange = () => setDuration(audio.duration || 0);
    const handleEnded = () => {
      setIsPlaying(false);
      nextTrack();
    };
    const handleLoadStart = () => {
      setCurrentTime(0);
      setDuration(0);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('loadstart', handleLoadStart);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('loadstart', handleLoadStart);
    };
  }, [nextTrack]);

  // Atualizar volume quando mudar
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  // Função para tocar um áudio específico
  const playAudio = useCallback((audioData) => {
    if (!audioRef.current) return;

    // Se é o mesmo áudio, apenas pausar/despausar
    if (currentAudio && currentAudio.id === audioData.id) {
      if (isPlaying) {
        audioRef.current.pause();
        setIsPlaying(false);
      } else {
        audioRef.current.play().then(() => setIsPlaying(true));
      }
      return;
    }

    // Novo áudio
    setCurrentAudio(audioData);
    audioRef.current.src = audioData.audio_url;
    audioRef.current.play().then(() => setIsPlaying(true));
  }, [currentAudio, isPlaying]);

  // Função para pausar
  const pauseAudio = useCallback(() => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  }, []);

  // Função para tocar/pausar
  const togglePlayPause = useCallback(() => {
    if (!audioRef.current || !currentAudio) return;

    if (isPlaying) {
      pauseAudio();
    } else {
      audioRef.current.play().then(() => setIsPlaying(true));
    }
  }, [currentAudio, isPlaying, pauseAudio]);

  // Função para buscar posição
  const seekTo = useCallback((time) => {
    if (audioRef.current && duration > 0) {
      audioRef.current.currentTime = Math.max(0, Math.min(time, duration));
    }
  }, [duration]);

  // Função para adicionar à fila
  const addToQueue = useCallback((audioData) => {
    setQueue(prev => {
      // Evitar duplicatas
      if (prev.some(item => item.id === audioData.id)) {
        return prev;
      }
      return [...prev, audioData];
    });
  }, []);

  // Função para adicionar coleção à fila
  const addCollectionToQueue = useCallback((audios) => {
    setQueue(prev => {
      const newAudios = audios.filter(audio => 
        !prev.some(item => item.id === audio.id)
      );
      return [...prev, ...newAudios];
    });
  }, []);

  // Função para tocar fila
  const playQueue = useCallback((startIndex = 0) => {
    if (queue.length === 0) return;
    
    const audioToPlay = queue[startIndex];
    setCurrentIndex(startIndex);
    playAudio(audioToPlay);
  }, [queue, playAudio]);

  // Função para faixa anterior
  const previousTrack = useCallback(() => {
    if (queue.length === 0) return;
    
    const prevIndex = currentIndex - 1;
    if (prevIndex >= 0) {
      setCurrentIndex(prevIndex);
      playAudio(queue[prevIndex]);
    }
  }, [queue, currentIndex, playAudio]);

  // Função para remover da fila
  const removeFromQueue = useCallback((index) => {
    setQueue(prev => {
      const newQueue = prev.filter((_, i) => i !== index);
      
      // Ajustar currentIndex se necessário
      if (index <= currentIndex) {
        setCurrentIndex(curr => Math.max(-1, curr - 1));
      }
      
      return newQueue;
    });
  }, [currentIndex]);

  // Função para limpar fila
  const clearQueue = useCallback(() => {
    setQueue([]);
    setCurrentIndex(-1);
  }, []);

  // Função para tocar coleção inteira
  const playCollection = useCallback((audios) => {
    if (audios.length === 0) return;
    
    setQueue(audios);
    setCurrentIndex(0);
    playAudio(audios[0]);
  }, [playAudio]);

  const value = {
    // Estado
    currentAudio,
    isPlaying,
    currentTime,
    duration,
    volume,
    queue,
    currentIndex,
    
    // Controles básicos
    playAudio,
    pauseAudio,
    togglePlayPause,
    seekTo,
    setVolume,
    
    // Controles de fila
    addToQueue,
    addCollectionToQueue,
    playQueue,
    nextTrack,
    previousTrack,
    removeFromQueue,
    clearQueue,
    playCollection
  };

  return (
    <AudioPlayerContext.Provider value={value}>
      {children}
    </AudioPlayerContext.Provider>
  );
}

export function useAudioPlayer() {
  const context = useContext(AudioPlayerContext);
  if (!context) {
    throw new Error("useAudioPlayer deve ser usado dentro de AudioPlayerProvider");
  }
  return context;
}