import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  Headphones,
  Folder,
  Upload,
  Music,
  List
} from "lucide-react";
import { LegislacaoAudio } from "@/api/entities";
import { ColecaoLegislacaoAudio } from "@/api/entities";
import { FiltroQuestao } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function AdministracaoLegislacaoAudio() {
  const [audios, setAudios] = useState([]);
  const [colecoes, setColecoes] = useState([]);
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("audios");

  // Filtros para áudios
  const [filtroDisciplina, setFiltroDisciplina] = useState("all");
  const [filtroColecao, setFiltroColecao] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Modal de áudio
  const [showAudioModal, setShowAudioModal] = useState(false);
  const [editingAudio, setEditingAudio] = useState(null);
  const [audioFormData, setAudioFormData] = useState({
    titulo: '',
    descricao: '',
    disciplina: '',
    colecao_id: '',
    ordem: 0,
    audio_url: '',
    duracao_segundos: null,
    tags: []
  });
  const [uploadingAudio, setUploadingAudio] = useState(false);

  // Modal de coleção
  const [showColecaoModal, setShowColecaoModal] = useState(false);
  const [editingColecao, setEditingColecao] = useState(null);
  const [colecaoFormData, setColecaoFormData] = useState({
    titulo: '',
    descricao: '',
    disciplina: '',
    ordem: 0,
    ativa: true
  });

  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const [audiosData, colecoesData, filtrosData] = await Promise.all([
        LegislacaoAudio.list('-created_date', 200),
        ColecaoLegislacaoAudio.list('ordem', 100),
        FiltroQuestao.list('-created_date', 100)
      ]);
      
      setAudios(audiosData);
      setColecoes(colecoesData);
      setFiltrosDisponiveis(filtrosData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar dados.');
    } finally {
      setIsLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = filtrosDisponiveis.map(f => f.disciplina);
    return [...new Set(disciplinas)].sort();
  }, [filtrosDisponiveis]);

  const audiosFiltrados = React.useMemo(() => {
    return audios.filter(a => {
      const matchDisciplina = filtroDisciplina === "all" || a.disciplina === filtroDisciplina;
      const matchColecao = filtroColecao === "all" || a.colecao_id === filtroColecao;
      const matchBusca = !filtroBusca || 
        a.titulo?.toLowerCase().includes(filtroBusca.toLowerCase());
      return matchDisciplina && matchColecao && matchBusca;
    });
  }, [audios, filtroDisciplina, filtroColecao, filtroBusca]);

  // Funções de Áudio
  const resetAudioForm = useCallback(() => {
    setAudioFormData({
      titulo: '',
      descricao: '',
      disciplina: '',
      colecao_id: '',
      ordem: 0,
      audio_url: '',
      duracao_segundos: null,
      tags: []
    });
    setEditingAudio(null);
  }, []);

  const handleNovoAudio = useCallback(() => {
    resetAudioForm();
    setShowAudioModal(true);
  }, [resetAudioForm]);

  const handleEditarAudio = useCallback((audio) => {
    setEditingAudio(audio);
    setAudioFormData({
      titulo: audio.titulo || '',
      descricao: audio.descricao || '',
      disciplina: audio.disciplina || '',
      colecao_id: audio.colecao_id || '',
      ordem: audio.ordem || 0,
      audio_url: audio.audio_url || '',
      duracao_segundos: audio.duracao_segundos || null,
      tags: audio.tags || []
    });
    setShowAudioModal(true);
  }, []);

  const handleUploadAudio = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('audio/')) {
      toast.error('Por favor, selecione um arquivo de áudio válido.');
      return;
    }

    setUploadingAudio(true);
    try {
      const { data } = await base44.integrations.Core.UploadFile({ file });
      setAudioFormData(prev => ({ ...prev, audio_url: data.file_url }));
      
      // Tentar obter duração do áudio
      const audioElement = new Audio(data.file_url);
      audioElement.onloadedmetadata = () => {
        setAudioFormData(prev => ({ 
          ...prev, 
          duracao_segundos: Math.round(audioElement.duration) 
        }));
      };
      
      toast.success('Áudio enviado com sucesso!');
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      toast.error('Erro ao enviar áudio.');
    } finally {
      setUploadingAudio(false);
    }
  };

  const handleSalvarAudio = useCallback(async () => {
    if (!audioFormData.titulo || !audioFormData.audio_url) {
      toast.error('Preencha o título e faça upload do áudio.');
      return;
    }

    setSalvando(true);
    try {
      if (editingAudio) {
        await LegislacaoAudio.update(editingAudio.id, audioFormData);
        toast.success('Áudio atualizado com sucesso!');
      } else {
        await LegislacaoAudio.create(audioFormData);
        toast.success('Áudio criado com sucesso!');
      }

      setShowAudioModal(false);
      resetAudioForm();
      carregarDados();

    } catch (error) {
      console.error('Erro ao salvar áudio:', error);
      toast.error('Erro ao salvar áudio.');
    } finally {
      setSalvando(false);
    }
  }, [audioFormData, editingAudio, resetAudioForm]);

  const handleExcluirAudio = useCallback(async (audioId) => {
    if (!confirm('Tem certeza que deseja excluir este áudio? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await LegislacaoAudio.delete(audioId);
      toast.success('Áudio excluído com sucesso!');
      carregarDados();
    } catch (error) {
      console.error('Erro ao excluir áudio:', error);
      toast.error('Erro ao excluir áudio.');
    }
  }, []);

  // Funções de Coleção
  const resetColecaoForm = useCallback(() => {
    setColecaoFormData({
      titulo: '',
      descricao: '',
      disciplina: '',
      ordem: 0,
      ativa: true
    });
    setEditingColecao(null);
  }, []);

  const handleNovaColecao = useCallback(() => {
    resetColecaoForm();
    setShowColecaoModal(true);
  }, [resetColecaoForm]);

  const handleEditarColecao = useCallback((colecao) => {
    setEditingColecao(colecao);
    setColecaoFormData({
      titulo: colecao.titulo || '',
      descricao: colecao.descricao || '',
      disciplina: colecao.disciplina || '',
      ordem: colecao.ordem || 0,
      ativa: colecao.ativa !== false
    });
    setShowColecaoModal(true);
  }, []);

  const handleSalvarColecao = useCallback(async () => {
    if (!colecaoFormData.titulo) {
      toast.error('Preencha o título da coleção.');
      return;
    }

    setSalvando(true);
    try {
      if (editingColecao) {
        await ColecaoLegislacaoAudio.update(editingColecao.id, colecaoFormData);
        toast.success('Coleção atualizada com sucesso!');
      } else {
        await ColecaoLegislacaoAudio.create(colecaoFormData);
        toast.success('Coleção criada com sucesso!');
      }

      setShowColecaoModal(false);
      resetColecaoForm();
      carregarDados();

    } catch (error) {
      console.error('Erro ao salvar coleção:', error);
      toast.error('Erro ao salvar coleção.');
    } finally {
      setSalvando(false);
    }
  }, [colecaoFormData, editingColecao, resetColecaoForm]);

  const handleExcluirColecao = useCallback(async (colecaoId) => {
    const audiosNaColecao = audios.filter(a => a.colecao_id === colecaoId);
    if (audiosNaColecao.length > 0) {
      toast.error(`Não é possível excluir esta coleção pois ela contém ${audiosNaColecao.length} áudio(s).`);
      return;
    }

    if (!confirm('Tem certeza que deseja excluir esta coleção?')) {
      return;
    }

    try {
      await ColecaoLegislacaoAudio.delete(colecaoId);
      toast.success('Coleção excluída com sucesso!');
      carregarDados();
    } catch (error) {
      console.error('Erro ao excluir coleção:', error);
      toast.error('Erro ao excluir coleção.');
    }
  }, [audios]);

  const getColecaoNome = (colecaoId) => {
    const colecao = colecoes.find(c => c.id === colecaoId);
    return colecao?.titulo || 'Sem coleção';
  };

  return (
    <>
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-white/60 backdrop-blur-sm">
          <TabsTrigger value="audios" className="gap-2">
            <Music className="w-4 h-4" />
            Áudios
          </TabsTrigger>
          <TabsTrigger value="colecoes" className="gap-2">
            <Folder className="w-4 h-4" />
            Coleções
          </TabsTrigger>
        </TabsList>

        {/* Tab de Áudios */}
        <TabsContent value="audios" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">
              Gerenciamento de Áudios
            </h3>
            <Button onClick={handleNovoAudio} className="gap-2">
              <Plus className="w-4 h-4" />
              Novo Áudio
            </Button>
          </div>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="space-y-6">
              {/* Filtros */}
              <div className="grid md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Disciplina</label>
                  <Select value={filtroDisciplina} onValueChange={setFiltroDisciplina}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      {disciplinasUnicas.map(d => (
                        <SelectItem key={d} value={d}>{d}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">Coleção</label>
                  <Select value={filtroColecao} onValueChange={setFiltroColecao}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      {colecoes.map(c => (
                        <SelectItem key={c.id} value={c.id}>{c.titulo}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <label className="text-sm font-medium text-slate-700">Buscar</label>
                  <Input
                    placeholder="Digite o título do áudio..."
                    value={filtroBusca}
                    onChange={(e) => setFiltroBusca(e.target.value)}
                  />
                </div>
              </div>

              {/* Lista de Áudios */}
              {isLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
                  <p className="text-slate-600">Carregando áudios...</p>
                </div>
              ) : audiosFiltrados.length === 0 ? (
                <div className="text-center py-12">
                  <Headphones className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">
                    Nenhum áudio encontrado
                  </h3>
                  <p className="text-slate-600 mb-4">
                    {filtroDisciplina || filtroColecao || filtroBusca
                      ? "Tente ajustar os filtros de busca"
                      : "Nenhum áudio cadastrado ainda."}
                  </p>
                </div>
              ) : (
                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {audiosFiltrados.map((audio) => (
                    <Card key={audio.id} className="bg-slate-50 border border-slate-200">
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1 space-y-2">
                            <div className="flex items-center gap-2">
                              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                                <Headphones className="w-5 h-5 text-white" />
                              </div>
                              <div>
                                <h4 className="font-semibold text-slate-800">{audio.titulo}</h4>
                                {audio.descricao && (
                                  <p className="text-sm text-slate-600 line-clamp-1">{audio.descricao}</p>
                                )}
                              </div>
                            </div>

                            <div className="flex flex-wrap gap-2">
                              {audio.colecao_id && (
                                <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                                  <Folder className="w-3 h-3 mr-1" />
                                  {getColecaoNome(audio.colecao_id)}
                                </Badge>
                              )}
                              {audio.disciplina && (
                                <Badge variant="outline">
                                  {audio.disciplina}
                                </Badge>
                              )}
                              {audio.duracao_segundos && (
                                <Badge variant="outline" className="text-xs">
                                  {Math.floor(audio.duracao_segundos / 60)}:{String(audio.duracao_segundos % 60).padStart(2, '0')}
                                </Badge>
                              )}
                              {audio.ordem !== undefined && audio.ordem !== 0 && (
                                <Badge variant="outline" className="text-xs">
                                  Ordem: {audio.ordem}
                                </Badge>
                              )}
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEditarAudio(audio)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => handleExcluirAudio(audio.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab de Coleções */}
        <TabsContent value="colecoes" className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-slate-800">
              Gerenciamento de Coleções
            </h3>
            <Button onClick={handleNovaColecao} className="gap-2">
              <Plus className="w-4 h-4" />
              Nova Coleção
            </Button>
          </div>

          <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
            <CardContent className="space-y-6">
              {isLoading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-600 border-t-transparent mx-auto mb-4"></div>
                  <p className="text-slate-600">Carregando coleções...</p>
                </div>
              ) : colecoes.length === 0 ? (
                <div className="text-center py-12">
                  <Folder className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                  <h3 className="text-xl font-semibold text-slate-800 mb-2">
                    Nenhuma coleção cadastrada
                  </h3>
                  <p className="text-slate-600 mb-4">
                    Crie coleções para organizar seus áudios
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  {colecoes.map((colecao) => {
                    const audiosNaColecao = audios.filter(a => a.colecao_id === colecao.id);
                    return (
                      <Card key={colecao.id} className="bg-slate-50 border border-slate-200">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1 space-y-2">
                              <div className="flex items-center gap-2">
                                <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg flex items-center justify-center">
                                  <Folder className="w-5 h-5 text-white" />
                                </div>
                                <div>
                                  <h4 className="font-semibold text-slate-800">{colecao.titulo}</h4>
                                  {colecao.descricao && (
                                    <p className="text-sm text-slate-600 line-clamp-1">{colecao.descricao}</p>
                                  )}
                                </div>
                              </div>

                              <div className="flex flex-wrap gap-2">
                                {colecao.disciplina && (
                                  <Badge variant="outline">
                                    {colecao.disciplina}
                                  </Badge>
                                )}
                                <Badge variant="outline">
                                  <List className="w-3 h-3 mr-1" />
                                  {audiosNaColecao.length} áudios
                                </Badge>
                                {colecao.ordem !== undefined && colecao.ordem !== 0 && (
                                  <Badge variant="outline" className="text-xs">
                                    Ordem: {colecao.ordem}
                                  </Badge>
                                )}
                                <Badge className={colecao.ativa ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                                  {colecao.ativa ? 'Ativa' : 'Inativa'}
                                </Badge>
                              </div>
                            </div>

                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleEditarColecao(colecao)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleExcluirColecao(colecao.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Modal de Áudio */}
      <Dialog open={showAudioModal} onOpenChange={setShowAudioModal}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Headphones className="w-5 h-5" />
              {editingAudio ? 'Editar Áudio' : 'Novo Áudio'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Título *</Label>
                <Input
                  value={audioFormData.titulo}
                  onChange={(e) => setAudioFormData(prev => ({ ...prev, titulo: e.target.value }))}
                  placeholder="Ex: CF/88 - Título I"
                />
              </div>

              <div className="space-y-2">
                <Label>Coleção</Label>
                <Select
                  value={audioFormData.colecao_id}
                  onValueChange={(value) => setAudioFormData(prev => ({ ...prev, colecao_id: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a coleção" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>Sem coleção</SelectItem>
                    {colecoes.filter(c => c.ativa).map(c => (
                      <SelectItem key={c.id} value={c.id}>{c.titulo}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Disciplina</Label>
                <Select
                  value={audioFormData.disciplina}
                  onValueChange={(value) => setAudioFormData(prev => ({ ...prev, disciplina: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a disciplina" />
                  </SelectTrigger>
                  <SelectContent>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Ordem na coleção</Label>
                <Input
                  type="number"
                  value={audioFormData.ordem}
                  onChange={(e) => setAudioFormData(prev => ({ ...prev, ordem: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={audioFormData.descricao}
                onChange={(e) => setAudioFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Breve descrição do áudio..."
                className="h-20"
              />
            </div>

            <div className="space-y-2">
              <Label>Arquivo de Áudio *</Label>
              <div className="flex gap-2">
                <Input
                  type="file"
                  accept="audio/*"
                  onChange={handleUploadAudio}
                  disabled={uploadingAudio}
                  className="flex-1"
                />
                {uploadingAudio && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-purple-600 border-t-transparent"></div>
                    Enviando...
                  </div>
                )}
              </div>
              {audioFormData.audio_url && (
                <div className="mt-2 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-700">✓ Áudio carregado com sucesso</p>
                  {audioFormData.duracao_segundos && (
                    <p className="text-xs text-green-600 mt-1">
                      Duração: {Math.floor(audioFormData.duracao_segundos / 60)}:{String(audioFormData.duracao_segundos % 60).padStart(2, '0')}
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAudioModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarAudio} disabled={salvando}>
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingAudio ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Coleção */}
      <Dialog open={showColecaoModal} onOpenChange={setShowColecaoModal}>
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Folder className="w-5 h-5" />
              {editingColecao ? 'Editar Coleção' : 'Nova Coleção'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label>Título *</Label>
              <Input
                value={colecaoFormData.titulo}
                onChange={(e) => setColecaoFormData(prev => ({ ...prev, titulo: e.target.value }))}
                placeholder="Ex: Constituição Federal de 1988"
              />
            </div>

            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={colecaoFormData.descricao}
                onChange={(e) => setColecaoFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Breve descrição da coleção..."
                className="h-20"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Disciplina</Label>
                <Select
                  value={colecaoFormData.disciplina}
                  onValueChange={(value) => setColecaoFormData(prev => ({ ...prev, disciplina: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a disciplina" />
                  </SelectTrigger>
                  <SelectContent>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Ordem de exibição</Label>
                <Input
                  type="number"
                  value={colecaoFormData.ordem}
                  onChange={(e) => setColecaoFormData(prev => ({ ...prev, ordem: parseInt(e.target.value) || 0 }))}
                  placeholder="0"
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
              <Label className="mb-0">Coleção ativa</Label>
              <input
                type="checkbox"
                checked={colecaoFormData.ativa}
                onChange={(e) => setColecaoFormData(prev => ({ ...prev, ativa: e.target.checked }))}
                className="w-5 h-5"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowColecaoModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarColecao} disabled={salvando}>
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingColecao ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}