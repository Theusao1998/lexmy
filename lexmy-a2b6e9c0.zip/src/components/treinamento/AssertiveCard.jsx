import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Edit3, Save, X, Trash2, BookOpen } from "lucide-react";

export default function AssertiveCard({ 
  assertiva, 
  editando, 
  onEdit, 
  onSave, 
  onCancel, 
  onDelete 
}) {
  const [dadosEdicao, setDadosEdicao] = useState({
    topico: assertiva.topico || "",
    texto_certo: assertiva.texto_certo || "",
    texto_errado: assertiva.texto_errado || "",
    fundamentacao_literal: assertiva.fundamentacao_literal || "",
    exemplo_pratico: assertiva.exemplo_pratico || "",
    resumo: assertiva.resumo || ""
  });

  const handleSave = () => {
    onSave(dadosEdicao);
  };

  const handleCancel = () => {
    // Resetar dados de edição
    setDadosEdicao({
      topico: assertiva.topico || "",
      texto_certo: assertiva.texto_certo || "",
      texto_errado: assertiva.texto_errado || "",
      fundamentacao_literal: assertiva.fundamentacao_literal || "",
      exemplo_pratico: assertiva.exemplo_pratico || "",
      resumo: assertiva.resumo || ""
    });
    onCancel();
  };

  if (editando) {
    return (
      <Card className="bg-blue-50 border-blue-200">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Edit3 className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-700">Editando Assertiva</span>
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                <Save className="w-4 h-4 mr-1" /> Salvar
              </Button>
              <Button size="sm" variant="outline" onClick={handleCancel}>
                <X className="w-4 h-4 mr-1" /> Cancelar
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Tópico */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Tópico</label>
            <Input
              value={dadosEdicao.topico}
              onChange={(e) => setDadosEdicao({...dadosEdicao, topico: e.target.value})}
              placeholder="Tópico específico da assertiva"
            />
          </div>

          {/* Texto Certo */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Versão Correta</label>
            <Textarea
              value={dadosEdicao.texto_certo}
              onChange={(e) => setDadosEdicao({...dadosEdicao, texto_certo: e.target.value})}
              placeholder="Versão correta da assertiva"
              className="min-h-20"
            />
          </div>

          {/* Texto Errado */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Versão Incorreta</label>
            <Textarea
              value={dadosEdicao.texto_errado}
              onChange={(e) => setDadosEdicao({...dadosEdicao, texto_errado: e.target.value})}
              placeholder="Versão incorreta da assertiva"
              className="min-h-20"
            />
          </div>

          {/* Fundamentação */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Fundamentação Legal</label>
            <Textarea
              value={dadosEdicao.fundamentacao_literal}
              onChange={(e) => setDadosEdicao({...dadosEdicao, fundamentacao_literal: e.target.value})}
              placeholder="Base legal literal com citações"
              className="min-h-24"
            />
          </div>

          {/* Exemplo Prático */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Exemplo Prático</label>
            <Textarea
              value={dadosEdicao.exemplo_pratico}
              onChange={(e) => setDadosEdicao({...dadosEdicao, exemplo_pratico: e.target.value})}
              placeholder="Exemplo prático que ilustra o conceito"
              className="min-h-20"
            />
          </div>

          {/* Resumo */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">Resumo</label>
            <Textarea
              value={dadosEdicao.resumo}
              onChange={(e) => setDadosEdicao({...dadosEdicao, resumo: e.target.value})}
              placeholder="Resumo em tópicos"
              className="min-h-20"
            />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white border-slate-200 hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-slate-600" />
              <CardTitle className="text-base">{assertiva.topico}</CardTitle>
            </div>
            <div className="flex gap-2">
              <Badge variant="outline" className="text-xs">
                {assertiva.disciplina}
              </Badge>
              {assertiva.conteudo && (
                <Badge variant="outline" className="text-xs">
                  {assertiva.conteudo}
                </Badge>
              )}
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline" onClick={onEdit}>
              <Edit3 className="w-4 h-4 mr-1" /> Editar
            </Button>
            <Button size="sm" variant="outline" className="text-red-600 border-red-200 hover:bg-red-50" onClick={onDelete}>
              <Trash2 className="w-4 h-4 mr-1" /> Excluir
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Versões da Assertiva */}
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-green-700">Versão Correta:</h4>
            <p className="text-sm text-slate-700 p-3 bg-green-50 rounded border border-green-200">
              {assertiva.texto_certo}
            </p>
          </div>
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-red-700">Versão Incorreta:</h4>
            <p className="text-sm text-slate-700 p-3 bg-red-50 rounded border border-red-200">
              {assertiva.texto_errado}
            </p>
          </div>
        </div>

        {/* Fundamentação (preview) */}
        {assertiva.fundamentacao_literal && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-700">Fundamentação:</h4>
            <p className="text-xs text-slate-600 line-clamp-2">
              {assertiva.fundamentacao_literal}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}