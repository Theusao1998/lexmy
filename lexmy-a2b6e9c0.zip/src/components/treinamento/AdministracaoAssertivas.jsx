import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  CheckCircle2,
  AlertCircle,
  Loader2,
  Plus,
  FileText,
  Trash2,
  ListOrdered,
  ClipboardList
} from "lucide-react";
import { Assertiva } from "@/api/entities";
import { FiltroQuestao } from "@/api/entities";
import { User } from "@/api/entities";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function AdministracaoQuestoes() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [filtros, setFiltros] = useState([]);
  const [questoes, setQuestoes] = useState([]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  // Estados do formulário de questão
  const [novaQuestao, setNovaQuestao] = useState({
    disciplina: "",
    conteudo: "",
    topico: "",
    assertiva: "",
    resposta_correta: "certo", 
    fundamentacao_literal: "",
  });
  const [salvandoQuestao, setSalvandoQuestao] = useState(false);
  const [ultimoSalvamento, setUltimoSalvamento] = useState(null);

  // NOVO: Estado para busca
  const [buscaQuestoes, setBuscaQuestoes] = useState("");

  // NOVO: Função para gerar código único para questões
  const gerarCodigoQuestao = () => {
    const timestamp = Date.now().toString().slice(-6);
    const random = Math.random().toString(36).substr(2, 4).toUpperCase();
    return `T${timestamp}${random}`;
  };

  const carregarQuestoes = useCallback(async () => {
    try {
      const data = await Assertiva.list('-created_date', 50);
      setQuestoes(data);
    } catch (error) {
      console.error("Erro ao carregar questões:", error);
    }
  }, []);

  const carregarFiltros = useCallback(async () => {
    try {
      const data = await FiltroQuestao.list('-created_date', 200);
      setFiltros(data);
    } catch (error) {
      console.error('Erro ao carregar filtros:', error);
    }
  }, []);

  const verificarPermissoes = useCallback(async () => {
    setIsLoading(true);
    try {
      const me = await User.me();
      setIsAdmin(me.role === "admin");
      
      if (me.role === "admin") {
        await Promise.all([
          carregarQuestoes(),
          carregarFiltros()
        ]);
      }
    } catch (error) {
      console.error('Erro ao verificar permissões:', error);
      setIsAdmin(false);
    }
    setIsLoading(false);
  }, [carregarQuestoes, carregarFiltros]);

  useEffect(() => {
    verificarPermissoes();
  }, [verificarPermissoes]);

  const disciplinasUnicas = useMemo(() => {
    if (!filtros) return [];
    return [...new Set(filtros.map(f => f.disciplina))].sort();
  }, [filtros]);

  const opcoesConteudoManual = useMemo(() => {
    if (!novaQuestao.disciplina || !filtros) return [];
    return filtros
      .filter(f => f.disciplina === novaQuestao.disciplina)
      .map(f => f.conteudo)
      .sort();
  }, [novaQuestao.disciplina, filtros]);

  const salvarQuestao = async () => {
    // Validações
    if (!novaQuestao.disciplina || !novaQuestao.conteudo || !novaQuestao.topico) {
      alert("Por favor, preencha disciplina, conteúdo e tópico.");
      return;
    }
    if (!novaQuestao.assertiva) {
      alert("Por favor, preencha o texto da questão.");
      return;
    }
    if (!novaQuestao.fundamentacao_literal) {
      alert("Por favor, preencha a fundamentação literal.");
      return;
    }

    setSalvandoQuestao(true);
    
    try {
      await Assertiva.create({
        codigo: gerarCodigoQuestao(),
        disciplina: novaQuestao.disciplina,
        conteudo: novaQuestao.conteudo,
        topico: novaQuestao.topico,
        assertiva: novaQuestao.assertiva,
        resposta_correta: novaQuestao.resposta_correta,
        fundamentacao_literal: novaQuestao.fundamentacao_literal,
      });
      
      setUltimoSalvamento({
        sucesso: true,
        timestamp: new Date(),
        topico: novaQuestao.topico
      });

      // Limpar formulário
      setNovaQuestao({
        disciplina: "",
        conteudo: "",
        topico: "",
        assertiva: "",
        resposta_correta: "certo",
        fundamentacao_literal: "",
      });

      setIsDialogOpen(false);
      await carregarQuestoes();

    } catch (error) {
      console.error('Erro ao salvar questão:', error);
      setUltimoSalvamento({
        sucesso: false,
        erro: error.message || String(error),
        timestamp: new Date()
      });
    } finally {
      setSalvandoQuestao(false);
    }
  };

  const deletarQuestao = async (id) => {
    if (!window.confirm("Tem certeza que deseja excluir esta questão? Esta ação não pode ser desfeita.")) {
      return;
    }
    try {
      await Assertiva.delete(id);
      await carregarQuestoes();
    } catch (error) {
      console.error("Erro ao deletar questão:", error);
      alert("Falha ao excluir a questão.");
    }
  };

  // NOVO: Filtrar questões por busca
  const questoesFiltradas = useMemo(() => {
    if (!questoes) return [];
    const termoBusca = buscaQuestoes.toLowerCase();
    return questoes.filter(questao => {
      return (
        questao.codigo?.toLowerCase().includes(termoBusca) ||
        questao.topico?.toLowerCase().includes(termoBusca) ||
        questao.assertiva?.toLowerCase().includes(termoBusca) ||
        questao.disciplina?.toLowerCase().includes(termoBusca) ||
        questao.conteudo?.toLowerCase().includes(termoBusca)
      );
    });
  }, [questoes, buscaQuestoes]);

  if (isLoading) {
    return (
      <div className="p-4">
        <Card className="bg-gradient-to-r from-blue-50 to-indigo-50/50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
              <span className="text-blue-800">Verificando permissões...</span>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!isAdmin) {
    return null;
  }

  return (
    <div className="space-y-6 p-4">
      {/* Botão Adicionar Nova Questão */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <Button 
          onClick={() => setIsDialogOpen(true)}
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 gap-2"
        >
          <Plus className="w-4 h-4" />
          Adicionar Nova Questão
        </Button>
        
        <DialogContent className="sm:max-w-xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3 text-blue-800">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-500 rounded-lg">
                <FileText className="w-5 h-5 text-white" />
              </div>
              Adicionar Nova Questão
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6 py-4 max-h-[70vh] overflow-y-auto px-1">
            {/* Filtros Básicos */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">
                  Disciplina *
                </label>
                <Select value={novaQuestao.disciplina} onValueChange={(value) => 
                  setNovaQuestao({...novaQuestao, disciplina: value, conteudo: ""}) 
                }>
                  <SelectTrigger>
                    <SelectValue placeholder="Escolha a disciplina..." />
                  </SelectTrigger>
                  <SelectContent>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {novaQuestao.disciplina && ( 
                <div className="space-y-2">
                  <label className="text-sm font-medium text-slate-700">
                    Conteúdo / Submatéria *
                  </label>
                  <Select value={novaQuestao.conteudo} onValueChange={(value) => 
                    setNovaQuestao({...novaQuestao, conteudo: value}) 
                  }>
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha o conteúdo..." />
                    </SelectTrigger>
                    <SelectContent>
                      {opcoesConteudoManual.map((item) => (
                        <SelectItem key={item} value={item}>{item}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            {/* Tópico */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">
                Tópico Específico *
              </label>
              <Input
                placeholder="Ex: Requisitos para Demissão por Justa Causa"
                value={novaQuestao.topico} 
                onChange={(e) => setNovaQuestao({...novaQuestao, topico: e.target.value})} 
              />
            </div>

            {/* Questão */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">
                Texto da Questão *
              </label>
              <Textarea
                placeholder="Escreva o texto da questão..."
                value={novaQuestao.assertiva} 
                onChange={(e) => setNovaQuestao({...novaQuestao, assertiva: e.target.value})} 
                className="min-h-[120px]"
              />
            </div>

            {/* Resposta Correta */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">
                Esta questão está: *
              </label>
              <Select value={novaQuestao.resposta_correta} onValueChange={(value) => 
                setNovaQuestao({...novaQuestao, resposta_correta: value}) 
              }>
                <SelectTrigger className="w-48">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="certo">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                      <span>Certa</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="errado">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <span>Errada</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-slate-500">
                Indique se a questão acima está correta ou incorreta conforme a legislação.
              </p>
            </div>

            {/* Fundamentação */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700">
                Fundamentação Literal *
              </label>
              <Textarea
                placeholder="Base legal com citações precisas de dispositivos..."
                value={novaQuestao.fundamentacao_literal} 
                onChange={(e) => setNovaQuestao({...novaQuestao, fundamentacao_literal: e.target.value})} 
                className="min-h-[100px]"
              />
            </div>

            {/* Botão de Salvar */}
            <div className="flex justify-end pt-4">
              <Button
                onClick={salvarQuestao} 
                disabled={salvandoQuestao} 
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 gap-2"
              >
                {salvandoQuestao ? ( 
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Salvando...
                  </>
                ) : (
                  <>
                    <Plus className="w-4 h-4" />
                    Salvar Questão
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Campo de busca */}
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-lg">
            <div className="p-2 bg-gradient-to-br from-slate-500 to-slate-600 rounded-lg">
              <ClipboardList className="w-5 h-5 text-white" />
            </div>
            Buscar Questões
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            <Input
              placeholder="Busque por código, tópico, disciplina ou texto da questão..."
              value={buscaQuestoes}
              onChange={(e) => setBuscaQuestoes(e.target.value)}
              className="pl-4"
            />
            {buscaQuestoes && (
              <p className="text-sm text-slate-500 mt-2">
                Encontradas {questoesFiltradas.length} questões
              </p>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Resultado do Último Salvamento */}
      {ultimoSalvamento && (
        <div className="mt-6">
          {ultimoSalvamento.sucesso ? (
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span className="font-semibold text-green-800">
                  Questão salva com sucesso!
                </span>
              </div>
              <p className="text-sm text-green-700">
                Tópico: {ultimoSalvamento.topico}
              </p>
              <p className="text-xs text-green-600 mt-1">
                {ultimoSalvamento.timestamp.toLocaleString('pt-BR')}
              </p>
            </div>
          ) : (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <AlertCircle className="w-5 h-5 text-red-600" />
                <span className="font-semibold text-red-800">
                  Erro ao salvar
                </span>
              </div>
              <p className="text-sm text-red-700">{ultimoSalvamento.erro}</p>
              <p className="text-xs text-red-600 mt-1">
                {ultimoSalvamento.timestamp.toLocaleString('pt-BR')}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Lista de Questões Cadastradas */}
      <Card className="bg-white/50 border-0 shadow-lg mt-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <ListOrdered className="w-5 h-5 text-slate-600" />
            Questões Cadastradas ({questoesFiltradas.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 max-h-96 overflow-y-auto pr-2">
            {questoesFiltradas.length > 0 ? ( 
              questoesFiltradas.map(questao => ( 
                <div key={questao.id} className="p-4 border rounded-lg bg-slate-50 relative group">
                  {/* Código da questão */}
                  <div className="flex items-start justify-between mb-2">
                    <div className="text-sm font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded border">
                      {questao.codigo || 'SEM CÓDIGO'}
                    </div>
                    <div className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                      (questao.resposta_correta || '').toLowerCase() === 'certo' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-red-100 text-red-700'
                    }`}>
                      {String(questao.resposta_correta || '').toUpperCase()}
                    </div>
                  </div>

                  <p className="font-semibold text-slate-800 pr-10 mb-2">{questao.assertiva}</p>
                  <div className="text-xs text-slate-500 mt-2 flex items-center gap-4 flex-wrap">
                    <span><strong>Disciplina:</strong> {questao.disciplina}</span>
                    <span><strong>Conteúdo:</strong> {questao.conteudo}</span>
                    <span><strong>Tópico:</strong> {questao.topico}</span>
                  </div>
                  
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="absolute bottom-2 right-2 h-8 w-8 text-slate-400 hover:bg-red-100 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => deletarQuestao(questao.id)} 
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))
            ) : (
              <p className="text-center text-slate-500 py-8">
                {buscaQuestoes ? 'Nenhuma questão encontrada para essa busca.' : 'Nenhuma questão cadastrada ainda.'}
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}