import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  FileText,
  Clock,
  Target,
  CheckCircle2
} from "lucide-react";
import { QuestaoDiscursiva } from "@/api/entities";
import { FiltroQuestao } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

export default function AdministracaoDiscursivas() {
  const [questoes, setQuestoes] = useState([]);
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filtros
  const [filtroDisciplina, setFiltroDisciplina] = useState("all");
  const [filtroStatus, setFiltroStatus] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Modal de criação/edição
  const [showModal, setShowModal] = useState(false);
  const [editingQuestao, setEditingQuestao] = useState(null);
  const [formData, setFormData] = useState({
    titulo: '',
    disciplina: '',
    conteudo: '',
    enunciado: '',
    resposta_espelho: '',
    pontuacao_maxima: 10,
    dificuldade: 'média',
    tempo_estimado_minutos: 30,
    status: 'rascunho',
    criterios_avaliacao: ''
  });
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const [questoesData, filtrosData] = await Promise.all([
        QuestaoDiscursiva.list('-created_date', 100),
        FiltroQuestao.list('-created_date', 100)
      ]);
      
      setQuestoes(questoesData);
      setFiltrosDisponiveis(filtrosData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar questões.');
    } finally {
      setIsLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = filtrosDisponiveis.map(f => f.disciplina);
    return [...new Set(disciplinas)].sort();
  }, [filtrosDisponiveis]);

  const opcoesConteudo = React.useMemo(() => {
    if (!formData.disciplina) return [];
    return filtrosDisponiveis
      .filter(f => f.disciplina === formData.disciplina)
      .map(f => f.conteudo)
      .sort();
  }, [filtrosDisponiveis, formData.disciplina]);

  const questoesFiltradas = React.useMemo(() => {
    return questoes.filter(q => {
      const matchDisciplina = filtroDisciplina === "all" || q.disciplina === filtroDisciplina;
      const matchStatus = filtroStatus === "all" || q.status === filtroStatus;
      const matchBusca = !filtroBusca || 
        q.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        q.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase());
      return matchDisciplina && matchStatus && matchBusca;
    });
  }, [questoes, filtroDisciplina, filtroStatus, filtroBusca]);

  const resetForm = useCallback(() => {
    setFormData({
      titulo: '',
      disciplina: '',
      conteudo: '',
      enunciado: '',
      resposta_espelho: '',
      pontuacao_maxima: 10,
      dificuldade: 'média',
      tempo_estimado_minutos: 30,
      status: 'rascunho',
      criterios_avaliacao: ''
    });
    setEditingQuestao(null);
  }, []);

  const handleNovaQuestao = useCallback(() => {
    resetForm();
    setShowModal(true);
  }, [resetForm]);

  const handleEditarQuestao = useCallback((questao) => {
    setEditingQuestao(questao);
    setFormData({
      titulo: questao.titulo || '',
      disciplina: questao.disciplina || '',
      conteudo: questao.conteudo || '',
      enunciado: questao.enunciado || '',
      resposta_espelho: questao.resposta_espelho || '',
      pontuacao_maxima: questao.pontuacao_maxima || 10,
      dificuldade: questao.dificuldade || 'média',
      tempo_estimado_minutos: questao.tempo_estimado_minutos || 30,
      status: questao.status || 'rascunho',
      criterios_avaliacao: questao.criterios_avaliacao || ''
    });
    setShowModal(true);
  }, []);

  const handleSalvarQuestao = useCallback(async () => {
    if (!formData.titulo || !formData.disciplina || !formData.enunciado || !formData.resposta_espelho) {
      toast.error('Preencha todos os campos obrigatórios.');
      return;
    }

    setSalvando(true);
    try {
      if (editingQuestao) {
        await QuestaoDiscursiva.update(editingQuestao.id, formData);
        toast.success('Questão atualizada com sucesso!');
      } else {
        await QuestaoDiscursiva.create(formData);
        toast.success('Questão criada com sucesso!');
      }
      setShowModal(false);
      resetForm();
      await carregarDados();
    } catch (error) {
      console.error('Erro ao salvar questão:', error);
      toast.error('Erro ao salvar questão.');
    } finally {
      setSalvando(false);
    }
  }, [formData, editingQuestao, resetForm]);

  const handleExcluirQuestao = useCallback(async (id) => {
    if (!confirm('Tem certeza que deseja excluir esta questão?')) return;

    try {
      await QuestaoDiscursiva.delete(id);
      toast.success('Questão excluída com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao excluir questão:', error);
      toast.error('Erro ao excluir questão.');
    }
  }, []);

  const handlePublicarQuestao = useCallback(async (questao) => {
    if (!confirm('Publicar esta questão? Ela ficará disponível para os estudantes.')) {
      return;
    }

    try {
      await QuestaoDiscursiva.update(questao.id, {
        ...questao,
        status: 'publicada'
      });
      toast.success('Questão publicada com sucesso!');
      await carregarDados();
    } catch (error) {
      console.error('Erro ao publicar questão:', error);
      toast.error('Erro ao publicar questão.');
    }
  }, []);

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Questões Discursivas
          </h3>
          <Button onClick={handleNovaQuestao} className="gap-2">
            <Plus className="w-4 h-4" />
            Nova Questão
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">
            {/* Filtros */}
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Disciplina</label>
                <Select value={filtroDisciplina} onValueChange={setFiltroDisciplina}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as disciplinas</SelectItem>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Status</label>
                <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="publicada">Publicada</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-700">Buscar</label>
                <Input
                  placeholder="Digite o título ou disciplina..."
                  value={filtroBusca}
                  onChange={(e) => setFiltroBusca(e.target.value)}
                />
              </div>
            </div>

            {/* Lista de Questões */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando questões...</p>
              </div>
            ) : questoesFiltradas.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhuma questão encontrada
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtroDisciplina !== "all" || filtroStatus !== "all" || filtroBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhuma questão cadastrada ainda."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {questoesFiltradas.map((questao) => (
                  <Card key={questao.id} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-3">
                            <h4 className="font-semibold text-slate-800">{questao.titulo}</h4>
                            <Badge className={questao.status === 'publicada' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
                              {questao.status === 'publicada' ? 'Publicada' : 'Rascunho'}
                            </Badge>
                            <Badge className={
                              questao.dificuldade === 'fácil' ? 'bg-green-100 text-green-700' :
                              questao.dificuldade === 'média' ? 'bg-amber-100 text-amber-700' :
                              'bg-red-100 text-red-700'
                            }>
                              {questao.dificuldade}
                            </Badge>
                          </div>
                          
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            <span className="flex items-center gap-1">
                              <FileText className="w-3 h-3" />
                              {questao.disciplina}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="w-3 h-3" />
                              {questao.tempo_estimado_minutos}min
                            </span>
                            <span className="flex items-center gap-1">
                              <Target className="w-3 h-3" />
                              {questao.pontuacao_maxima} pts
                            </span>
                          </div>
                        </div>

                        <div className="flex gap-2">
                          {questao.status === 'rascunho' && (
                            <Button
                              size="sm"
                              className="gap-1 bg-green-600 hover:bg-green-700"
                              onClick={() => handlePublicarQuestao(questao)}
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              Publicar
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarQuestao(questao)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirQuestao(questao.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Criar/Editar Questão */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {editingQuestao ? 'Editar Questão' : 'Nova Questão Discursiva'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Título *</Label>
                <Input
                  value={formData.titulo}
                  onChange={(e) => setFormData(prev => ({ ...prev, titulo: e.target.value }))}
                  placeholder="Ex: Princípios da Administração Pública"
                />
              </div>
              <div className="space-y-2">
                <Label>Disciplina *</Label>
                <Select
                  value={formData.disciplina}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, disciplina: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione" />
                  </SelectTrigger>
                  <SelectContent>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Pontuação Máxima *</Label>
                <Input
                  type="number"
                  min="1"
                  value={formData.pontuacao_maxima}
                  onChange={(e) => setFormData(prev => ({ ...prev, pontuacao_maxima: parseInt(e.target.value) }))}
                />
              </div>
              <div className="space-y-2">
                <Label>Dificuldade</Label>
                <Select
                  value={formData.dificuldade}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, dificuldade: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fácil">Fácil</SelectItem>
                    <SelectItem value="média">Média</SelectItem>
                    <SelectItem value="alta">Alta</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Tempo Estimado (min)</Label>
                <Input
                  type="number"
                  min="5"
                  value={formData.tempo_estimado_minutos}
                  onChange={(e) => setFormData(prev => ({ ...prev, tempo_estimado_minutos: parseInt(e.target.value) }))}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Conteúdo/Submatéria</Label>
              <Select
                value={formData.conteudo}
                onValueChange={(value) => setFormData(prev => ({ ...prev, conteudo: value }))}
                disabled={!formData.disciplina || opcoesConteudo.length === 0}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione o conteúdo" />
                </SelectTrigger>
                <SelectContent>
                  {opcoesConteudo.map((item) => (
                    <SelectItem key={item} value={item}>{item}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Enunciado *</Label>
              <Textarea
                value={formData.enunciado}
                onChange={(e) => setFormData(prev => ({ ...prev, enunciado: e.target.value }))}
                placeholder="Digite o enunciado da questão..."
                className="min-h-[120px]"
              />
            </div>

            <div className="space-y-2">
              <Label>Resposta Espelho (Gabarito) *</Label>
              <Textarea
                value={formData.resposta_espelho}
                onChange={(e) => setFormData(prev => ({ ...prev, resposta_espelho: e.target.value }))}
                placeholder="Digite a resposta modelo/gabarito completa..."
                className="min-h-[200px]"
              />
            </div>

            <div className="space-y-2">
              <Label>Critérios de Avaliação (Opcional)</Label>
              <Textarea
                value={formData.criterios_avaliacao}
                onChange={(e) => setFormData(prev => ({ ...prev, criterios_avaliacao: e.target.value }))}
                placeholder="Ex: Deve citar pelo menos 3 princípios, fundamentar com jurisprudência..."
                className="min-h-[100px]"
              />
            </div>

            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rascunho">Rascunho</SelectItem>
                  <SelectItem value="publicada">Publicada</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarQuestao} disabled={salvando}>
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingQuestao ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}