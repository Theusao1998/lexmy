import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  Brain,
  Eye,
  CheckCircle2
} from "lucide-react";
import { MapaMental } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";

export default function AdministracaoMapasMentais() {
  const [mapas, setMapas] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filtros
  const [filtroStatus, setFiltroStatus] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Modal de criação/edição
  const [showModal, setShowModal] = useState(false);
  const [editingMapa, setEditingMapa] = useState(null);
  const [formData, setFormData] = useState({
    titulo: '',
    descricao: '',
    disciplina: '',
    conteudo_renderizado_html: '',
    tags: [],
    status: 'rascunho'
  });
  const [salvando, setSalvando] = useState(false);

  // Preview
  const [showPreview, setShowPreview] = useState(false);

  useEffect(() => {
    carregarMapas();
  }, []);

  const carregarMapas = async () => {
    setIsLoading(true);
    try {
      const data = await MapaMental.list('-created_date', 100);
      setMapas(data);
    } catch (error) {
      console.error('Erro ao carregar mapas mentais:', error);
      toast.error('Erro ao carregar mapas mentais.');
    } finally {
      setIsLoading(false);
    }
  };

  const mapasFiltrados = React.useMemo(() => {
    return mapas.filter(m => {
      const matchStatus = filtroStatus === "all" || m.status === filtroStatus;
      const matchBusca = !filtroBusca || 
        m.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        m.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase());
      return matchStatus && matchBusca;
    });
  }, [mapas, filtroStatus, filtroBusca]);

  const resetForm = useCallback(() => {
    setFormData({
      titulo: '',
      descricao: '',
      disciplina: '',
      conteudo_renderizado_html: '',
      tags: [],
      status: 'rascunho'
    });
    setEditingMapa(null);
  }, []);

  const handleNovoMapa = useCallback(() => {
    resetForm();
    setShowModal(true);
  }, [resetForm]);

  const handleEditarMapa = useCallback((mapa) => {
    setEditingMapa(mapa);
    setFormData({
      titulo: mapa.titulo || '',
      descricao: mapa.descricao || '',
      disciplina: mapa.disciplina || '',
      conteudo_renderizado_html: mapa.conteudo_renderizado_html || '',
      tags: mapa.tags || [],
      status: mapa.status || 'rascunho'
    });
    setShowModal(true);
  }, []);

  const handleSalvarMapa = useCallback(async () => {
    if (!formData.titulo || !formData.conteudo_renderizado_html) {
      toast.error('Preencha o título e o conteúdo HTML.');
      return;
    }

    setSalvando(true);
    try {
      if (editingMapa) {
        await MapaMental.update(editingMapa.id, formData);
        toast.success('Mapa mental atualizado com sucesso!');
      } else {
        await MapaMental.create(formData);
        toast.success('Mapa mental criado com sucesso!');
      }
      setShowModal(false);
      resetForm();
      await carregarMapas();
    } catch (error) {
      console.error('Erro ao salvar mapa mental:', error);
      toast.error('Erro ao salvar mapa mental.');
    } finally {
      setSalvando(false);
    }
  }, [formData, editingMapa, resetForm]);

  const handleExcluirMapa = useCallback(async (id) => {
    if (!confirm('Tem certeza que deseja excluir este mapa mental?')) return;

    try {
      await MapaMental.delete(id);
      toast.success('Mapa mental excluído com sucesso!');
      await carregarMapas();
    } catch (error) {
      console.error('Erro ao excluir mapa mental:', error);
      toast.error('Erro ao excluir mapa mental.');
    }
  }, []);

  const handlePublicarMapa = useCallback(async (mapa) => {
    if (!confirm('Publicar este mapa mental? Ele ficará disponível para os estudantes.')) {
      return;
    }

    try {
      await MapaMental.update(mapa.id, {
        ...mapa,
        status: 'publicado'
      });
      toast.success('Mapa mental publicado com sucesso!');
      await carregarMapas();
    } catch (error) {
      console.error('Erro ao publicar mapa mental:', error);
      toast.error('Erro ao publicar mapa mental.');
    }
  }, []);

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Mapas Mentais
          </h3>
          <Button onClick={handleNovoMapa} className="gap-2 bg-purple-600 hover:bg-purple-700">
            <Plus className="w-4 h-4" />
            Novo Mapa Mental
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">
            {/* Filtros */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Status</label>
                <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="publicado">Publicado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-700">Buscar</label>
                <Input
                  placeholder="Digite o título ou disciplina..."
                  value={filtroBusca}
                  onChange={(e) => setFiltroBusca(e.target.value)}
                />
              </div>
            </div>

            {/* Lista de Mapas */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando mapas mentais...</p>
              </div>
            ) : mapasFiltrados.length === 0 ? (
              <div className="text-center py-12">
                <Brain className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhum mapa mental encontrado
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtroStatus !== "all" || filtroBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhum mapa mental cadastrado ainda."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {mapasFiltrados.map((mapa) => (
                  <Card key={mapa.id} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-3">
                            <h4 className="font-semibold text-slate-800">{mapa.titulo}</h4>
                            <Badge className={mapa.status === 'publicado' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
                              {mapa.status === 'publicado' ? 'Publicado' : 'Rascunho'}
                            </Badge>
                          </div>
                          
                          {mapa.disciplina && (
                            <p className="text-sm text-slate-600">
                              <strong>Disciplina:</strong> {mapa.disciplina}
                            </p>
                          )}
                        </div>

                        <div className="flex gap-2">
                          {mapa.status === 'rascunho' && (
                            <Button
                              size="sm"
                              className="gap-1 bg-green-600 hover:bg-green-700"
                              onClick={() => handlePublicarMapa(mapa)}
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              Publicar
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarMapa(mapa)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirMapa(mapa.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Criar/Editar Mapa Mental */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Brain className="w-5 h-5" />
              {editingMapa ? 'Editar Mapa Mental' : 'Novo Mapa Mental'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Título *</Label>
                <Input
                  value={formData.titulo}
                  onChange={(e) => setFormData(prev => ({ ...prev, titulo: e.target.value }))}
                  placeholder="Ex: Organização do Estado"
                />
              </div>
              <div className="space-y-2">
                <Label>Disciplina</Label>
                <Input
                  value={formData.disciplina}
                  onChange={(e) => setFormData(prev => ({ ...prev, disciplina: e.target.value }))}
                  placeholder="Ex: Direito Constitucional"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={formData.descricao}
                onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Breve descrição do mapa mental..."
                className="h-20"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>Conteúdo HTML *</Label>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setShowPreview(!showPreview)}
                  className="gap-2"
                >
                  <Eye className="w-4 h-4" />
                  {showPreview ? 'Ocultar' : 'Pré-visualizar'}
                </Button>
              </div>
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg mb-2">
                <p className="text-xs text-blue-800 leading-relaxed">
                  <strong>Instruções:</strong> Cole aqui o HTML completo gerado pelo ChatGPT com todo o CSS/JS embutido.
                  O conteúdo será renderizado exatamente como fornecido.
                </p>
              </div>
              <Textarea
                value={formData.conteudo_renderizado_html}
                onChange={(e) => setFormData(prev => ({ ...prev, conteudo_renderizado_html: e.target.value }))}
                placeholder="Cole o HTML completo aqui..."
                className="min-h-[300px] font-mono text-sm"
              />
            </div>

            {showPreview && formData.conteudo_renderizado_html && (
              <div className="space-y-2">
                <Label>Pré-visualização:</Label>
                <div className="border rounded-lg p-4 bg-white max-h-96 overflow-auto">
                  <div dangerouslySetInnerHTML={{ __html: formData.conteudo_renderizado_html }} />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label>Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="rascunho">Rascunho</SelectItem>
                  <SelectItem value="publicado">Publicado</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarMapa} disabled={salvando} className="bg-purple-600 hover:bg-purple-700">
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingMapa ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}