import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  FileImage,
  Upload,
  Eye
} from "lucide-react";
import { Material } from "@/api/entities";
import { FiltroQuestao } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "sonner";
import { base44 } from "@/api/base44Client";

export default function AdministracaoResumos() {
  const [resumos, setResumos] = useState([]);
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  // Filtros
  const [filtroDisciplina, setFiltroDisciplina] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Modal de criação/edição
  const [showModal, setShowModal] = useState(false);
  const [editingResumo, setEditingResumo] = useState(null);
  const [formData, setFormData] = useState({
    titulo: '',
    disciplina: '',
    imagem_url: '',
    tags: [],
    descricao: ''
  });
  const [salvando, setSalvando] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  // Preview de imagem
  const [showPreview, setShowPreview] = useState(false);
  const [previewImage, setPreviewImage] = useState(null);

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    setIsLoading(true);
    try {
      const [materiaisData, filtrosData] = await Promise.all([
        Material.filter({ tipo: 'resumo' }, '-created_date', 200),
        FiltroQuestao.list('-created_date', 100)
      ]);
      
      setResumos(materiaisData);
      setFiltrosDisponiveis(filtrosData);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      toast.error('Erro ao carregar resumos.');
    } finally {
      setIsLoading(false);
    }
  };

  const disciplinasUnicas = React.useMemo(() => {
    const disciplinas = filtrosDisponiveis.map(f => f.disciplina);
    return [...new Set(disciplinas)].sort();
  }, [filtrosDisponiveis]);

  const resumosFiltrados = React.useMemo(() => {
    return resumos.filter(r => {
      const matchDisciplina = filtroDisciplina === "all" || r.disciplina === filtroDisciplina;
      const matchBusca = !filtroBusca || 
        r.titulo?.toLowerCase().includes(filtroBusca.toLowerCase()) ||
        r.disciplina?.toLowerCase().includes(filtroBusca.toLowerCase());
      return matchDisciplina && matchBusca;
    });
  }, [resumos, filtroDisciplina, filtroBusca]);

  const resetForm = useCallback(() => {
    setFormData({
      titulo: '',
      disciplina: '',
      imagem_url: '',
      tags: [],
      descricao: ''
    });
    setEditingResumo(null);
  }, []);

  const handleNovoResumo = useCallback(() => {
    resetForm();
    setShowModal(true);
  }, [resetForm]);

  const handleEditarResumo = useCallback((resumo) => {
    setEditingResumo(resumo);
    setFormData({
      titulo: resumo.titulo || '',
      disciplina: resumo.disciplina || '',
      imagem_url: resumo.imagem_url || '',
      tags: resumo.tags || [],
      descricao: resumo.descricao || ''
    });
    setShowModal(true);
  }, []);

  const handleUploadImagem = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      toast.error('Por favor, selecione um arquivo de imagem válido.');
      return;
    }

    setUploadingImage(true);
    try {
      const { data } = await base44.integrations.Core.UploadFile({ file });
      setFormData(prev => ({ ...prev, imagem_url: data.file_url }));
      toast.success('Imagem enviada com sucesso!');
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      toast.error('Erro ao enviar imagem.');
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSalvarResumo = useCallback(async () => {
    if (!formData.titulo || !formData.imagem_url) {
      toast.error('Preencha o título e faça upload da imagem.');
      return;
    }

    setSalvando(true);
    try {
      const dadosParaSalvar = {
        ...formData,
        tipo: 'resumo',
        conteudo_puro: '' // Resumos não têm conteúdo textual
      };

      if (editingResumo) {
        await Material.update(editingResumo.id, dadosParaSalvar);
        toast.success('Resumo atualizado com sucesso!');
      } else {
        await Material.create(dadosParaSalvar);
        toast.success('Resumo criado com sucesso!');
      }

      setShowModal(false);
      resetForm();
      carregarDados();

    } catch (error) {
      console.error('Erro ao salvar resumo:', error);
      toast.error('Erro ao salvar resumo.');
    } finally {
      setSalvando(false);
    }
  }, [formData, editingResumo, resetForm]);

  const handleExcluirResumo = useCallback(async (resumoId) => {
    if (!confirm('Tem certeza que deseja excluir este resumo? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await Material.delete(resumoId);
      toast.success('Resumo excluído com sucesso!');
      carregarDados();
    } catch (error) {
      console.error('Erro ao excluir resumo:', error);
      toast.error('Erro ao excluir resumo.');
    }
  }, []);

  const handlePreview = (resumo) => {
    setPreviewImage(resumo);
    setShowPreview(true);
  };

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Resumos Visuais
          </h3>
          <Button onClick={handleNovoResumo} className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Resumo
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">
            {/* Filtros */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Disciplina</label>
                <Select value={filtroDisciplina} onValueChange={setFiltroDisciplina}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as disciplinas</SelectItem>
                    {disciplinasUnicas.map(d => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-700">Buscar</label>
                <Input
                  placeholder="Digite o título do resumo..."
                  value={filtroBusca}
                  onChange={(e) => setFiltroBusca(e.target.value)}
                />
              </div>
            </div>

            {/* Lista de Resumos */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando resumos...</p>
              </div>
            ) : resumosFiltrados.length === 0 ? (
              <div className="text-center py-12">
                <FileImage className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhum resumo encontrado
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtroDisciplina || filtroBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhum resumo cadastrado ainda."}
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {resumosFiltrados.map((resumo) => (
                  <Card key={resumo.id} className="bg-slate-50 border border-slate-200 overflow-hidden group">
                    <div className="relative aspect-[3/4] overflow-hidden bg-slate-100">
                      {resumo.imagem_url ? (
                        <img
                          src={resumo.imagem_url}
                          alt={resumo.titulo}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <FileImage className="w-16 h-16 text-slate-300" />
                        </div>
                      )}
                      
                      {/* Overlay com ações */}
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => handlePreview(resumo)}
                          className="gap-1"
                        >
                          <Eye className="w-4 h-4" />
                          Ver
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => handleEditarResumo(resumo)}
                          className="gap-1"
                        >
                          <Edit className="w-4 h-4" />
                          Editar
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleExcluirResumo(resumo.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    <CardContent className="p-4">
                      <h4 className="font-semibold text-slate-800 mb-2 line-clamp-2">
                        {resumo.titulo}
                      </h4>
                      {resumo.descricao && (
                        <p className="text-sm text-slate-600 line-clamp-2 mb-2">
                          {resumo.descricao}
                        </p>
                      )}
                      <div className="flex flex-wrap gap-2">
                        {resumo.disciplina && (
                          <Badge variant="outline" className="text-xs">
                            {resumo.disciplina}
                          </Badge>
                        )}
                        {resumo.tags && resumo.tags.length > 0 && (
                          <Badge variant="outline" className="text-xs">
                            {resumo.tags.length} tags
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Criar/Editar Resumo */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileImage className="w-5 h-5" />
              {editingResumo ? 'Editar Resumo' : 'Novo Resumo'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="space-y-2">
              <Label>Título *</Label>
              <Input
                value={formData.titulo}
                onChange={(e) => setFormData(prev => ({ ...prev, titulo: e.target.value }))}
                placeholder="Ex: Resumo - Direitos Fundamentais"
              />
            </div>

            <div className="space-y-2">
              <Label>Disciplina</Label>
              <Select
                value={formData.disciplina}
                onValueChange={(value) => setFormData(prev => ({ ...prev, disciplina: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione a disciplina" />
                </SelectTrigger>
                <SelectContent>
                  {disciplinasUnicas.map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={formData.descricao}
                onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Breve descrição do resumo..."
                className="h-20"
              />
            </div>

            <div className="space-y-2">
              <Label>Imagem do Resumo *</Label>
              <div className="flex gap-2">
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleUploadImagem}
                  disabled={uploadingImage}
                  className="flex-1"
                />
                {uploadingImage && (
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-blue-600 border-t-transparent"></div>
                    Enviando...
                  </div>
                )}
              </div>
              {formData.imagem_url && (
                <div className="mt-2 relative w-full h-64 bg-slate-100 rounded-lg overflow-hidden border-2 border-green-200">
                  <img
                    src={formData.imagem_url}
                    alt="Preview"
                    className="w-full h-full object-contain"
                  />
                  <div className="absolute top-2 right-2">
                    <Badge className="bg-green-500">✓ Carregada</Badge>
                  </div>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarResumo} disabled={salvando}>
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingResumo ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Preview */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>{previewImage?.titulo}</DialogTitle>
          </DialogHeader>
          {previewImage && (
            <div className="space-y-4">
              <div className="relative w-full max-h-[70vh] overflow-auto bg-slate-100 rounded-lg">
                <img
                  src={previewImage.imagem_url}
                  alt={previewImage.titulo}
                  className="w-full h-auto"
                />
              </div>
              {previewImage.descricao && (
                <p className="text-sm text-slate-600">{previewImage.descricao}</p>
              )}
              {previewImage.disciplina && (
                <Badge variant="outline">{previewImage.disciplina}</Badge>
              )}
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setShowPreview(false)}>Fechar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}