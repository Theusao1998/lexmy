
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CreditCard,
  Search,
  Filter,
  Plus,
  XCircle,
  CheckCircle,
  Clock,
  AlertCircle,
  Trash2,
  Edit,
  Calendar,
  User as UserIcon,
  TrendingUp,
  Zap
} from "lucide-react";
import { base44 } from "@/api/base44Client";
import { format } from "date-fns";
import { ptBR } from "date-fns/locale";

export default function AdministracaoAssinaturas() {
  const [assinaturas, setAssinaturas] = useState([]);
  const [filteredAssinaturas, setFilteredAssinaturas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("todos");
  const [planoFilter, setPlanoFilter] = useState("todos");
  
  // Estados para estatísticas
  const [stats, setStats] = useState({
    total: 0,
    ativas: 0,
    testes: 0,
    canceladas: 0,
    pendentes: 0,
    expiradas: 0
  });

  // Estados para dialogs
  const [showAtivarTesteDialog, setShowAtivarTesteDialog] = useState(false);
  const [showEditarDialog, setShowEditarDialog] = useState(false);
  const [assinaturaEdicao, setAssinaturaEdicao] = useState(null);
  const [userEmailTeste, setUserEmailTeste] = useState("");
  const [processando, setProcessando] = useState(false);

  useEffect(() => {
    carregarAssinaturas();
  }, []);

  useEffect(() => {
    aplicarFiltros();
  }, [assinaturas, searchTerm, statusFilter, planoFilter]);

  const carregarAssinaturas = async () => {
    setLoading(true);
    try {
      // CORRIGIDO: Usar base44 normal (as regras de RLS permitem admin ver todas)
      const data = await base44.entities.Assinatura.list('-created_date', 100);
      setAssinaturas(data);
      
      // Calcular estatísticas
      const estatisticas = {
        total: data.length,
        ativas: data.filter(a => a.status === 'ativo').length,
        testes: data.filter(a => a.status === 'teste').length,
        canceladas: data.filter(a => a.status === 'cancelado').length,
        pendentes: data.filter(a => a.status === 'pendente').length,
        expiradas: data.filter(a => a.status === 'expirado').length
      };
      setStats(estatisticas);
    } catch (error) {
      console.error('Erro ao carregar assinaturas:', error);
      alert('Erro ao carregar assinaturas. Verifique o console.');
    } finally {
      setLoading(false);
    }
  };

  const aplicarFiltros = () => {
    let resultado = [...assinaturas];

    // Filtro de busca por email
    if (searchTerm.trim()) {
      resultado = resultado.filter(a =>
        a.user_email?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Filtro por status
    if (statusFilter !== "todos") {
      resultado = resultado.filter(a => a.status === statusFilter);
    }

    // Filtro por plano
    if (planoFilter !== "todos") {
      resultado = resultado.filter(a => a.plano === planoFilter);
    }

    setFilteredAssinaturas(resultado);
  };

  const calcularDiasRestantes = (dataFim) => {
    if (!dataFim) return null;
    const hoje = new Date();
    const fim = new Date(dataFim);
    
    hoje.setHours(0, 0, 0, 0);
    fim.setHours(0, 0, 0, 0);
    
    const diff = fim.getTime() - hoje.getTime();
    const dias = Math.ceil(diff / (1000 * 60 * 60 * 24));
    return Math.max(0, dias);
  };

  const getStatusBadge = (status) => {
    const configs = {
      ativo: { color: 'bg-green-100 text-green-700 border-green-200', icon: CheckCircle, label: 'Ativo' },
      teste: { color: 'bg-blue-100 text-blue-700 border-blue-200', icon: Zap, label: 'Teste' },
      cancelado: { color: 'bg-red-100 text-red-700 border-red-200', icon: XCircle, label: 'Cancelado' },
      expirado: { color: 'bg-gray-100 text-gray-700 border-gray-200', icon: Clock, label: 'Expirado' },
      pendente: { color: 'bg-yellow-100 text-yellow-700 border-yellow-200', icon: AlertCircle, label: 'Pendente' }
    };
    return configs[status] || configs.pendente;
  };

  const getPlanoBadge = (plano) => {
    const configs = {
      mensal: 'Mensal',
      semestral: 'Semestral',
      anual: 'Anual',
      teste: 'Teste Gratuito'
    };
    return configs[plano] || plano;
  };

  const handleAtivarTesteGratuito = async () => {
    if (!userEmailTeste.trim()) {
      alert('Por favor, insira o email do usuário.');
      return;
    }

    setProcessando(true);
    try {
      const { data } = await base44.functions.invoke('activateFreeTrial', {
        user_email: userEmailTeste.trim()
      });

      if (data.success) {
        alert(`Teste gratuito ativado com sucesso para ${userEmailTeste}!`);
        setShowAtivarTesteDialog(false);
        setUserEmailTeste("");
        await carregarAssinaturas();
      } else {
        alert(`Erro: ${data.error || 'Erro desconhecido'}`);
      }
    } catch (error) {
      console.error('Erro ao ativar teste:', error);
      alert('Erro ao ativar teste gratuito. Verifique o console.');
    } finally {
      setProcessando(false);
    }
  };

  const handleCancelarAssinatura = async (assinatura) => {
    if (!confirm(`Tem certeza que deseja cancelar a assinatura de ${assinatura.user_email}?`)) {
      return;
    }

    try {
      // CORRIGIDO: Usar base44 normal
      await base44.entities.Assinatura.update(assinatura.id, {
        status: 'cancelado',
        cancelada_em: new Date().toISOString()
      });
      alert('Assinatura cancelada com sucesso!');
      await carregarAssinaturas();
    } catch (error) {
      console.error('Erro ao cancelar assinatura:', error);
      alert('Erro ao cancelar assinatura. Verifique o console.');
    }
  };

  const handleExcluirAssinatura = async (assinatura) => {
    if (!confirm(`Tem certeza que deseja EXCLUIR permanentemente a assinatura de ${assinatura.user_email}? Esta ação não pode ser desfeita.`)) {
      return;
    }

    try {
      // CORRIGIDO: Usar base44 normal
      await base44.entities.Assinatura.delete(assinatura.id);
      alert('Assinatura excluída com sucesso!');
      await carregarAssinaturas();
    } catch (error) {
      console.error('Erro ao excluir assinatura:', error);
      alert('Erro ao excluir assinatura. Verifique o console.');
    }
  };

  const handleEditarAssinatura = (assinatura) => {
    setAssinaturaEdicao({...assinatura});
    setShowEditarDialog(true);
  };

  const handleSalvarEdicao = async () => {
    if (!assinaturaEdicao) return;

    setProcessando(true);
    try {
      const dadosAtualizacao = {
        status: assinaturaEdicao.status,
        plano: assinaturaEdicao.plano,
        valor: parseFloat(assinaturaEdicao.valor) || 0,
        data_fim: assinaturaEdicao.data_fim || null,
        data_teste_fim: assinaturaEdicao.data_teste_fim || null
      };

      // CORRIGIDO: Usar base44 normal
      await base44.entities.Assinatura.update(assinaturaEdicao.id, dadosAtualizacao);
      alert('Assinatura atualizada com sucesso!');
      setShowEditarDialog(false);
      setAssinaturaEdicao(null);
      await carregarAssinaturas();
    } catch (error) {
      console.error('Erro ao editar assinatura:', error);
      alert('Erro ao editar assinatura. Verifique o console.');
    } finally {
      setProcessando(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando assinaturas...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Estatísticas */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-blue-600 font-medium mb-1">Total</p>
                <p className="text-2xl font-bold text-blue-900">{stats.total}</p>
              </div>
              <CreditCard className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-green-600 font-medium mb-1">Ativas</p>
                <p className="text-2xl font-bold text-green-900">{stats.ativas}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-purple-600 font-medium mb-1">Testes</p>
                <p className="text-2xl font-bold text-purple-900">{stats.testes}</p>
              </div>
              <Zap className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-yellow-50 to-yellow-100 border-yellow-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-yellow-600 font-medium mb-1">Pendentes</p>
                <p className="text-2xl font-bold text-yellow-900">{stats.pendentes}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-red-600 font-medium mb-1">Canceladas</p>
                <p className="text-2xl font-bold text-red-900">{stats.canceladas}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-gray-50 to-gray-100 border-gray-200">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-600 font-medium mb-1">Expiradas</p>
                <p className="text-2xl font-bold text-gray-900">{stats.expiradas}</p>
              </div>
              <Clock className="w-8 h-8 text-gray-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filtros e Ações */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Busca */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
                <Input
                  placeholder="Buscar por email do usuário..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Filtro Status */}
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Status</SelectItem>
                <SelectItem value="ativo">Ativo</SelectItem>
                <SelectItem value="teste">Teste</SelectItem>
                <SelectItem value="cancelado">Cancelado</SelectItem>
                <SelectItem value="pendente">Pendente</SelectItem>
                <SelectItem value="expirado">Expirado</SelectItem>
              </SelectContent>
            </Select>

            {/* Filtro Plano */}
            <Select value={planoFilter} onValueChange={setPlanoFilter}>
              <SelectTrigger className="w-full md:w-40">
                <SelectValue placeholder="Plano" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todos">Todos Planos</SelectItem>
                <SelectItem value="mensal">Mensal</SelectItem>
                <SelectItem value="semestral">Semestral</SelectItem>
                <SelectItem value="anual">Anual</SelectItem>
                <SelectItem value="teste">Teste</SelectItem>
              </SelectContent>
            </Select>

            {/* Botão Ativar Teste */}
            <Button
              onClick={() => setShowAtivarTesteDialog(true)}
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 gap-2"
            >
              <Plus className="w-4 h-4" />
              Ativar Teste
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Tabela de Assinaturas */}
      <Card>
        <CardHeader>
          <CardTitle>Assinaturas ({filteredAssinaturas.length})</CardTitle>
          <CardDescription>
            Gerencie todas as assinaturas da plataforma
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Usuário</TableHead>
                  <TableHead>Plano</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Valor</TableHead>
                  <TableHead>Data Início</TableHead>
                  <TableHead>Data Fim</TableHead>
                  <TableHead>Dias Restantes</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAssinaturas.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-slate-500">
                      Nenhuma assinatura encontrada com os filtros aplicados.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredAssinaturas.map((assinatura) => {
                    const statusConfig = getStatusBadge(assinatura.status);
                    const StatusIcon = statusConfig.icon;
                    const diasRestantes = assinatura.status === 'teste' && assinatura.data_teste_fim
                      ? calcularDiasRestantes(assinatura.data_teste_fim)
                      : null;

                    return (
                      <TableRow key={assinatura.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <UserIcon className="w-4 h-4 text-slate-400" />
                            <span className="font-medium text-slate-700">{assinatura.user_email}</span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{getPlanoBadge(assinatura.plano)}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className={statusConfig.color}>
                            <StatusIcon className="w-3 h-3 mr-1" />
                            {statusConfig.label}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {assinatura.valor > 0 ? `R$ ${assinatura.valor.toFixed(2)}` : '-'}
                        </TableCell>
                        <TableCell>
                          {assinatura.data_inicio
                            ? format(new Date(assinatura.data_inicio), 'dd/MM/yyyy', { locale: ptBR })
                            : '-'}
                        </TableCell>
                        <TableCell>
                          {assinatura.status === 'teste' && assinatura.data_teste_fim
                            ? format(new Date(assinatura.data_teste_fim), 'dd/MM/yyyy', { locale: ptBR })
                            : assinatura.data_fim
                            ? format(new Date(assinatura.data_fim), 'dd/MM/yyyy', { locale: ptBR })
                            : '-'}
                        </TableCell>
                        <TableCell>
                          {diasRestantes !== null ? (
                            <Badge className="bg-blue-100 text-blue-700 border-blue-200">
                              {diasRestantes} dias
                            </Badge>
                          ) : '-'}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditarAssinatura(assinatura)}
                              className="h-8 w-8 p-0"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            {assinatura.status === 'ativo' && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleCancelarAssinatura(assinatura)}
                                className="h-8 w-8 p-0 text-orange-600 hover:text-orange-700 hover:bg-orange-50"
                              >
                                <XCircle className="w-4 h-4" />
                              </Button>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleExcluirAssinatura(assinatura)}
                              className="h-8 w-8 p-0 text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Dialog: Ativar Teste Gratuito */}
      <Dialog open={showAtivarTesteDialog} onOpenChange={setShowAtivarTesteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ativar Teste Gratuito</DialogTitle>
            <DialogDescription>
              Insira o email do usuário para ativar 14 dias de teste gratuito.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="user-email">Email do Usuário</Label>
              <Input
                id="user-email"
                type="email"
                placeholder="usuario@example.com"
                value={userEmailTeste}
                onChange={(e) => setUserEmailTeste(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAtivarTesteDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleAtivarTesteGratuito}
              disabled={processando || !userEmailTeste.trim()}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {processando ? 'Ativando...' : 'Ativar Teste'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog: Editar Assinatura */}
      <Dialog open={showEditarDialog} onOpenChange={setShowEditarDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Editar Assinatura</DialogTitle>
            <DialogDescription>
              Modifique os detalhes da assinatura de {assinaturaEdicao?.user_email}
            </DialogDescription>
          </DialogHeader>
          {assinaturaEdicao && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-status">Status</Label>
                <Select
                  value={assinaturaEdicao.status}
                  onValueChange={(value) => setAssinaturaEdicao({...assinaturaEdicao, status: value})}
                >
                  <SelectTrigger id="edit-status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ativo">Ativo</SelectItem>
                    <SelectItem value="teste">Teste</SelectItem>
                    <SelectItem value="cancelado">Cancelado</SelectItem>
                    <SelectItem value="pendente">Pendente</SelectItem>
                    <SelectItem value="expirado">Expirado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="edit-plano">Plano</Label>
                <Select
                  value={assinaturaEdicao.plano}
                  onValueChange={(value) => setAssinaturaEdicao({...assinaturaEdicao, plano: value})}
                >
                  <SelectTrigger id="edit-plano">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mensal">Mensal</SelectItem>
                    <SelectItem value="semestral">Semestral</SelectItem>
                    <SelectItem value="anual">Anual</SelectItem>
                    <SelectItem value="teste">Teste</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="edit-valor">Valor (R$)</Label>
                <Input
                  id="edit-valor"
                  type="number"
                  step="0.01"
                  value={assinaturaEdicao.valor}
                  onChange={(e) => setAssinaturaEdicao({...assinaturaEdicao, valor: e.target.value})}
                />
              </div>

              <div>
                <Label htmlFor="edit-data-fim">Data Fim</Label>
                <Input
                  id="edit-data-fim"
                  type="date"
                  value={assinaturaEdicao.data_fim ? assinaturaEdicao.data_fim.split('T')[0] : ''}
                  onChange={(e) => setAssinaturaEdicao({...assinaturaEdicao, data_fim: e.target.value ? new Date(e.target.value).toISOString() : null})}
                />
              </div>

              {assinaturaEdicao.status === 'teste' && (
                <div>
                  <Label htmlFor="edit-data-teste-fim">Data Fim do Teste</Label>
                  <Input
                    id="edit-data-teste-fim"
                    type="date"
                    value={assinaturaEdicao.data_teste_fim ? assinaturaEdicao.data_teste_fim.split('T')[0] : ''}
                    onChange={(e) => setAssinaturaEdicao({...assinaturaEdicao, data_teste_fim: e.target.value ? new Date(e.target.value).toISOString() : null})}
                  />
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowEditarDialog(false)}>
              Cancelar
            </Button>
            <Button
              onClick={handleSalvarEdicao}
              disabled={processando}
              className="bg-blue-600 hover:bg-blue-700"
            >
              {processando ? 'Salvando...' : 'Salvar Alterações'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
