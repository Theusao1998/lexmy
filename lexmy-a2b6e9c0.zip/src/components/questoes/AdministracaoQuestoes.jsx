
import React, { useState, useEffect, useMemo, useCallback } from "react"; // Added useMemo, useCallback
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Settings,
  Edit,
  Trash2,
  Save,
  X,
  HelpCircle,
  Zap,
  Check
} from "lucide-react";
import { QuestaoMultipla } from "@/api/entities";
import { Disciplina } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { FiltroQuestao } from "@/api/entities"; // NOVO: import do FiltroQuestao

export default function AdministracaoQuestoes() {
  const [questoes, setQuestoes] = useState([]);
  const [disciplinas, setDisciplinas] = useState([]); // This state will still hold all Disciplina objects
  const [filtrosDisponiveis, setFiltrosDisponiveis] = useState([]); // NOVO
  const [isLoading, setIsLoading] = useState(true);

  // Filtros
  const [filtrosDisciplina, setFiltrosDisciplina] = useState("all");
  const [filtrosConteudo, setFiltrosConteudo] = useState("all");
  const [filtrosBusca, setFiltrosBusca] = useState("");
  const [filtroStatus, setFiltroStatus] = useState("all");

  // Modal de criação/edição
  const [showModal, setShowModal] = useState(false);
  const [editingQuestao, setEditingQuestao] = useState(null);
  const [formData, setFormData] = useState({
    codigo: '', // NOVO: Campo para o código único
    disciplina: '',
    conteudo: '',
    enunciado: '',
    alternativas: ['', '', '', '', ''],
    gabarito: 0,
    fundamentacao: '',
    banca: '',
    ano: '',
    concurso: '',
    status: 'rascunho',
    origem: 'manual'
  });

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarQuestoes = useCallback(async () => {
    setIsLoading(true);
    try {
      let filtros = {};
      if (filtrosDisciplina && filtrosDisciplina !== "all") {
        filtros.disciplina = filtrosDisciplina;
      }
      if (filtrosConteudo && filtrosConteudo !== "all") {
        filtros.conteudo = filtrosConteudo;
      }
      if (filtroStatus && filtroStatus !== "all") {
        filtros.status = filtroStatus;
      }

      const data = await QuestaoMultipla.filter(filtros, '-created_date', 100);

      // ATUALIZADO: Aplicar filtro de busca por código ou disciplina
      let questoesFiltradas = data;
      if (filtrosBusca) {
        const busca = filtrosBusca.toLowerCase();
        questoesFiltradas = data.filter(questao =>
          questao.codigo?.toLowerCase().includes(busca) ||
          questao.disciplina?.toLowerCase().includes(busca)
        );
      }

      setQuestoes(questoesFiltradas);
    } catch (error) {
      console.error('Erro ao carregar questões:', error);
    }
    setIsLoading(false);
  }, [filtrosDisciplina, filtrosConteudo, filtrosBusca, filtroStatus, setQuestoes, setIsLoading]); // Added dependencies for useCallback

  useEffect(() => {
    carregarQuestoes();
  }, [filtrosDisciplina, filtrosConteudo, filtrosBusca, filtroStatus, carregarQuestoes]); // Added carregarQuestoes to dependencies

  const carregarDados = async () => {
    try {
      const [disciplinasData, filtrosData] = await Promise.all([
        Disciplina.list(),
        FiltroQuestao.list('-created_date', 100) // NOVO: carregar filtros
      ]);
      setDisciplinas(disciplinasData);
      setFiltrosDisponiveis(filtrosData); // NOVO
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
    }
  };

  // Função para gerar código único da questão
  const gerarCodigoQuestao = () => {
    const timestamp = Date.now().toString().slice(-6); // Últimos 6 dígitos do timestamp
    const random = Math.random().toString(36).substr(2, 4).toUpperCase(); // 4 caracteres aleatórios
    return `Q${timestamp}${random}`;
  };

  const resetForm = useCallback(() => {
    setFormData({
      codigo: gerarCodigoQuestao(), // NOVO: gerar código automaticamente
      disciplina: '',
      conteudo: '',
      enunciado: '',
      alternativas: ['', '', '', '', ''],
      gabarito: 0,
      fundamentacao: '',
      banca: '',
      ano: '',
      concurso: '',
      status: 'rascunho',
      origem: 'manual'
    });
    setEditingQuestao(null);
  }, []);

  const handleNovaQuestao = useCallback(() => {
    resetForm();
    setShowModal(true);
  }, [resetForm]);

  const handleEditarQuestao = useCallback((questao) => {
    setEditingQuestao(questao);
    setFormData({
      codigo: questao.codigo || gerarCodigoQuestao(), // NOVO: preservar código existente ou gerar novo
      disciplina: questao.disciplina || '',
      conteudo: questao.conteudo || '',
      enunciado: questao.enunciado || '',
      alternativas: questao.alternativas || ['', '', '', '', ''],
      gabarito: questao.gabarito || 0,
      fundamentacao: questao.fundamentacao || '',
      banca: questao.banca || '',
      ano: questao.ano ? String(questao.ano) : '', // CORRIGIDO: manter como string no form
      concurso: questao.concurso || '',
      status: questao.status || 'rascunho',
      origem: questao.origem || 'manual'
    });
    setShowModal(true);
  }, []);

  const handleAprovarQuestao = useCallback(async (questao) => {
    if (!confirm('Aprovar esta questão? Ela ficará disponível para os estudantes.')) {
      return;
    }

    try {
      // CORRIGIDO: Incluir todos os campos obrigatórios e tratar valores opcionais
      const dadosAtualizacao = {
        codigo: questao.codigo || gerarCodigoQuestao(),
        disciplina: questao.disciplina,
        conteudo: questao.conteudo || '',
        enunciado: questao.enunciado,
        alternativas: questao.alternativas,
        gabarito: questao.gabarito,
        fundamentacao: questao.fundamentacao,
        banca: questao.banca || '',
        ano: questao.ano ? Number(questao.ano) : null, // CORRIGIDO: converter para número ou null
        concurso: questao.concurso || '',
        status: 'aprovada',
        origem: questao.origem || 'manual'
      };

      // NOVO: Remover campos com valores vazios ou inválidos
      Object.keys(dadosAtualizacao).forEach(key => {
        if (dadosAtualizacao[key] === '' || dadosAtualizacao[key] === undefined) {
          if (key === 'ano') {
            dadosAtualizacao[key] = null; // Ano vazio deve ser null
          } else if (['banca', 'concurso', 'conteudo'].includes(key)) {
            // Manter string vazia para campos opcionais de texto
          } else {
            // Only delete if it's not one of the explicitly handled fields or required fields
            const requiredFields = ['codigo', 'disciplina', 'enunciado', 'alternativas', 'gabarito', 'fundamentacao', 'status', 'origem'];
            if (!requiredFields.includes(key)) {
                delete dadosAtualizacao[key];
            }
          }
        }
      });

      await QuestaoMultipla.update(questao.id, dadosAtualizacao);
      carregarQuestoes();
    } catch (error) {
      console.error('Erro ao aprovar questão:', error);
      alert('Erro ao aprovar questão. Tente novamente.');
    }
  }, [carregarQuestoes]);

  const handleSalvarQuestao = useCallback(async () => {
    try {
      // Validações básicas
      if (!formData.disciplina || !formData.enunciado || !formData.fundamentacao) {
        alert('Preencha os campos obrigatórios: disciplina, enunciado e fundamentação.');
        return;
      }

      if (formData.alternativas.some(alt => !alt.trim())) {
        alert('Preencha todas as 5 alternativas.');
        return;
      }

      // CORRIGIDO: Garantir que código existe e tratar campos numéricos
      const dadosParaSalvar = {
        ...formData,
        codigo: formData.codigo || gerarCodigoQuestao(),
        ano: formData.ano && formData.ano !== '' ? Number(formData.ano) : null // CORRIGIDO: converter para número ou null
      };

      // NOVO: Remover campos vazios que podem causar erro de validação
      Object.keys(dadosParaSalvar).forEach(key => {
        if (dadosParaSalvar[key] === '' || dadosParaSalvar[key] === undefined) {
          if (key === 'ano') {
            dadosParaSalvar[key] = null;
          } else if (['banca', 'concurso', 'conteudo'].includes(key)) {
            // Manter string vazia para campos opcionais de texto
          } else if (!['codigo', 'disciplina', 'enunciado', 'alternativas', 'gabarito', 'fundamentacao', 'status', 'origem'].includes(key)) {
            delete dadosParaSalvar[key];
          }
        }
      });

      if (editingQuestao) {
        await QuestaoMultipla.update(editingQuestao.id, dadosParaSalvar);
      } else {
        await QuestaoMultipla.create(dadosParaSalvar);
      }

      setShowModal(false);
      resetForm();
      carregarQuestoes();

    } catch (error) {
      console.error('Erro ao salvar questão:', error);
      alert('Erro ao salvar questão. Tente novamente.');
    }
  }, [formData, editingQuestao, resetForm, carregarQuestoes]);

  const handleExcluirQuestao = useCallback(async (questaoId) => {
    if (!confirm('Tem certeza que deseja excluir esta questão? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await QuestaoMultipla.delete(questaoId);
      carregarQuestoes();
    } catch (error) {
      console.error('Erro ao excluir questão:', error);
      alert('Erro ao excluir questão. Tente novamente.');
    }
  }, [carregarQuestoes]);

  const handleAlternativaChange = useCallback((index, value) => {
    const novasAlternativas = [...formData.alternativas];
    novasAlternativas[index] = value;
    setFormData(prev => ({ ...prev, alternativas: novasAlternativas }));
  }, [formData.alternativas]);

  // NOVO: Disciplinas únicas dos filtros
  const disciplinasUnicasFiltros = useMemo(() => {
    const disciplines = filtrosDisponiveis.map(f => f.disciplina);
    // Filter out potential empty strings or nulls if they exist in the data
    const validDisciplines = disciplines.filter(Boolean);
    const disciplinasSet = new Set(validDisciplines);
    return Array.from(disciplinasSet).sort();
  }, [filtrosDisponiveis]);

  // ATUALIZADO: Opções de conteúdo baseadas nos filtros
  const opcoesConteudo = useMemo(() => {
    return filtrosDisciplina && filtrosDisciplina !== "all"
      ? filtrosDisponiveis
          .filter(filtro => filtro.disciplina === filtrosDisciplina)
          .map(filtro => filtro.conteudo)
          .sort()
      : [];
  }, [filtrosDisponiveis, filtrosDisciplina]);

  const opcoesConteudoForm = useMemo(() => {
    return formData.disciplina
      ? filtrosDisponiveis
          .filter(filtro => filtro.disciplina === formData.disciplina)
          .map(filtro => filtro.conteudo)
          .sort()
      : [];
  }, [filtrosDisponiveis, formData.disciplina]);

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Questões de Múltipla Escolha
          </h3>
          <Button onClick={handleNovaQuestao} className="gap-2">
            <Plus className="w-4 h-4" />
            Nova Questão
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">

            {/* Filtros */}
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Disciplina</label>
                <Select value={filtrosDisciplina} onValueChange={setFiltrosDisciplina}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas as disciplinas" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as disciplinas</SelectItem>
                    {disciplinasUnicasFiltros.map(disciplina => (
                      <SelectItem key={disciplina} value={disciplina}>{disciplina}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Conteúdo</label>
                <Select value={filtrosConteudo} onValueChange={setFiltrosConteudo} disabled={!filtrosDisciplina || filtrosDisciplina === "all"}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os conteúdos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os conteúdos</SelectItem>
                    {opcoesConteudo.map((item) => (
                      <SelectItem key={item} value={item}>{item}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Status</label>
                <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="aprovada">Aprovada</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Buscar por Código</label>
                <Input
                  placeholder="Digite o código da questão..."
                  value={filtrosBusca}
                  onChange={(e) => setFiltrosBusca(e.target.value)}
                />
              </div>
            </div>

            {/* ATUALIZADA: Lista de Questões Simplificada */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando questões...</p>
              </div>
            ) : questoes.length === 0 ? (
              <div className="text-center py-12">
                <HelpCircle className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhuma questão encontrada
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtrosDisciplina || filtrosConteudo || filtrosBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhuma questão cadastrada ainda."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {questoes.map((questao) => (
                  <Card key={questao.id} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex items-center gap-4">
                          {/* NOVO: Código da questão em destaque */}
                          <div className="text-center">
                            <div className="text-lg font-bold text-slate-800 bg-white px-3 py-1 rounded-lg border-2 border-purple-200">
                              {questao.codigo || 'SEM CÓDIGO'}
                            </div>
                          </div>

                          {/* SIMPLIFICADO: Apenas disciplina e status */}
                          <div className="flex flex-col gap-2">
                            <div className="flex items-center gap-2">
                              <Badge variant="outline" className="font-medium">
                                {questao.disciplina}
                              </Badge>
                              <Badge className={questao.status === 'aprovada' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
                                {questao.status === 'aprovada' ? 'Aprovada' : 'Rascunho'}
                              </Badge>
                              
                              {questao.banca && (
                                <Badge variant="outline" className="bg-amber-50 text-amber-600 border-amber-200 text-xs">
                                  {questao.banca}
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Botões de ação */}
                        <div className="flex gap-2">
                          {questao.status === 'rascunho' && (
                            <Button
                              size="sm"
                              className="gap-1 bg-green-600 hover:bg-green-700"
                              onClick={() => handleAprovarQuestao(questao)}
                            >
                              <Check className="w-4 h-4" />
                              Aprovar
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarQuestao(questao)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirQuestao(questao.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Criar/Editar Questão */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HelpCircle className="w-5 h-5" />
              {editingQuestao ? 'Editar Questão' : 'Nova Questão'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* NOVO: Campo de código (somente leitura) */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Código da Questão</label>
              <Input
                value={formData.codigo}
                readOnly
                className="bg-slate-50 font-mono text-center font-bold"
              />
            </div>

            {/* ATUALIZADO: Informações básicas com novos campos */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Disciplina *</label>
                <Select
                  value={formData.disciplina}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, disciplina: value, conteudo: '' }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a disciplina" />
                  </SelectTrigger>
                  <SelectContent>
                    {disciplinasUnicasFiltros.map(disciplina => (
                      <SelectItem key={disciplina} value={disciplina}>{disciplina}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Conteúdo</label>
                <Select
                  value={formData.conteudo}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, conteudo: value }))}
                  disabled={!formData.disciplina || opcoesConteudoForm.length === 0}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione o conteúdo" />
                  </SelectTrigger>
                  <SelectContent>
                    {opcoesConteudoForm.map((item) => (
                      <SelectItem key={item} value={item}>{item}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* NOVO: Campos para questões de concurso */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Banca Organizadora</label>
                <Input
                  value={formData.banca}
                  onChange={(e) => setFormData(prev => ({ ...prev, banca: e.target.value }))}
                  placeholder="Ex: CESPE, FCC, VUNESP..."
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Ano da Prova</label>
                <Input
                  type="number"
                  min="2000"
                  max="2030"
                  value={formData.ano}
                  onChange={(e) => setFormData(prev => ({ ...prev, ano: e.target.value }))} // CORRIGIDO: manter como string no form
                  placeholder="2024"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Concurso</label>
                <Input
                  value={formData.concurso}
                  onChange={(e) => setFormData(prev => ({ ...prev, concurso: e.target.value }))}
                  placeholder="Ex: TRF 3ª Região, PCDF..."
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="aprovada">Aprovada</SelectItem>
                  </SelectContent>
              </Select>
            </div>

            {/* Enunciado */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Enunciado *</label>
              <Textarea
                value={formData.enunciado}
                onChange={(e) => setFormData(prev => ({ ...prev, enunciado: e.target.value }))}
                placeholder="Digite o enunciado da questão..."
                className="min-h-[100px]"
              />
            </div>

            {/* Alternativas */}
            <div className="space-y-4">
              <label className="text-sm font-medium">Alternativas *</label>
              {formData.alternativas.map((alt, index) => (
                <div key={index} className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData(prev => ({ ...prev, gabarito: index }))}
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors ${
                      formData.gabarito === index
                        ? 'bg-green-500 text-white'
                        : 'bg-slate-200 text-slate-600 hover:bg-green-200'
                    }`}
                    title="Clique para marcar como resposta correta"
                  >
                    {String.fromCharCode(65 + index)}
                  </button>
                  <Input
                    value={alt}
                    onChange={(e) => handleAlternativaChange(index, e.target.value)}
                    placeholder={`Alternativa ${String.fromCharCode(65 + index)}`}
                    className="flex-1"
                  />
                </div>
              ))}
              <p className="text-xs text-slate-500">
                Clique na letra para definir a resposta correta. Atual: <strong>{String.fromCharCode(65 + formData.gabarito)}</strong>
              </p>
            </div>

            {/* Fundamentação */}
            <div className="space-y-2">
              <label className="text-sm font-medium">Fundamentação Legal *</label>
              <Textarea
                value={formData.fundamentacao}
                onChange={(e) => setFormData(prev => ({ ...prev, fundamentacao: e.target.value }))}
                placeholder="Base legal, doutrinária ou jurisprudencial detalhada..."
                className="min-h-[120px]"
              />
            </div>

            {/* Botões */}
            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setShowModal(false)}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleSalvarQuestao}
                className="gap-2"
              >
                <Save className="w-4 h-4" />
                {editingQuestao ? 'Salvar' : 'Criar'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
