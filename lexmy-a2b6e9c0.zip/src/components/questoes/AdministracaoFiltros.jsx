
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  Plus, 
  Filter, 
  Edit,
  Trash2,
  Save,
  BookOpen,
  X,
  ChevronDown,
  ChevronRight
} from "lucide-react";
import { FiltroQuestao } from "@/api/entities";
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

export default function AdministracaoFiltros({ onFiltroAdicionado }) {
  const [filtros, setFiltros] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Estados para nova disciplina
  const [showDisciplinaModal, setShowDisciplinaModal] = useState(false);
  const [novaDisciplina, setNovaDisciplina] = useState('');
  const [novosConteudos, setNovosConteudos] = useState(['']);
  
  // Estados para disciplinas agrupadas
  const [disciplinasAgrupadas, setDisciplinasAgrupadas] = useState({});
  const [disciplinasAbertas, setDisciplinasAbertas] = useState({});

  // Estados para edição de disciplina
  const [showEditarModal, setShowEditarModal] = useState(false);
  const [editandoDisciplina, setEditandoDisciplina] = useState(null);
  const [conteudosEditando, setConteudosEditando] = useState([]);

  useEffect(() => {
    carregarFiltros();
  }, []);

  const carregarFiltros = async () => {
    setIsLoading(true);
    try {
      const data = await FiltroQuestao.list('-created_date', 200);
      setFiltros(data);
      
      // Agrupar filtros por disciplina
      const agrupados = {};
      data.forEach(filtro => {
        if (!agrupados[filtro.disciplina]) {
          agrupados[filtro.disciplina] = [];
        }
        agrupados[filtro.disciplina].push(filtro);
      });
      setDisciplinasAgrupadas(agrupados);
      
    } catch (error) {
      console.error('Erro ao carregar filtros:', error);
    }
    setIsLoading(false);
  };

  const resetForm = () => {
    setNovaDisciplina('');
    setNovosConteudos(['']);
  };

  const resetEditForm = () => {
    setEditandoDisciplina(null);
    setConteudosEditando([]);
  };

  const handleNovaDisciplina = () => {
    resetForm();
    setShowDisciplinaModal(true);
  };

  const adicionarConteudo = () => {
    if (novosConteudos.length < 10) { // Limite de 10 conteúdos por vez
      setNovosConteudos([...novosConteudos, '']);
    }
  };

  const removerConteudo = (index) => {
    if (novosConteudos.length > 1) {
      const novos = novosConteudos.filter((_, i) => i !== index);
      setNovosConteudos(novos);
    }
  };

  const atualizarConteudo = (index, valor) => {
    const novos = [...novosConteudos];
    novos[index] = valor;
    setNovosConteudos(novos);
  };

  const handleSalvarDisciplina = async () => {
    try {
      if (!novaDisciplina.trim()) {
        alert('Digite o nome da disciplina.');
        return;
      }

      // Filtrar conteúdos não vazios
      const conteudosValidos = novosConteudos.filter(c => c.trim() !== '');
      
      if (conteudosValidos.length === 0) {
        alert('Adicione pelo menos um conteúdo.');
        return;
      }

      // Verificar se disciplina já existe
      if (disciplinasAgrupadas[novaDisciplina]) {
        alert('Esta disciplina já existe. Use a edição para adicionar novos conteúdos.');
        return;
      }

      // Criar filtros para cada conteúdo
      const promises = conteudosValidos.map(conteudo => 
        FiltroQuestao.create({
          disciplina: novaDisciplina,
          conteudo: conteudo.trim()
        })
      );

      await Promise.all(promises);
      
      setShowDisciplinaModal(false);
      resetForm();
      await carregarFiltros();
      
      if (onFiltroAdicionado) {
        onFiltroAdicionado();
      }
      
    } catch (error) {
      console.error('Erro ao salvar disciplina:', error);
      alert('Erro ao salvar disciplina. Tente novamente.');
    }
  };

  const handleEditarDisciplina = (disciplina) => {
    const conteudos = disciplinasAgrupadas[disciplina].map(filtro => ({
      id: filtro.id,
      conteudo: filtro.conteudo
    }));
    
    setEditandoDisciplina(disciplina);
    setConteudosEditando(conteudos);
    setShowEditarModal(true);
  };

  const adicionarConteudoEdicao = () => {
    if (conteudosEditando.length < 15) {
      setConteudosEditando([...conteudosEditando, { id: null, conteudo: '' }]);
    }
  };

  const removerConteudoEdicao = (index) => {
    const conteudos = [...conteudosEditando];
    conteudos.splice(index, 1);
    setConteudosEditando(conteudos);
  };

  const atualizarConteudoEdicao = (index, valor) => {
    const conteudos = [...conteudosEditando];
    conteudos[index].conteudo = valor;
    setConteudosEditando(conteudos);
  };

  const handleSalvarEdicao = async () => {
    try {
      if (!editandoDisciplina) return;

      // Filtrar conteúdos válidos
      const conteudosValidos = conteudosEditando.filter(c => c.conteudo.trim() !== '');
      
      if (conteudosValidos.length === 0) {
        alert('Deve haver pelo menos um conteúdo válido.');
        return;
      }

      // Separar conteúdos novos dos existentes
      const conteudosNovos = conteudosValidos.filter(c => !c.id);
      const conteudosExistentes = conteudosValidos.filter(c => c.id);
      
      // Obter IDs dos conteúdos que devem ser mantidos
      const idsParaManter = conteudosExistentes.map(c => c.id);
      const todosConteudosOriginais = disciplinasAgrupadas[editandoDisciplina];
      const conteudosParaExcluir = todosConteudosOriginais.filter(f => !idsParaManter.includes(f.id));

      // Excluir conteúdos removidos
      for (const filtro of conteudosParaExcluir) {
        await FiltroQuestao.delete(filtro.id);
      }

      // Atualizar conteúdos existentes
      for (const conteudo of conteudosExistentes) {
        const original = todosConteudosOriginais.find(f => f.id === conteudo.id);
        if (original && original.conteudo !== conteudo.conteudo) {
          await FiltroQuestao.update(conteudo.id, {
            disciplina: editandoDisciplina,
            conteudo: conteudo.conteudo.trim()
          });
        }
      }

      // Criar novos conteúdos
      for (const novoConteudo of conteudosNovos) {
        await FiltroQuestao.create({
          disciplina: editandoDisciplina,
          conteudo: novoConteudo.conteudo.trim()
        });
      }

      setShowEditarModal(false);
      resetEditForm();
      await carregarFiltros();
      
      if (onFiltroAdicionado) {
        onFiltroAdicionado();
      }
      
    } catch (error) {
      console.error('Erro ao salvar edição:', error);
      alert('Erro ao salvar alterações. Tente novamente.');
    }
  };

  const handleExcluirFiltro = async (filtroId, disciplina, conteudo) => {
    if (!confirm(`Excluir "${conteudo}" de ${disciplina}?`)) {
      return;
    }

    try {
      await FiltroQuestao.delete(filtroId);
      carregarFiltros();
      if (onFiltroAdicionado) {
        onFiltroAdicionado();
      }
    } catch (error) {
      console.error('Erro ao excluir filtro:', error);
      alert('Erro ao excluir filtro. Tente novamente.');
    }
  };

  const handleExcluirDisciplina = async (disciplina) => {
    if (!confirm(`Excluir TODA a disciplina "${disciplina}" e todos os seus conteúdos? Esta ação não pode ser desfeita.`)) {
      return;
    }

    try {
      const filtrosDisciplina = disciplinasAgrupadas[disciplina];
      const promises = filtrosDisciplina.map(f => FiltroQuestao.delete(f.id));
      await Promise.all(promises);
      
      carregarFiltros();
      if (onFiltroAdicionado) {
        onFiltroAdicionado();
      }
    } catch (error) {
      console.error('Erro ao excluir disciplina:', error);
      alert('Erro ao excluir disciplina. Tente novamente.');
    }
  };

  const toggleDisciplina = (disciplina) => {
    setDisciplinasAbertas(prev => ({
      ...prev,
      [disciplina]: !prev[disciplina]
    }));
  };

  return (
    <>
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center">
                <Filter className="w-6 h-6 text-white" />
              </div>
              Administração de Filtros
            </CardTitle>
            <Button onClick={handleNovaDisciplina} className="gap-2">
              <Plus className="w-4 h-4" />
              Nova Disciplina
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-slate-800">Disciplinas e Conteúdos</h3>
            <p className="text-sm text-slate-600">Organize conteúdos por disciplina para seleção de questões</p>
          </div>

          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-2 border-green-600 border-t-transparent mx-auto mb-4"></div>
              <p className="text-slate-600">Carregando filtros...</p>
            </div>
          ) : Object.keys(disciplinasAgrupadas).length === 0 ? (
            <div className="text-center py-12">
              <Filter className="w-16 h-16 mx-auto mb-6 text-slate-400" />
              <h3 className="text-xl font-semibold text-slate-800 mb-2">
                Nenhuma disciplina cadastrada
              </h3>
              <p className="text-slate-600 mb-4">
                Adicione disciplinas com conteúdos para organizar as questões
              </p>
              <Button onClick={handleNovaDisciplina} className="gap-2">
                <Plus className="w-4 h-4" />
                Criar Primeira Disciplina
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(disciplinasAgrupadas).map(([disciplina, conteudos]) => (
                <Card key={disciplina} className="bg-slate-50 border border-slate-200">
                  <Collapsible 
                    open={disciplinasAbertas[disciplina]} 
                    onOpenChange={() => toggleDisciplina(disciplina)}
                  >
                    <CollapsibleTrigger asChild>
                      <div className="p-4 cursor-pointer hover:bg-slate-100 transition-colors">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            {disciplinasAbertas[disciplina] ? (
                              <ChevronDown className="w-4 h-4 text-slate-500" />
                            ) : (
                              <ChevronRight className="w-4 h-4 text-slate-500" />
                            )}
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                              <BookOpen className="w-4 h-4 text-white" />
                            </div>
                            <div>
                              <h4 className="font-semibold text-slate-800">{disciplina}</h4>
                              <p className="text-sm text-slate-600">{conteudos.length} conteúdos</p>
                            </div>
                          </div>
                          <div className="flex gap-2" onClick={(e) => e.stopPropagation()}>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleEditarDisciplina(disciplina)}
                              className="text-blue-600 hover:text-blue-700 hover:bg-blue-50"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button 
                              size="sm" 
                              variant="destructive" 
                              onClick={() => handleExcluirDisciplina(disciplina)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CollapsibleTrigger>
                    
                    <CollapsibleContent>
                      <div className="px-4 pb-4 border-t border-slate-200">
                        <div className="grid gap-2 mt-4">
                          {conteudos.map((filtro) => (
                            <div key={filtro.id} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                              <span className="text-sm text-slate-700">{filtro.conteudo}</span>
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                onClick={() => handleExcluirFiltro(filtro.id, disciplina, filtro.conteudo)}
                                className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                          ))}
                        </div>
                      </div>
                    </CollapsibleContent>
                  </Collapsible>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Modal de Nova Disciplina */}
      <Dialog open={showDisciplinaModal} onOpenChange={setShowDisciplinaModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5" />
              Nova Disciplina
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="disciplina-nome">Nome da Disciplina *</Label>
              <Input
                id="disciplina-nome"
                value={novaDisciplina}
                onChange={(e) => setNovaDisciplina(e.target.value)}
                placeholder="Ex: Direito Constitucional"
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Conteúdos *</Label>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={adicionarConteudo}
                  disabled={novosConteudos.length >= 10}
                >
                  <Plus className="w-4 h-4 mr-1" /> Adicionar
                </Button>
              </div>
              
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {novosConteudos.map((conteudo, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={conteudo}
                      onChange={(e) => atualizarConteudo(index, e.target.value)}
                      placeholder={`Conteúdo ${index + 1}`}
                      className="flex-1"
                    />
                    {novosConteudos.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => removerConteudo(index)}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => setShowDisciplinaModal(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSalvarDisciplina} className="gap-2">
                <Save className="w-4 h-4" />
                Criar Disciplina
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Modal de Editar Disciplina */}
      <Dialog open={showEditarModal} onOpenChange={(open) => {
        setShowEditarModal(open);
        if (!open) resetEditForm(); // Reset form when modal closes
      }}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Edit className="w-5 h-5" />
              Editar: {editandoDisciplina}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Conteúdos *</Label>
                <Button 
                  type="button" 
                  variant="outline" 
                  size="sm" 
                  onClick={adicionarConteudoEdicao}
                  disabled={conteudosEditando.length >= 15}
                >
                  <Plus className="w-4 h-4 mr-1" /> Adicionar
                </Button>
              </div>
              
              <div className="space-y-2 max-h-72 overflow-y-auto">
                {conteudosEditando.map((item, index) => (
                  <div key={item.id || `new-${index}`} className="flex gap-2"> {/* Use item.id for existing, unique temp key for new */}
                    <Input
                      value={item.conteudo}
                      onChange={(e) => atualizarConteudoEdicao(index, e.target.value)}
                      placeholder={`Conteúdo ${index + 1}`}
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removerConteudoEdicao(index)}
                      className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      disabled={conteudosEditando.length <= 1}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t">
              <Button variant="outline" onClick={() => {
                setShowEditarModal(false);
                resetEditForm();
              }}>
                Cancelar
              </Button>
              <Button onClick={handleSalvarEdicao} className="gap-2">
                <Save className="w-4 h-4" />
                Salvar Alterações
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
