import React, { useState, useEffect, useCallback } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Edit,
  Trash2,
  Save,
  FileText,
  Clock,
  ListChecks,
  CheckCircle2
} from "lucide-react";
import { Simulado } from "@/api/entities";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";

export default function AdministracaoSimulados() {
  const [simulados, setSimulados] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Filtros
  const [filtroStatus, setFiltroStatus] = useState("all");
  const [filtroBusca, setFiltroBusca] = useState("");

  // Modal de criação/edição
  const [showModal, setShowModal] = useState(false);
  const [editingSimulado, setEditingSimulado] = useState(null);
  const [formData, setFormData] = useState({
    titulo: '',
    descricao: '',
    disciplina: '',
    conteudo_puro: '',
    status: 'rascunho',
    instrucoes: '',
    tempo_limite_minutos: '',
    tags: []
  });
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    carregarSimulados();
  }, [filtroStatus, filtroBusca]);

  const carregarSimulados = useCallback(async () => {
    setIsLoading(true);
    try {
      let filtros = {};
      if (filtroStatus && filtroStatus !== "all") {
        filtros.status = filtroStatus;
      }

      const data = await Simulado.list('-created_date', 100);
      
      let simuladosFiltrados = data;
      if (filtroBusca) {
        const busca = filtroBusca.toLowerCase();
        simuladosFiltrados = data.filter(simulado =>
          simulado.titulo?.toLowerCase().includes(busca) ||
          simulado.disciplina?.toLowerCase().includes(busca)
        );
      }

      setSimulados(simuladosFiltrados);
    } catch (error) {
      console.error('Erro ao carregar simulados:', error);
    }
    setIsLoading(false);
  }, [filtroStatus, filtroBusca]);

  const resetForm = useCallback(() => {
    setFormData({
      titulo: '',
      descricao: '',
      disciplina: '',
      conteudo_puro: '',
      status: 'rascunho',
      instrucoes: '',
      tempo_limite_minutos: '',
      tags: []
    });
    setEditingSimulado(null);
  }, []);

  const handleNovoSimulado = useCallback(() => {
    resetForm();
    setShowModal(true);
  }, [resetForm]);

  const handleEditarSimulado = useCallback((simulado) => {
    setEditingSimulado(simulado);
    setFormData({
      titulo: simulado.titulo || '',
      descricao: simulado.descricao || '',
      disciplina: simulado.disciplina || '',
      conteudo_puro: simulado.conteudo_puro || '',
      status: simulado.status || 'rascunho',
      instrucoes: simulado.instrucoes || '',
      tempo_limite_minutos: simulado.tempo_limite_minutos ? String(simulado.tempo_limite_minutos) : '',
      tags: simulado.tags || []
    });
    setShowModal(true);
  }, []);

  const handleSalvarSimulado = useCallback(async () => {
    if (!formData.titulo.trim() || !formData.conteudo_puro.trim()) {
      alert('Preencha o título e o conteúdo.');
      return;
    }

    setSalvando(true);
    try {
      const dadosParaSalvar = {
        ...formData,
        tempo_limite_minutos: formData.tempo_limite_minutos ? parseInt(formData.tempo_limite_minutos) : null
      };

      if (editingSimulado) {
        await Simulado.update(editingSimulado.id, dadosParaSalvar);
      } else {
        await Simulado.create(dadosParaSalvar);
      }

      setShowModal(false);
      resetForm();
      carregarSimulados();

    } catch (error) {
      console.error('Erro ao salvar simulado:', error);
      alert('Erro ao salvar simulado. Tente novamente.');
    } finally {
      setSalvando(false);
    }
  }, [formData, editingSimulado, resetForm, carregarSimulados]);

  const handleExcluirSimulado = useCallback(async (simuladoId) => {
    if (!confirm('Tem certeza que deseja excluir este simulado? Esta ação não pode ser desfeita.')) {
      return;
    }

    try {
      await Simulado.delete(simuladoId);
      carregarSimulados();
    } catch (error) {
      console.error('Erro ao excluir simulado:', error);
      alert('Erro ao excluir simulado. Tente novamente.');
    }
  }, [carregarSimulados]);

  const handlePublicarSimulado = useCallback(async (simulado) => {
    if (!confirm('Publicar este simulado? Ele ficará disponível para os estudantes.')) {
      return;
    }

    try {
      await Simulado.update(simulado.id, {
        ...simulado,
        status: 'publicado'
      });
      carregarSimulados();
    } catch (error) {
      console.error('Erro ao publicar simulado:', error);
      alert('Erro ao publicar simulado. Tente novamente.');
    }
  }, [carregarSimulados]);

  return (
    <>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-slate-800">
            Gerenciamento de Simulados
          </h3>
          <Button onClick={handleNovoSimulado} className="gap-2">
            <Plus className="w-4 h-4" />
            Novo Simulado
          </Button>
        </div>

        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="space-y-6">
            {/* Filtros */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Status</label>
                <Select value={filtroStatus} onValueChange={setFiltroStatus}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os status</SelectItem>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="publicado">Publicado</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2 md:col-span-2">
                <label className="text-sm font-medium text-slate-700">Buscar</label>
                <Input
                  placeholder="Digite o título ou disciplina..."
                  value={filtroBusca}
                  onChange={(e) => setFiltroBusca(e.target.value)}
                />
              </div>
            </div>

            {/* Lista de Simulados */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-2 border-blue-600 border-t-transparent mx-auto mb-4"></div>
                <p className="text-slate-600">Carregando simulados...</p>
              </div>
            ) : simulados.length === 0 ? (
              <div className="text-center py-12">
                <FileText className="w-16 h-16 mx-auto mb-6 text-slate-400" />
                <h3 className="text-xl font-semibold text-slate-800 mb-2">
                  Nenhum simulado encontrado
                </h3>
                <p className="text-slate-600 mb-4">
                  {filtroStatus || filtroBusca
                    ? "Tente ajustar os filtros de busca"
                    : "Nenhum simulado cadastrado ainda."}
                </p>
              </div>
            ) : (
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {simulados.map((simulado) => (
                  <Card key={simulado.id} className="bg-slate-50 border border-slate-200">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between gap-4">
                        <div className="flex-1 space-y-2">
                          <div className="flex items-center gap-3">
                            <h4 className="font-semibold text-slate-800">{simulado.titulo}</h4>
                            <Badge className={simulado.status === 'publicado' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}>
                              {simulado.status === 'publicado' ? 'Publicado' : 'Rascunho'}
                            </Badge>
                          </div>
                          
                          {simulado.descricao && (
                            <p className="text-sm text-slate-600 line-clamp-1">{simulado.descricao}</p>
                          )}
                          
                          <div className="flex items-center gap-4 text-xs text-slate-500">
                            {simulado.disciplina && (
                              <span className="flex items-center gap-1">
                                <FileText className="w-3 h-3" />
                                {simulado.disciplina}
                              </span>
                            )}
                            {simulado.tempo_limite_minutos && (
                              <span className="flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {simulado.tempo_limite_minutos} min
                              </span>
                            )}
                          </div>
                        </div>

                        <div className="flex gap-2">
                          {simulado.status === 'rascunho' && (
                            <Button
                              size="sm"
                              className="gap-1 bg-green-600 hover:bg-green-700"
                              onClick={() => handlePublicarSimulado(simulado)}
                            >
                              <CheckCircle2 className="w-4 h-4" />
                              Publicar
                            </Button>
                          )}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEditarSimulado(simulado)}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleExcluirSimulado(simulado.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Modal de Criar/Editar Simulado */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              {editingSimulado ? 'Editar Simulado' : 'Novo Simulado'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Título *</Label>
                <Input
                  value={formData.titulo}
                  onChange={(e) => setFormData(prev => ({ ...prev, titulo: e.target.value }))}
                  placeholder="Ex: Simulado TRT 2023"
                />
              </div>

              <div className="space-y-2">
                <Label>Disciplina Principal</Label>
                <Input
                  value={formData.disciplina}
                  onChange={(e) => setFormData(prev => ({ ...prev, disciplina: e.target.value }))}
                  placeholder="Ex: Direito Constitucional"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Descrição</Label>
              <Textarea
                value={formData.descricao}
                onChange={(e) => setFormData(prev => ({ ...prev, descricao: e.target.value }))}
                placeholder="Breve descrição do simulado..."
                className="h-20"
              />
            </div>

            <div className="space-y-2">
              <Label>Instruções</Label>
              <Textarea
                value={formData.instrucoes}
                onChange={(e) => setFormData(prev => ({ ...prev, instrucoes: e.target.value }))}
                placeholder="Instruções para o usuário antes de iniciar o simulado..."
                className="h-24"
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Tempo Limite (minutos)</Label>
                <Input
                  type="number"
                  value={formData.tempo_limite_minutos}
                  onChange={(e) => setFormData(prev => ({ ...prev, tempo_limite_minutos: e.target.value }))}
                  placeholder="Ex: 180"
                />
              </div>
              <div className="space-y-2">
                <Label>Status</Label>
                <Select
                  value={formData.status}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, status: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="rascunho">Rascunho</SelectItem>
                    <SelectItem value="publicado">Publicado</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label>Conteúdo do Simulado *</Label>
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg mb-2">
                <p className="text-xs text-blue-800 leading-relaxed">
                  <strong>Formato:</strong><br/>
                  [DISCIPLINA: Nome da Disciplina]<br/>
                  Questão 1:<br/>
                  [Enunciado da questão...]<br/>
                  a) Alternativa A<br/>
                  b) Alternativa B (CORRETA)<br/>
                  c) Alternativa C<br/>
                  d) Alternativa D<br/>
                  e) Alternativa E<br/>
                  [FUNDAMENTAÇÃO: Texto da fundamentação...]<br/>
                </p>
              </div>
              <Textarea
                value={formData.conteudo_puro}
                onChange={(e) => setFormData(prev => ({ ...prev, conteudo_puro: e.target.value }))}
                placeholder="Cole o conteúdo completo do simulado aqui..."
                className="min-h-[300px] font-mono text-sm"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowModal(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSalvarSimulado} disabled={salvando}>
              {salvando ? (
                <>
                  <div className="w-4 h-4 mr-2 animate-spin rounded-full border-2 border-white border-t-transparent"></div>
                  Salvando...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  {editingSimulado ? 'Atualizar' : 'Criar'}
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}