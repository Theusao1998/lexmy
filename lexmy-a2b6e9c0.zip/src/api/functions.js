import { base44 } from './base44Client';


export const generateQuestion = base44.functions.generateQuestion;

export const gradeAnswer = base44.functions.gradeAnswer;

export const verticalizeEdital = base44.functions.verticalizeEdital;

export const exportEditalPdf = base44.functions.exportEditalPdf;

export const batchGenerateAssertivas = base44.functions.batchGenerateAssertivas;

export const batchGenerateQuestions = base44.functions.batchGenerateQuestions;

export const executarBot = base44.functions.executarBot;

export const gerarAssertivasPrecisas = base44.functions.gerarAssertivasPrecisas;

export const criarAvatarJuridico = base44.functions.criarAvatarJuridico;

export const gerarQuestaoMultipla = base44.functions.gerarQuestaoMultipla;

export const avaliarRespostaMultipla = base44.functions.avaliarRespostaMultipla;

export const interpretarLegislacaoHTML = base44.functions.interpretarLegislacaoHTML;

export const perguntarProfLex = base44.functions.perguntarProfLex;

export const chamarModerador = base44.functions.chamarModerador;

export const chamarProfLex = base44.functions.chamarProfLex;

export const processarDisciplinaEdital = base44.functions.processarDisciplinaEdital;

export const copiarEditalParaUsuario = base44.functions.copiarEditalParaUsuario;

export const parseSimulado = base44.functions.parseSimulado;

export const createMercadoPagoCheckout = base44.functions.createMercadoPagoCheckout;

export const mercadoPagoWebhook = base44.functions.mercadoPagoWebhook;

export const activateFreeTrial = base44.functions.activateFreeTrial;

export const cancelSubscription = base44.functions.cancelSubscription;

export const refineEditalTopics = base44.functions.refineEditalTopics;

export const enviarLembretesPlanner = base44.functions.enviarLembretesPlanner;

export const gradeDiscursiva = base44.functions.gradeDiscursiva;

