import { base44 } from './base44Client';


export const Disciplina = base44.entities.Disciplina;

export const Material = base44.entities.Material;

export const SessaoEstudo = base44.entities.SessaoEstudo;

export const Meta = base44.entities.Meta;

export const Edital = base44.entities.Edital;

export const PostComunidade = base44.entities.PostComunidade;

export const Assertiva = base44.entities.Assertiva;

export const LegislacaoAudio = base44.entities.LegislacaoAudio;

export const MusicaFoco = base44.entities.MusicaFoco;

export const ChatMessage = base44.entities.ChatMessage;

export const ChatBot = base44.entities.ChatBot;

export const RespostaComunidade = base44.entities.RespostaComunidade;

export const CurtidaPost = base44.entities.CurtidaPost;

export const CurtidaResposta = base44.entities.CurtidaResposta;

export const QuestaoMultipla = base44.entities.QuestaoMultipla;

export const FiltroQuestao = base44.entities.FiltroQuestao;

export const Anotacao = base44.entities.Anotacao;

export const Marcacao = base44.entities.Marcacao;

export const HistoricoQuestao = base44.entities.HistoricoQuestao;

export const ColecaoLegislacaoAudio = base44.entities.ColecaoLegislacaoAudio;

export const BlocoRotina = base44.entities.BlocoRotina;

export const Simulado = base44.entities.Simulado;

export const Assinatura = base44.entities.Assinatura;

export const QuestaoDiscursiva = base44.entities.QuestaoDiscursiva;

export const HistoricoDiscursiva = base44.entities.HistoricoDiscursiva;

export const MapaMental = base44.entities.MapaMental;



// auth sdk:
export const User = base44.auth;